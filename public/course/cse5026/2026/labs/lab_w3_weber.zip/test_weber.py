"""Run: python -m unittest -v test_weber.py"""
import csv
import json
from pathlib import Path
import random
import re
import signal
import subprocess
import sys
import tempfile
import unittest
from urllib.error import HTTPError
from urllib.request import build_opener, ProxyHandler, Request
import xml.etree.ElementTree as ET
from lab_w3_weber import Config, Session, generate_svg, MIN_DISTANCE, CSV_FIELDS, render_html


class LanguageTests(unittest.TestCase):
    def test_default_page_and_translated_page(self):
        english = render_html()
        self.assertIn('<html lang="en">', english)
        self.assertIn('Which side has more dots?', english)
        self.assertNotRegex(english, r'[\u4e00-\u9fff]')
        chinese = render_html('zh')
        self.assertIn('<html lang="zh-CN">', chinese)
        self.assertIn('哪边的点更多？', chinese)
        for page in (english, chinese):
            self.assertNotIn('__MESSAGES__', page)
            self.assertNotRegex(page, r'\{\{\w+\}\}')
        with self.assertRaises(ValueError):
            render_html('fr')

    def test_cli_language_and_http_save_flow(self):
        script = Path(__file__).with_name('lab_w3_weber.py')
        opener = build_opener(ProxyHandler({}))
        for options, lang in [([], 'en'), (['--lang', 'en'], 'en'), (['--lang', 'zh'], 'zh')]:
            with self.subTest(options=options), tempfile.TemporaryDirectory() as output:
                process = subprocess.Popen(
                    [sys.executable, str(script), '--no-browser', '--output-dir', output, *options],
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
                )
                try:
                    startup = ''.join(process.stdout.readline() for _ in range(6))
                    url = re.search(r'Open: (http://[^\s]+)', startup).group(1)
                    self.assertNotRegex(startup, r'[\u4e00-\u9fff]')
                    with opener.open(url, timeout=5) as response:
                        page = response.read().decode()
                    self.assertEqual(page, render_html(lang))

                    def post(route, body):
                        request = Request(url + route, json.dumps(body).encode(),
                                          {'Content-Type': 'application/json'})
                        with opener.open(request, timeout=5) as response:
                            return json.load(response)

                    with self.assertRaises(HTTPError) as caught:
                        post('start', {'participant': '=invalid'})
                    with caught.exception as response:
                        error = json.load(response)['error']
                    self.assertIn('Participant IDs' if lang == 'en' else '被试代号', error)
                    session = post('start', {'base': 20, 'delta': 5, 'trials': 1})
                    event = SessionTests.event(status='timeout', key='', rt=1501)
                    post('record', {'session_id': session['session_id'], 'event': event})
                    result = post('finish', {'session_id': session['session_id'], 'status': 'completed'})
                    self.assertEqual((result['count'], result['timeouts']), (1, 1))
                    with Path(result['csv_path']).open(encoding='utf-8-sig', newline='') as handle:
                        reader = csv.DictReader(handle)
                        rows = list(reader)
                        self.assertEqual(reader.fieldnames, CSV_FIELDS)
                    self.assertEqual(rows[0]['response_status'], 'timeout')
                finally:
                    process.send_signal(signal.SIGINT)
                    try:
                        stdout, stderr = process.communicate(timeout=5)
                    except subprocess.TimeoutExpired:
                        process.kill()
                        process.communicate()
                        raise
                self.assertEqual(process.returncode, 0, stderr)
                self.assertIn('Shutting down.', stdout)
                self.assertNotRegex(stdout + stderr, r'[\u4e00-\u9fff]')

    def test_cli_help_and_invalid_language(self):
        script = Path(__file__).with_name('lab_w3_weber.py')
        help_result = subprocess.run([sys.executable, str(script), '--help'], capture_output=True, text=True)
        self.assertEqual(help_result.returncode, 0)
        self.assertIn('--lang {en,zh}', help_result.stdout)
        invalid = subprocess.run([sys.executable, str(script), '--lang', 'fr'], capture_output=True, text=True)
        self.assertEqual(invalid.returncode, 2)
        self.assertIn('invalid choice', invalid.stderr)
        self.assertNotRegex(help_result.stdout + invalid.stderr, r'[\u4e00-\u9fff]')

class StimulusTests(unittest.TestCase):
    def test_svg_counts_bounds_and_no_overlap(self):
        for count in [10, 20, 100, 110, 400]:
            svg = generate_svg(count, random.Random(5026))
            dots = ET.fromstring(svg).findall('.//{http://www.w3.org/2000/svg}circle')
            self.assertEqual(len(dots), count)
            coords = [(float(d.attrib['cx']), float(d.attrib['cy'])) for d in dots]
            for i, (x, y) in enumerate(coords):
                self.assertTrue(12 <= x <= 388 and 12 <= y <= 388)
                self.assertTrue(all((x-a)**2+(y-b)**2 >= MIN_DISTANCE**2 for a,b in coords[:i]))
            self.assertEqual(svg, generate_svg(count, random.Random(5026)))

    def test_parameters(self):
        self.assertEqual(Config.parse({}), Config())
        for value in [{'base':0}, {'base':True}, {'delta':-1}, {'base':395,'delta':10},
                      {'trials':201}, {'trials':1.5}, {'participant':'=1+1'}]:
            with self.subTest(value=value), self.assertRaises(ValueError): Config.parse(value)

class SessionTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
    def tearDown(self): self.temp.cleanup()
    @staticmethod
    def event(trial=1, status='response', key='KeyF', rt=250.25):
        return dict(trial=trial,status=status,key=key,rt_ms=rt if status=='response' else None,
                    onset_ms=2000.0*trial,offset_ms=2000.0*trial+rt,preceding_fixation_ms=1510.0)
    def test_balanced_sides_and_independent_stimuli(self):
        for total in [20,21]:
            s=Session(self.root,Config(100,10,total),{})
            left=sum(t['ground_truth']=='left' for t in s.plan)
            self.assertLessEqual(abs(left-(total-left)),1)
            self.assertEqual(len(s.presentation()['trials']),total)
            for plan in s.plan:
                self.assertEqual(sorted([plan['left_count'],plan['right_count']]),[100,110])
                for side in ['left','right']:
                    dots=ET.parse(s.directory/plan[f'{side}_svg']).findall('.//{http://www.w3.org/2000/svg}circle')
                    self.assertEqual(len(dots),plan[f'{side}_count'])
            files=[p.read_text() for p in (s.directory/'stimuli').glob('*.svg')]
            self.assertEqual(len(files),len(set(files)))
    def test_csv_responses_timeout_and_retries(self):
        s=Session(self.root,Config(trials=3,participant='学生01'),{})
        correct_key='ArrowLeft' if s.plan[0]['ground_truth']=='left' else 'KeyJ'
        first=self.event(key=correct_key)
        s.record(first);s.record(first.copy())
        self.assertEqual(len(s.rows),1)
        with self.assertRaises(ValueError): s.record({**first,'key':'ArrowRight' if correct_key=='ArrowLeft' else 'KeyF'})
        with self.assertRaises(ValueError): s.record(self.event(trial=3))
        s.record(self.event(trial=2,status='timeout',key='',rt=1502))
        wrong='KeyJ' if s.plan[2]['ground_truth']=='left' else 'KeyF'
        s.record(self.event(trial=3,key=wrong,rt=800))
        summary=s.finish('completed')
        self.assertEqual((summary['correct'],summary['timeouts'],summary['count']),(1,1,3))
        self.assertEqual(summary['median_correct_rt_ms'],250.2)
        with (s.directory/'trials.csv').open(encoding='utf-8-sig',newline='') as f: rows=list(csv.DictReader(f))
        self.assertEqual(rows[0]['participant_id'],'学生01')
        self.assertEqual(rows[0]['correct'],'1')
        self.assertEqual(rows[1]['response'],'')
        self.assertEqual(rows[1]['rt_ms'],'')
        self.assertEqual(rows[1]['correct'],'0')
        self.assertEqual(rows[2]['correct'],'0')
        self.assertEqual(json.loads((s.directory/'session.json').read_text())['status'],'completed')
    def test_deadline_validation_and_interruption(self):
        s=Session(self.root,Config(trials=2),{})
        for event in [self.event(rt=1500),self.event(rt=-1),self.event(rt=float('nan')),
                      self.event(key='Space'),self.event(status='timeout',key='',rt=1499)]:
            with self.subTest(event=event), self.assertRaises(ValueError): s.record(event)
        s.record(self.event(status='interrupted',key='',rt=120))
        with self.assertRaises(ValueError): s.finish('completed')
        self.assertEqual(s.finish('aborted','focus_lost')['count'],0)
        self.assertEqual(s.rows[0]['correct'],'')
        self.assertEqual(s.rows[0]['rt_ms'],'')
        self.assertEqual(json.loads((s.directory/'session.json').read_text())['reason'],'focus_lost')
    def test_separate_rounds_never_overwrite(self):
        a,b=Session(self.root,Config(trials=1),{}),Session(self.root,Config(trials=1),{})
        self.assertNotEqual(a.id,b.id)
        self.assertTrue((a.directory/'trials.csv').is_file())
        self.assertTrue((b.directory/'trials.csv').is_file())

if __name__=='__main__': unittest.main()
