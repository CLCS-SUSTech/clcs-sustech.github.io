# Lab 3 · Weber's Law: Dot Comparison Experiment

Run [lab_w3_weber.py](lab_w3_weber.py) to explore how the same difference in dot count varies in discriminability across base numerosities. Students act as participants and compare two random dot arrays presented side by side. The program saves trial-level data and the original SVG stimuli.

## Getting started

Use **Python 3.10 or later**. No third-party Python packages are required. You need a computer keyboard and a recent version of Chrome, Edge, Firefox, or Safari.

Run the following command from this directory:

```bash
python3 lab_w3_weber.py
```

On Windows, you can use `py lab_w3_weber.py`. The browser will automatically open the local experiment page. If it does not, copy the full URL printed in the terminal into your browser. Keep the Python process running throughout the experiment. When you have finished, press `Ctrl+C` in the terminal to stop it. No internet connection is required: the program listens only on `127.0.0.1`, and no data are uploaded.

Optional arguments:

```bash
python3 lab_w3_weber.py --lang en
python3 lab_w3_weber.py --lang zh
python3 lab_w3_weber.py --output-dir ./results
python3 lab_w3_weber.py --no-browser --port 8765
```

The web interface defaults to English. Use `--lang zh` for Chinese or `--lang en` to explicitly select English. Command-line help and terminal output are always in English.

If no port is specified, an available port is selected automatically. By default, results are saved in `results/` next to the script, regardless of the working directory from which the program is launched.

## Controls and procedure

1. Set the base numerosity **I** (default: 20; presets: 20 and 100; custom values are also available), the difference **ΔI** (default: 10), and the number of trials (default: 20). The participant ID may be left blank; you do not need to enter your real name.
2. Click “Start experiment” (“开始实验” in the Chinese interface). First, look at the small black fixation cross in the center for 1.5 seconds.
3. The left and right dot arrays appear simultaneously. One contains I dots and the other contains I+ΔI dots. The counts are not displayed on screen.
4. Within 1.5 seconds, decide which array contains more dots: **F / Left arrow = more on the left**, **J / Right arrow = more on the right**.
5. The arrays disappear immediately after the first valid keypress. If no response is made, they disappear after 1.5 seconds and the trial is recorded as a timeout. A 1.5-second rest interval follows, with only the small central fixation cross visible, before the next trial begins. No correctness feedback is provided during the experiment.
6. At the end of the session, the page displays accuracy, the number of timeouts, median reaction time for correct responses, and the CSV path. Return to the settings to start another session.

Each session uses fixed values of I and ΔI. When the number of trials is even, the larger array appears equally often on each side; when it is odd, the counts differ by one trial. Trial order is randomized. The two SVG arrays for each trial are generated independently, using equal-sized white square frames and equal-sized black dots. Dots do not overlap or extend beyond the frame.

I and ΔI must be positive integers, I+ΔI must not exceed 400, and the number of trials must be between 1 and 200. The window must be at least 800×550 pixels. Keep the window size, browser zoom, and viewing distance unchanged throughout the experiment. You may maximize the window before starting.

Automatic key repeats from holding down a key are not counted as new responses. Keypresses during the rest interval do not submit an early response. Pressing **Esc**, switching to another window or tab, or resizing the window ends the current session and saves the records collected so far. A trial being presented at that time is marked as `interrupted`.

## Output files

Each session has its own directory, named with a timestamp and a random identifier to prevent overwriting:

```text
results/
  20260920_093000_a1b2c3d4/
    trials.csv
    session.json
    stimuli/
      trial_001_left.svg
      trial_001_right.svg
      ...
```

CSV fields:

| Field | Meaning |
| --- | --- |
| `session_id`, `participant_id`, `started_at_utc` | Session ID, participant ID, and start time (UTC) |
| `trial` | Trial number, starting at 1 |
| `base_I`, `delta_I`, `delta_over_I` | Base numerosity, difference, and relative difference ΔI/I |
| `left_count`, `right_count` | Actual dot counts on each side |
| `ground_truth` | Side containing more dots: `left` / `right` |
| `response`, `response_key` | Participant's choice and key code (`KeyF`, `KeyJ`, `ArrowLeft`, or `ArrowRight`); blank if no response was made |
| `response_status` | `response`: valid response; `timeout`: response deadline exceeded; `interrupted`: trial interrupted |
| `correct` | 1 for a correct response, 0 for an incorrect response or timeout; blank for interrupted trials |
| `rt_ms` | Time in milliseconds from the software presentation onset to keypress handling; blank for timeouts and interrupted trials. Do not treat these missing values as reaction times of 1500 ms |
| `onset_ms`, `offset_ms` | Presentation onset and offset relative to the current browser page's timing origin, not calendar timestamps |
| `stimulus_duration_ms` | Recorded stimulus duration, useful for checking timing delays |
| `preceding_fixation_ms` | Recorded duration of the fixation cross preceding this trial |
| `response_limit_ms`, `rest_ms` | Configured response deadline and rest interval, both 1500 ms |
| `stimulus_seed` | Trial generation seed, saved as a decimal string. It can be converted to an integer in Python; avoid truncation of large integers in spreadsheet software |
| `left_svg`, `right_svg` | SVG paths relative to the session directory |
| `viewport_width`, `viewport_height`, `device_pixel_ratio` | Browser display environment at the start of the session |

`onset_ms` and `offset_ms` are meaningful only within the same page's timing reference. Group data from different pages by `session_id`.

## Classroom experiment requirements

Collect data for the nine combinations of base numerosity **I = 20, 40, 100** and relative difference **r = 0.10, 0.25, 0.50**. Each table cell represents one session. The value in parentheses is the difference ΔI to enter in the program; the left/right positions are randomized by the program.

| Base numerosity I | r = 0.10 | r = 0.25 | r = 0.50 |
| --- | --- | --- | --- |
| 20 | 20 vs 22 (ΔI = 2) | 20 vs 25 (ΔI = 5) | 20 vs 30 (ΔI = 10) |
| 40 | 40 vs 44 (ΔI = 4) | 40 vs 50 (ΔI = 10) | 40 vs 60 (ΔI = 20) |
| 100 | 100 vs 110 (ΔI = 10) | 100 vs 125 (ΔI = 25) | 100 vs 150 (ΔI = 50) |

Complete **20 trials per session**, for a total of **9 sessions and 180 trials per participant**. Each student should randomize the order of the nine sessions and use the same participant ID throughout so that the results can be combined for analysis.

Analysis requirements:

- Report accuracy (Acc) and reaction time (RT) for correct responses in each condition. Report timeout rates separately.
- Plot accuracy as a line chart: **put r on the horizontal axis and accuracy on the vertical axis, with three separate lines for the three base numerosities.** Also create boxplots of RT for correct responses.
- Use a hypothesis test to examine whether RT differs significantly between the **I = 20 and I = 100 conditions with ΔI = 10**. State your null hypothesis (H_0), the test statistic (a t-test is suggested), and the test result (whether the null hypothesis is rejected).

Expected results and interpretation:

- **Model A: Linear perception.** If larger base numerosities are systematically easier and produce higher accuracy at the same r, the results are more consistent with Model A.
- **Model B: Logarithmic perception.** If the accuracy curves for the three base numerosities largely overlap, the results support Model B's prediction.

Use the line chart to discuss which model better matches the results. If differences between the curves are inconsistent, report that the available data are insufficient to distinguish the two models.

## Checks

The following tests require no additional dependencies:

```bash
python3 -m unittest -v test_weber.py
```

The tests cover parameter limits, SVG dot counts/boundaries/overlap, randomized side balance, CSV responses and missing values, response deadlines, duplicate requests, and interruption handling. Browser interaction should also be checked using actual keypresses in the current display environment.

References: [Weber–Fechner law dot illustration](https://en.wikipedia.org/wiki/Weber%E2%80%93Fechner_law), [requestAnimationFrame](https://developer.mozilla.org/en-US/docs/Web/API/Window/requestAnimationFrame), and [performance.now](https://developer.mozilla.org/en-US/docs/Web/API/Performance/now). All SVG stimuli in this experiment are generated by the program; the reference illustration is not used as a trial stimulus.
