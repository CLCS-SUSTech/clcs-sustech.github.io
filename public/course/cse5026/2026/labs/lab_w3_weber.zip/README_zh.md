# Lab 3 · Weber's law 点数比较实验

运行 [lab_w3_weber.py](lab_w3_weber.py)，用左右两幅随机点图体验相同点数差在不同基数下的可辨别程度。学生自己作为被试作答，程序保存逐 trial 数据和原始 SVG。

## 启动

使用 **Python 3.10 或更新版本**，不需要安装第三方 Python 库。需要电脑键盘，以及近期版本的 Chrome、Edge、Firefox 或 Safari。

在本目录运行：

```bash
python3 lab_w3_weber.py
```

Windows 可使用 `py lab_w3_weber.py`。浏览器会自动打开本机实验页面。若没有自动打开，复制终端打印的完整地址到浏览器。实验期间保留 Python 进程，全部结束后在终端按 `Ctrl+C` 退出。无需联网，程序仅监听 `127.0.0.1`，数据不上传。

可选参数：

```bash
python3 lab_w3_weber.py --lang en
python3 lab_w3_weber.py --lang zh
python3 lab_w3_weber.py --output-dir ./results
python3 lab_w3_weber.py --no-browser --port 8765
```

网页默认使用英文。使用 `--lang zh` 切换为中文，或使用 `--lang en` 明确选择英文；命令行帮助和输出始终使用英文。

不指定端口时自动选取空闲端口。默认结果目录位于脚本旁的 `results/`，不受启动时工作目录影响。

## 操作与实验流程

1. 设置基数 **I**（默认 20；预设 20、100，也可自定义）、差分数 **ΔI**（默认 10）、trial 数（默认 20）。被试代号可留空，不需要填写真实姓名。
2. 点击“Start experiment”（中文界面为“开始实验”）。先注视中心黑色小十字 1.5 秒。
3. 左右图同时出现。一幅含 I 个点，另一幅含 I+ΔI 个点；屏幕上不显示数量。
4. 在 1.5 秒内判断哪幅更多：**F / 左方向键 = 左边更多**，**J / 右方向键 = 右边更多**。
5. 首次有效按键后点图立即消失；若未作答，1.5 秒后消失并记为超时。随后休息 1.5 秒，仅以中央小十字作为注视点，再进入下一 trial。实验过程中没有正误反馈。
6. 完成后显示正确率、超时数、正确作答的反应时中位数和 CSV 路径。返回设置可运行下一轮。

每轮使用一个固定 I 和 ΔI。“更多”一侧在偶数轮次中各占一半，奇数轮次中相差一题，顺序随机打乱。每题两幅 SVG 分别随机生成，均为等大白底方框、等大黑点；点不重叠，也不被边框截断。

I、ΔI 为正整数，I+ΔI 最大为 400，trial 数为 1–200。窗口至少为 800×550 像素。实验过程中请保持窗口尺寸、浏览器缩放和观看距离不变。开始前可自行最大化窗口。

按住按键产生的自动重复不会被当成新答案，休息期的按键不会提前作答。按 **Esc**、切到其他窗口/标签页或改变窗口尺寸会结束当前轮次并保存已有记录。正在呈现的题标记为 `interrupted`。


## 结果文件

每轮单独建目录，文件名包含时间和随机标识，避免覆盖：

```text
results/
  20260920_093000_a1b2c3d4/
    trials.csv
    session.json
    stimuli/
      trial_001_left.svg
      trial_001_right.svg
      ...
```

CSV 字段：

| 字段 | 含义 |
| --- | --- |
| `session_id`, `participant_id`, `started_at_utc` | 轮次、被试代号、开始时间（UTC） |
| `trial` | 题号，从 1 开始 |
| `base_I`, `delta_I`, `delta_over_I` | 基数、差分数、相对差 ΔI/I |
| `left_count`, `right_count` | 两侧实际点数 |
| `ground_truth` | 点数更多的一侧：`left` / `right` |
| `response`, `response_key` | 被试选择及按键代码（`KeyF`、`KeyJ`、`ArrowLeft`、`ArrowRight`）；未作答为空 |
| `response_status` | `response` 有效作答、`timeout` 超时、`interrupted` 中断 |
| `correct` | 答对为 1、答错或超时为 0；中断为空 |
| `rt_ms` | 从软件呈现起点到按键处理的时间，单位毫秒；超时或中断为空，不能将其当作 1500 ms 的反应时 |
| `onset_ms`, `offset_ms` | 相对于当前浏览器页面计时原点的呈现/结束时间，不是日期时间 |
| `stimulus_duration_ms` | 实际记录的呈现时长，便于检查延迟 |
| `preceding_fixation_ms` | 本题之前实际记录的十字注视时长 |
| `response_limit_ms`, `rest_ms` | 设定的作答截止时间和休息时间，均为 1500 ms |
| `stimulus_seed` | 本题生成种子，保存为十进制字符串；Python 读取时可转整数，避免电子表格截断大整数 |
| `left_svg`, `right_svg` | 相对于本轮目录的 SVG 路径 |
| `viewport_width`, `viewport_height`, `device_pixel_ratio` | 开始时的浏览器显示环境 |

`onset_ms` 与 `offset_ms` 只在同一页面计时域内有意义，跨页面请按 `session_id` 分组。

## 课堂实验要求

使用基数 **I = 20、40、100** 和相对差 **r = 0.10、0.25、0.50** 的九种组合收集数据。每个单元格对应一轮实验，括号内为在程序中填写的差分数 ΔI；两侧实际位置由程序随机安排。

| 基数 I | r = 0.10 | r = 0.25 | r = 0.50 |
| --- | --- | --- | --- |
| 20 | 20 vs 22（ΔI = 2） | 20 vs 25（ΔI = 5） | 20 vs 30（ΔI = 10） |
| 40 | 40 vs 44（ΔI = 4） | 40 vs 50（ΔI = 10） | 40 vs 60（ΔI = 20） |
| 100 | 100 vs 110（ΔI = 10） | 100 vs 125（ΔI = 25） | 100 vs 150（ΔI = 50） |

每轮 **20 trials**，共 **9 轮、180 trials / 人**。每位学生随机安排九轮的顺序，并在各轮使用同一个被试代号，便于合并分析。

分析要求：

- 报告各条件的正确率（Acc）和正确作答的反应时（RT），并单独报告超时率。
- 画出正确率折线图：**横轴为 r，纵轴为正确率，用三条线分别表示三个基数。** 同时画出正确作答 RT 的箱线图（boxplot）。
- 使用假设检验分析 RT 是否在 **I=20,100 (ΔI=10)** 两组实验条件之间有显著差异。说明你的零假设（H_0）是什么，统计量（建议使用t检验），以及假设检验的结果（是否拒绝零假设）。

预期结果与解释：

- **模型 A：线性感知。** 相同 r 下，大基数系统性更容易、正确率更高，则更符合模型 A。
- **模型 B：对数感知。** 三个基数的正确率曲线大致重合，则支持模型 B 的预测。

根据折线图讨论结果更符合哪一种模型；如果曲线差异不稳定，则报告现有数据不足以区分两种模型。


## 检查

以下测试无需额外依赖：

```bash
python3 -m unittest -v test_weber.py
```

检查参数边界、SVG 数量/边界/重叠、随机侧别均衡、CSV 答案与缺失值、截止时间、重复请求和中断处理。浏览器交互还应检查实际按键与当前显示环境。

参考：[Weber–Fechner law 点图示意](https://en.wikipedia.org/wiki/Weber%E2%80%93Fechner_law)、[requestAnimationFrame](https://developer.mozilla.org/en-US/docs/Web/API/Window/requestAnimationFrame)、[performance.now](https://developer.mozilla.org/en-US/docs/Web/API/Performance/now)。本实验 SVG 均由程序生成，未使用参考图作为试次刺激。
