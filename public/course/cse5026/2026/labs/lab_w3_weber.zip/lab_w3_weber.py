#!/usr/bin/env python3
"""Weber dot-comparison lab. Python 3.10+, standard library only.

Run: python lab_w3_weber.py
Python generates SVG stimuli and saves data; the local browser presents trials
and timestamps responses without a network request in the timing path.
"""
from __future__ import annotations

import argparse
import csv
from dataclasses import dataclass
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, HTTPServer
import io
import json
import math
from pathlib import Path
import random
import secrets
import statistics
import threading
from urllib.parse import urlsplit
import webbrowser

RESPONSE_MS = 1500
REST_MS = 1500
SVG_SIZE = 400
DOT_RADIUS = 3
MIN_DISTANCE = 8
MAX_DOTS = 400
KEYS = {"KeyF": "left", "ArrowLeft": "left", "KeyJ": "right", "ArrowRight": "right"}
CSV_FIELDS = [
    "session_id", "participant_id", "started_at_utc", "trial", "base_I", "delta_I",
    "delta_over_I", "left_count", "right_count", "ground_truth", "response",
    "response_key", "response_status", "correct", "rt_ms", "onset_ms", "offset_ms",
    "stimulus_duration_ms", "preceding_fixation_ms", "response_limit_ms", "rest_ms",
    "stimulus_seed", "left_svg", "right_svg", "viewport_width", "viewport_height",
    "device_pixel_ratio",
]


# Shared translations for HTML, JavaScript, and user-facing validation messages.
MESSAGES = {'title': {'en': "Weber's Law · Dot Comparison", 'zh': "Weber's Law · 点数比较实验"},
 'heading': {'en': 'Which side has more dots?', 'zh': '哪边的点更多？'},
 'instructions': {'en': 'Compare the two dot arrays and decide which side has more dots within <strong>1.5 '
                        'seconds</strong>. Go with your first impression rather than counting each dot.',
                  'zh': '观察左右两幅点图，在 <strong>1.5 秒</strong>内判断哪边的点更多。凭第一印象作答，不必逐点数数。'},
 'left': {'en': 'More on the left', 'zh': '左边更多'},
 'right': {'en': 'More on the right', 'zh': '右边更多'},
 'rest': {'en': 'After each response or timeout, look at the central fixation cross for <strong>1.5 '
                'seconds</strong> before the next trial. A fixation cross also appears before the first '
                'trial.',
          'zh': '每次作答或超时后，注视屏幕中央的小十字，休息 <strong>1.5 秒</strong>，随后进入下一题。开始前也会显示十字。'},
 'conditions': {'en': 'Each session uses one base numerosity. You can compare I=10 and I=100 with the same '
                      'ΔI. Dot counts and correctness feedback are not shown during the experiment.',
                'zh': '一轮只使用一个基数。可先完成 I=10，再以相同 ΔI 完成 I=100，比较结果。实验中不显示点数或正误提示。'},
 'focus_note': {'en': 'Use a computer keyboard and keep the browser in focus. Switching windows or resizing '
                      'the window ends the session and saves existing results. Press Esc to end early.',
                'zh': '请使用电脑键盘，保持浏览器在前台。切换窗口或改变窗口大小会结束本轮并保存已有结果。按 Esc 可提前结束。'},
 'base': {'en': 'Base numerosity I', 'zh': '基数 I'},
 'custom': {'en': 'Custom', 'zh': '自定义'},
 'custom_base': {'en': 'Custom base numerosity', 'zh': '自定义基数'},
 'delta': {'en': 'Difference ΔI', 'zh': '差分数 ΔI'},
 'trials': {'en': 'Number of trials', 'zh': 'Trial 数'},
 'participant': {'en': 'Participant ID <small>(optional)</small>', 'zh': '被试代号 <small>（可选）</small>'},
 'participant_hint': {'en': 'e.g. S01; no real name needed', 'zh': '如 S01，无需真实姓名'},
 'start': {'en': 'Start experiment', 'zh': '开始实验'},
 'local_note': {'en': 'All data and SVG stimuli are saved locally. No internet connection is needed.',
                'zh': '所有数据与 SVG 仅保存到本机。无需联网。'},
 'completed': {'en': 'Session complete', 'zh': '本轮完成'},
 'again': {'en': 'Back to settings', 'zh': '返回设置，开始下一轮'},
 'retry': {'en': 'Retry saving', 'zh': '重试保存'},
 'results_note': {'en': 'Accuracy includes timeouts as incorrect and excludes interrupted trials. Reaction '
                        'time summaries include correct responses only. See the CSV for full trial-level '
                        'data.',
                  'zh': '正确率包含超时 trial（计为未答对），中断的 trial 不计入。反应时摘要仅包含正确作答。完整逐题数据见 CSV。'},
 'experiment': {'en': 'Experiment area', 'zh': '实验区域'},
 'footer': {'en': 'More on the left: F / ←\u3000\u3000More on the right: J / →\u3000\u3000Esc: End session',
            'zh': '左边更多：F / ←\u3000\u3000右边更多：J / →\u3000\u3000Esc：结束本轮'},
 'save_failed': {'en': 'Saving failed', 'zh': '保存失败'},
 'window_small': {'en': 'Enlarge the browser window to at least 800 × 550 pixels and use a computer '
                        'keyboard.',
                  'zh': '请将浏览器窗口扩大至至少 800 × 550 像素，并使用电脑键盘。'},
 'invalid_numbers': {'en': 'Enter positive integers: I + ΔI ≤ 400 and number of trials ≤ 200.',
                     'zh': '请输入正整数；I + ΔI ≤ 400，trial 数 ≤ 200。'},
 'generating': {'en': 'Generating dot arrays…', 'zh': '正在生成点图…'},
 'focus_start': {'en': 'The page lost focus. Return to this page and start again.', 'zh': '页面失去焦点，请返回后重新开始。'},
 'focus_lost': {'en': 'The page lost focus.', 'zh': '页面失去焦点'},
 'all_completed': {'en': 'All trials completed.', 'zh': '已完成全部 trial。'},
 'escape': {'en': 'Session ended by pressing Esc.', 'zh': '主动按 Esc 结束'},
 'ended': {'en': 'Session ended', 'zh': '本轮已结束'},
 'saving': {'en': 'Saving results…', 'zh': '正在保存结果…'},
 'accuracy': {'en': 'Accuracy', 'zh': '正确率'},
 'timeouts': {'en': 'Timeouts', 'zh': '超时'},
 'median_rt': {'en': 'Median correct RT', 'zh': '正确反应时中位数'},
 'connection_lost': {'en': 'The save connection was interrupted. The experiment has stopped.',
                     'zh': '保存连接中断，实验已停止。'},
 'window_switched': {'en': 'The session was interrupted by switching windows.', 'zh': '切换窗口导致本轮中断。'},
 'background': {'en': 'The page moved to the background. The session was interrupted.', 'zh': '页面进入后台，本轮中断。'},
 'resized': {'en': 'The window size changed. The session was interrupted.', 'zh': '窗口尺寸变化，本轮中断。'},
 'preview': {'en': 'This session compares {base} vs {larger} dots. ΔI / I = {ratio}',
             'zh': '本轮比较 {base} 与 {larger} 个点。ΔI / I = {ratio}'},
 'saved': {'en': 'Saved {total} trial records ({valid} valid).',
           'zh': '已保存 {total} 个 trial 的记录（有效 {valid} 个）。'},
 'save_error': {'en': 'Some results have not been saved: {error}. Keep this page open, make sure Python is '
                      'still running, and retry.',
                'zh': '尚未全部保存：{error}。请保留此页面，确认 Python 程序仍在运行后重试。'},
 'integer_range': {'en': '{key} must be an integer between 1 and {maximum}.',
                   'zh': '{key} 必须是 1–{maximum} 的整数。'},
 'too_many_dots': {'en': 'I + ΔI must not exceed {maximum} to keep the dot arrays clear.',
                   'zh': 'I + ΔI 不能超过 {maximum}，以保持点图清晰。'},
 'participant_length': {'en': 'Participant IDs must contain at most 40 characters and no control characters.',
                        'zh': '被试代号最多 40 个字符，不能含换行。'},
 'participant_prefix': {'en': 'Participant IDs must not start with =, +, -, or @.',
                        'zh': '被试代号不能以 =、+、-、@ 开头。'},
 'write_error': {'en': 'Unable to write result files: {error}', 'zh': '无法写入结果文件：{error}'},
 'network_error': {'en': 'Unable to reach the local Python server. Check that it is still running.',
                   'zh': '无法连接本地 Python 程序，请确认程序仍在运行。'}}

ERROR_ZH = {'Invalid dot count': '无效的点数',
 'Dot generation failed. Reduce the dot count and try again.': '点图生成失败，请减少点数后重试。',
 'Invalid display dimensions': '无效的显示尺寸',
 'Invalid trial number': '无效的试次编号',
 'Conflicting duplicate trial': '重复试次的数据不一致',
 'Trial out of order or session already ended': '试次顺序错误或本轮已结束',
 'Invalid timestamp': '无效的时间戳',
 'Offset must follow onset': '结束时间必须晚于呈现时间',
 'Invalid or late response': '无效或超时的反应',
 'Response timestamp mismatch': '反应时间戳不一致',
 'Invalid non-response': '无效的未作答记录',
 'Invalid trial status': '无效的试次状态',
 'Invalid session status': '无效的实验状态',
 'Cannot complete an unfinished session': '尚未完成所有试次，无法结束本轮',
 'Invalid request size': '无效的请求大小',
 'Expected a JSON object': '请求必须为 JSON 对象',
 'Unknown action': '未知操作',
 'Not found': '未找到',
 'Unexpected origin': '请求来源无效'}


@dataclass(frozen=True)
class Config:
    base: int = 10
    delta: int = 10
    trials: int = 20
    participant: str = "anonymous"

    @classmethod
    def parse(cls, value: dict, lang: str = "en") -> "Config":
        numbers = []
        for key, default, maximum in [("base", 10, MAX_DOTS), ("delta", 10, MAX_DOTS), ("trials", 20, 200)]:
            n = value.get(key, default)
            if type(n) is not int or not 1 <= n <= maximum:
                raise ValueError(translate(lang, "integer_range", key=key, maximum=maximum))
            numbers.append(n)
        if numbers[0] + numbers[1] > MAX_DOTS:
            raise ValueError(translate(lang, "too_many_dots", maximum=MAX_DOTS))
        participant = value.get("participant", "").strip() or "anonymous"
        if len(participant) > 40 or any(ord(c) < 32 for c in participant):
            raise ValueError(translate(lang, "participant_length"))
        # Spreadsheet applications must not interpret participant labels as formulas.
        if participant.startswith(("=", "+", "-", "@")):
            raise ValueError(translate(lang, "participant_prefix"))
        return cls(*numbers, participant)


def generate_svg(count: int, rng: random.Random) -> str:
    """Independent uniform point sampling with rejection to prevent overlap."""
    if type(count) is not int or not 1 <= count <= MAX_DOTS:
        raise ValueError("Invalid dot count")
    points: list[tuple[float, float]] = []
    for _ in range(count * 500):
        x, y = (round(rng.uniform(12, SVG_SIZE - 12), 3) for _ in range(2))
        if all((x - px) ** 2 + (y - py) ** 2 >= MIN_DISTANCE ** 2 for px, py in points):
            points.append((x, y))
            if len(points) == count:
                break
    if len(points) != count:
        raise RuntimeError("Dot generation failed. Reduce the dot count and try again.")
    dots = "".join(f'<circle cx="{x}" cy="{y}" r="{DOT_RADIUS}"/>' for x, y in points)
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {SVG_SIZE} {SVG_SIZE}" '
            f'width="{SVG_SIZE}" height="{SVG_SIZE}"><rect x="1" y="1" width="398" '
            f'height="398" fill="white" stroke="black" stroke-width="2"/>'
            f'<g fill="black">{dots}</g></svg>')


def atomic_text(path: Path, text: str, encoding: str = "utf-8") -> None:
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(text, encoding=encoding)
    temp.replace(path)


class Session:
    def __init__(self, root: Path, config: Config, environment: dict):
        self.config = config
        self.started = datetime.now(timezone.utc).isoformat()
        self.id = datetime.now().strftime("%Y%m%d_%H%M%S") + "_" + secrets.token_hex(4)
        self.directory = root / self.id
        self.directory.mkdir(parents=True, exist_ok=False)
        (self.directory / "stimuli").mkdir()
        self.environment = {}
        for key in ["viewport_width", "viewport_height", "device_pixel_ratio"]:
            n = environment.get(key, 0)
            if type(n) not in (int, float) or not math.isfinite(n) or not 0 <= n <= 100000:
                raise ValueError("Invalid display dimensions")
            self.environment[key] = n
        self.seed = secrets.randbits(64)
        rng = random.Random(self.seed)
        sides = ["left", "right"] * (config.trials // 2)
        if config.trials % 2:
            sides.append(rng.choice(["left", "right"]))
        rng.shuffle(sides)
        self.plan = []
        for number, side in enumerate(sides, 1):
            seed = rng.getrandbits(64)
            counts = (config.base + config.delta, config.base)
            if side == "right":
                counts = counts[::-1]
            trial = {"trial": number, "left_count": counts[0], "right_count": counts[1],
                     "ground_truth": side, "stimulus_seed": str(seed)}
            stimulus_rng = random.Random(seed)
            for which, count in zip(["left", "right"], counts):
                name = f"stimuli/trial_{number:03d}_{which}.svg"
                (self.directory / name).write_text(generate_svg(count, stimulus_rng), encoding="utf-8")
                trial[f"{which}_svg"] = name
            self.plan.append(trial)
        self.rows: list[dict] = []
        self.events: list[dict] = []
        self.status = "running"
        self.reason = ""
        self.save_csv()
        self.save_metadata()

    def save_metadata(self):
        metadata = {"session_id": self.id, "started_at_utc": self.started,
                    "status": self.status, "reason": self.reason,
                    "config": self.config.__dict__, "session_seed": str(self.seed),
                    "response_limit_ms": RESPONSE_MS, "rest_ms": REST_MS,
                    "svg_size": SVG_SIZE, "dot_radius": DOT_RADIUS,
                    "minimum_center_distance": MIN_DISTANCE, "environment": self.environment,
                    "recorded_trials": len(self.rows), "plan": self.plan}
        atomic_text(self.directory / "session.json", json.dumps(metadata, ensure_ascii=False, indent=2))

    def save_csv(self):
        output = io.StringIO(newline="")
        writer = csv.DictWriter(output, fieldnames=CSV_FIELDS)
        writer.writeheader()
        writer.writerows(self.rows)
        atomic_text(self.directory / "trials.csv", output.getvalue(), "utf-8-sig")

    def presentation(self) -> dict:
        trials = []
        for row in self.plan:
            trials.append({"trial": row["trial"], **{
                side: (self.directory / row[f"{side}_svg"]).read_text(encoding="utf-8")
                for side in ["left", "right"]}})
        return {"session_id": self.id, "trials": trials, "response_ms": RESPONSE_MS,
                "rest_ms": REST_MS, "csv_path": str(self.directory / "trials.csv")}

    def record(self, event: dict):
        number = event.get("trial")
        if type(number) is not int or not 1 <= number <= self.config.trials:
            raise ValueError("Invalid trial number")
        if number <= len(self.events):
            if event != self.events[number - 1]:
                raise ValueError("Conflicting duplicate trial")
            return  # Safe to retry a request whose acknowledgement was lost.
        if self.status != "running" or number != len(self.rows) + 1:
            raise ValueError("Trial out of order or session already ended")
        timing = {}
        for key in ["onset_ms", "offset_ms", "preceding_fixation_ms"]:
            n = event.get(key)
            if type(n) not in (float, int) or not math.isfinite(n) or n < 0:
                raise ValueError("Invalid timestamp")
            timing[key] = round(n, 3)
        duration = event["offset_ms"] - event["onset_ms"]
        if duration < 0:
            raise ValueError("Offset must follow onset")
        status, key, rt = event.get("status"), event.get("key", ""), event.get("rt_ms")
        if status == "response":
            if key not in KEYS or type(rt) not in (int, float) or not math.isfinite(rt) or not 0 <= rt < RESPONSE_MS:
                raise ValueError("Invalid or late response")
            if abs(duration - rt) > 1:
                raise ValueError("Response timestamp mismatch")
            response = KEYS[key]
        elif status in ["timeout", "interrupted"]:
            if key or rt is not None or (status == "timeout" and duration < RESPONSE_MS):
                raise ValueError("Invalid non-response")
            response, rt = "", ""
        else:
            raise ValueError("Invalid trial status")
        plan = self.plan[number - 1]
        row = {"session_id": self.id, "participant_id": self.config.participant,
               "started_at_utc": self.started, **plan, "base_I": self.config.base,
               "delta_I": self.config.delta, "delta_over_I": self.config.delta / self.config.base,
               "response": response, "response_key": key, "response_status": status,
               "correct": "" if status == "interrupted" else int(response == plan["ground_truth"]),
               "rt_ms": round(rt, 3) if rt != "" else "", **timing,
               "stimulus_duration_ms": round(duration, 3), "response_limit_ms": RESPONSE_MS,
               "rest_ms": REST_MS, **self.environment}
        self.rows.append(row)
        self.events.append(event.copy())
        try:
            self.save_csv()
        except OSError:
            self.rows.pop()
            self.events.pop()
            raise

    def finish(self, status: str, reason: str = ""):
        if status not in ["completed", "aborted"]:
            raise ValueError("Invalid session status")
        if self.status == "completed":
            return self.summary()
        if status == "completed" and (len(self.rows) != self.config.trials or any(r["response_status"] == "interrupted" for r in self.rows)):
            raise ValueError("Cannot complete an unfinished session")
        self.status, self.reason = status, reason[:160]
        self.save_metadata()
        return self.summary()

    def summary(self):
        valid = [r for r in self.rows if r["response_status"] != "interrupted"]
        rts = [r["rt_ms"] for r in valid if r["correct"] and r["response_status"] == "response"]
        return {"status": self.status, "count": len(valid),
                "correct": sum(r["correct"] for r in valid),
                "timeouts": sum(r["response_status"] == "timeout" for r in valid),
                "median_correct_rt_ms": round(statistics.median(rts), 1) if rts else None,
                "csv_path": str(self.directory / "trials.csv")}


HTML = r'''<!doctype html>
<html lang="{{html_lang}}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>{{title}}</title>
<style>
:root {font-family: -apple-system,BlinkMacSystemFont,"Segoe UI","Microsoft YaHei",sans-serif;color:#182b35;background:#f5f7f7;font-size:16px}
*{box-sizing:border-box}body{margin:0}button,input,select{font:inherit}button{cursor:pointer;border:0;border-radius:7px;padding:13px 22px;background:#126a65;color:white;font-weight:650}button:disabled{opacity:.5;cursor:wait}button.secondary{background:#e5eeed;color:#20524e}input,select{width:100%;padding:11px;border:1px solid #adbdbd;border-radius:6px;background:white;color:#182b35}input:focus,select:focus,button:focus-visible{outline:3px solid #71bdb3;outline-offset:2px}
main{max-width:1050px;margin:7vh auto;padding:30px}h1{font-size:clamp(30px,4vw,48px);line-height:1.2;margin:16px 0 25px;font-weight:700;letter-spacing:-1px}h2{font-size:24px}p{line-height:1.7}small,.muted{color:#5b6c74}.eyebrow{font-size:13px;letter-spacing:2px;color:#126a65;font-weight:700}.setup-layout{display:grid;grid-template-columns:1.1fr 1fr;gap:70px;align-items:start}.keys{display:flex;gap:30px;margin:28px 0}kbd{display:inline-block;border:1px solid #bdc9cc;background:white;padding:5px 10px;border-radius:5px;font:600 17px monospace;box-shadow:0 2px 0 #d0d9db}.field{margin:0 0 20px}label{display:block;margin-bottom:7px;font-weight:600}.row{display:grid;grid-template-columns:1fr 1fr;gap:16px}.form-box{background:white;border-top:3px solid #126a65;padding:28px;box-shadow:0 8px 30px #203c4810}.error{color:#b22929;line-height:1.6}.footnote{font-size:13px;margin-top:26px;color:#5b6c74}.actions{display:flex;gap:12px;flex-wrap:wrap;margin-top:25px}[hidden]{display:none!important}
#experiment{position:fixed;inset:0;background:#fff;color:#000;user-select:none;cursor:none}#trial-header{position:absolute;top:24px;left:34px;color:#777;font-size:14px}#trial-footer{position:absolute;bottom:24px;left:0;right:0;text-align:center;color:#777;font-size:15px}.plots{position:absolute;inset:0;display:flex;justify-content:center;align-items:center;gap:clamp(35px,7vw,120px)}.plot{width:min(39vw,65vh,440px);height:min(39vw,65vh,440px)}.plot svg{width:100%;height:100%;display:block}#fixation{position:absolute;left:50%;top:50%;width:18px;height:18px;transform:translate(-50%,-50%)}#fixation:before,#fixation:after{content:"";position:absolute;background:#000}#fixation:before{left:8px;top:0;width:2px;height:18px}#fixation:after{left:0;top:8px;width:18px;height:2px}
#results{max-width:760px}.stats{display:flex;gap:44px;flex-wrap:wrap;margin:35px 0}.stat strong{display:block;font-size:38px;color:#126a65;margin-bottom:6px}.path{font-family:monospace;overflow-wrap:anywhere;background:#e8eeee;padding:16px;font-size:14px}#rest-note{font-size:13px}.loading{color:#126a65}@media(max-width:750px){main{margin:20px auto;padding:22px}.setup-layout{grid-template-columns:1fr;gap:25px}.form-box{padding:22px}}
</style></head><body><main>
<section id="setup"><div class="eyebrow">CSE5026 · WEEK 03 · PERCEPTION</div>
<div class="setup-layout"><div><h1>{{heading}}</h1><p>{{instructions}}</p>
<div class="keys"><div>{{left}}<br><kbd>F</kbd> / <kbd>←</kbd></div><div>{{right}}<br><kbd>J</kbd> / <kbd>→</kbd></div></div>
<p>{{rest}}</p>
<p class="muted">{{conditions}}</p>
<p class="footnote">{{focus_note}}</p></div>
<form id="config" class="form-box"><div class="field"><label for="base-choice">{{base}}</label><select id="base-choice"><option value="10">10</option><option value="100">100</option><option value="custom">{{custom}}</option></select></div>
<div class="field" id="custom-field" hidden><label for="custom-base">{{custom_base}}</label><input id="custom-base" type="number" min="1" max="399" step="1" value="110"></div>
<div class="row"><div class="field"><label for="delta">{{delta}}</label><input id="delta" type="number" min="1" max="399" step="1" value="10" required></div><div class="field"><label for="trials">{{trials}}</label><input id="trials" type="number" min="1" max="200" step="1" value="20" required></div></div>
<div class="field"><label for="participant">{{participant}}</label><input id="participant" maxlength="40" placeholder="{{participant_hint}}" autocomplete="off"></div>
<p id="preview" class="muted"></p><button type="submit" id="start">{{start}}</button><p id="form-error" class="error" role="alert"></p><p class="footnote">{{local_note}}</p></form></div></section>
<section id="results" hidden><div class="eyebrow">SESSION RESULTS</div><h1 id="result-title">{{completed}}</h1><p id="result-message"></p><div id="stats" class="stats"></div><p id="save-state" class="loading" role="status"></p><div id="saved-path" class="path" hidden></div><div class="actions"><button id="again" hidden>{{again}}</button><button id="retry" class="secondary" hidden>{{retry}}</button></div><p class="footnote">{{results_note}}</p></section>
</main><section id="experiment" hidden aria-label="{{experiment}}"><div id="trial-header"></div><div class="plots" id="plots" hidden><div id="left-plot" class="plot"></div><div id="right-plot" class="plot"></div></div><div id="fixation" hidden></div><div id="trial-footer">{{footer}}</div></section>
<script>
'use strict';
const messages=__MESSAGES__;
const t=(key,values={})=>messages[key].replace(/\{(\w+)\}/g,(match,name)=>String(values[name]??match));
const $=id=>document.getElementById(id);
const keySides={KeyF:'left',ArrowLeft:'left',KeyJ:'right',ArrowRight:'right'};
let state='setup', session=null, index=0, onset=0, fixationOnset=0, fixationDuration=0;
let frame=null, timer=null, timeoutTimer=null, generation=0, events=[], acknowledged=0, saving=false;
let endStatus='aborted', endReason='', held=new Set();
const phaseActive=()=>['fixation','arming','stimulus'].includes(state);
function cancelClocks(){generation++;cancelAnimationFrame(frame);clearTimeout(timer);clearTimeout(timeoutTimer);}
async function api(route,body){
 let res;
 try{res=await fetch(route,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body),signal:AbortSignal.timeout(10000)});}
 catch(error){throw new Error(t('network_error'));}
 const data=await res.json();if(!res.ok)throw new Error(data.error||t('save_failed'));return data;
}
function updatePreview(){const base=$('base-choice').value==='custom'?Number($('custom-base').value):Number($('base-choice').value);const delta=Number($('delta').value);$('custom-field').hidden=$('base-choice').value!=='custom';$('custom-base').required=!$('custom-field').hidden;$('preview').textContent=t('preview',{base,larger:base+delta,ratio:base>0?(delta/base).toFixed(3):'—'});}
['base-choice','custom-base','delta'].forEach(id=>$(id).addEventListener('input',updatePreview));updatePreview();
$('config').addEventListener('submit',async e=>{
 e.preventDefault();$('form-error').textContent='';
 if(window.innerWidth<800||window.innerHeight<550){$('form-error').textContent=t('window_small');return;}
 const base=$('base-choice').value==='custom'?Number($('custom-base').value):Number($('base-choice').value);
 const delta=Number($('delta').value),trials=Number($('trials').value);
 if(![base,delta,trials].every(n=>Number.isInteger(n)&&n>0)||base+delta>400||trials>200){$('form-error').textContent=t('invalid_numbers');return;}
 state='loading';$('start').disabled=true;$('start').textContent=t('generating');
 try{
  session=await api('start',{base,delta,trials,participant:$('participant').value,environment:{viewport_width:innerWidth,viewport_height:innerHeight,device_pixel_ratio:devicePixelRatio}});
  // Build SVG nodes before any stimulus is visible. No fetching or parsing during a trial.
  session.nodes=session.trials.map(t=>{const nodes={};for(const side of ['left','right']){const box=document.createElement('div');box.innerHTML=t[side];nodes[side]=box.firstElementChild;}return nodes;});
  index=0;events=[];acknowledged=0;saving=false;held.clear();
  $('setup').hidden=true;$('results').hidden=true;$('experiment').hidden=false;
  document.activeElement.blur();
  if(document.hidden||!document.hasFocus()){endRun(t('focus_start'));return;}
  beginFixation();
 }catch(error){state='setup';$('form-error').textContent=error.message;}
 finally{$('start').disabled=false;$('start').textContent=t('start');}
});
function beginFixation(){
 cancelClocks();const token=generation;state='fixation';$('plots').hidden=true;$('fixation').hidden=false;
 $('trial-header').textContent=`Trial ${index+1} / ${session.trials.length}`;
 frame=requestAnimationFrame(()=>{if(token!==generation)return;fixationOnset=performance.now();
  const wait=()=>{if(token!==generation)return;const remaining=session.rest_ms-(performance.now()-fixationOnset);if(remaining>0){timer=setTimeout(wait,remaining);return;}armTrial();};
  timer=setTimeout(wait,session.rest_ms);
 });
}
function armTrial(){
 state='arming';const token=generation;
 $('left-plot').replaceChildren(session.nodes[index].left);$('right-plot').replaceChildren(session.nodes[index].right);
 frame=requestAnimationFrame(()=>{
  if(token!==generation||state!=='arming')return;
  if(document.hidden||!document.hasFocus()){endRun(t('focus_lost'));return;}
  $('fixation').hidden=true;$('plots').hidden=false;
  // Timestamp DOM reveal immediately before paint; this is a software onset estimate.
  onset=performance.now();fixationDuration=onset-fixationOnset;state='stimulus';
  const expire=()=>{if(token!==generation||state!=='stimulus')return;const now=performance.now();if(now-onset>=session.response_ms){endTrial('timeout','',now);}else{timeoutTimer=setTimeout(expire,session.response_ms-(now-onset));}};
  timeoutTimer=setTimeout(expire,session.response_ms);
 });
}
function capture(status,key,now){
 return {trial:index+1,status,key,rt_ms:status==='response'?now-onset:null,onset_ms:onset,offset_ms:now,preceding_fixation_ms:fixationDuration};
}
function endTrial(status,key,now){
 if(state!=='stimulus')return;
 events.push(capture(status,key,now));cancelClocks();$('plots').hidden=true;index++;
 if(index===session.trials.length){state='finishing';showResults('completed',t('all_completed'));}
 else beginFixation();
 flush();
}
document.addEventListener('keydown',e=>{
 if(e.code==='Escape'&&phaseActive()){e.preventDefault();endRun(t('escape'));return;}
 if(!(e.code in keySides))return;
 if(!phaseActive())return;
 e.preventDefault();if(e.repeat||held.has(e.code))return;held.add(e.code);
 if(e.ctrlKey||e.metaKey||e.altKey||state!=='stimulus')return;
 const now=performance.now();
 // Check the deadline here too: a delayed timeout callback must not admit late keys.
 endTrial(now-onset<session.response_ms?'response':'timeout',now-onset<session.response_ms?e.code:'',now);
});
document.addEventListener('keyup',e=>held.delete(e.code));
function endRun(reason){
 if(state==='stimulus')events.push(capture('interrupted','',performance.now()));
 cancelClocks();showResults('aborted',reason);flush();
}
function showResults(status,reason){
 state='finishing';endStatus=status;endReason=reason;$('experiment').hidden=true;$('plots').hidden=true;$('fixation').hidden=true;$('results').hidden=false;
 $('result-title').textContent=status==='completed'?t('completed'):t('ended');$('result-message').textContent=reason;
 $('stats').replaceChildren();$('save-state').textContent=t('saving');$('save-state').className='loading';$('saved-path').hidden=true;$('again').hidden=true;$('retry').hidden=true;
}
async function flush(){
 if(saving)return;saving=true;
 try{
  while(acknowledged<events.length){await api('record',{session_id:session.session_id,event:events[acknowledged]});acknowledged++;}
  if(state==='finishing'){
   const result=await api('finish',{session_id:session.session_id,status:endStatus,reason:endReason,events:[]});
   const values=[[t('accuracy'),result.count?`${(100*result.correct/result.count).toFixed(1)}%`:'—'],[t('timeouts'),String(result.timeouts)],[t('median_rt'),result.median_correct_rt_ms===null?'—':`${result.median_correct_rt_ms} ms`]];
   $('stats').replaceChildren();for(const [label,value] of values){const div=document.createElement('div');div.className='stat';const strong=document.createElement('strong');strong.textContent=value;div.append(strong,document.createTextNode(label));$('stats').append(div);}
   $('save-state').textContent=t('saved',{total:events.length,valid:result.count});
   $('saved-path').textContent=result.csv_path;$('saved-path').hidden=false;$('again').hidden=false;$('retry').hidden=true;state='results';
  }
 }catch(error){
  if(phaseActive()){if(state==='stimulus')events.push(capture('interrupted','',performance.now()));cancelClocks();showResults('aborted',t('connection_lost'));}
  $('save-state').className='error';$('save-state').textContent=t('save_error',{error:error.message});$('retry').hidden=false;
 }finally{saving=false;}
}
$('retry').addEventListener('click',()=>{$('retry').hidden=true;flush();});
$('again').addEventListener('click',()=>{state='setup';session=null;$('results').hidden=true;$('setup').hidden=false;});
window.addEventListener('blur',()=>{held.clear();if(phaseActive())endRun(t('window_switched'));});
document.addEventListener('visibilitychange',()=>{if(document.hidden&&phaseActive())endRun(t('background'));});
window.addEventListener('resize',()=>{if(phaseActive())endRun(t('resized'));});
window.addEventListener('pagehide',()=>{
 if(!session||state==='results'||state==='setup')return;
 if(state==='stimulus')events.push(capture('interrupted','',performance.now()));
 cancelClocks();
 const body={session_id:session.session_id,status:endStatus==='completed'&&state==='finishing'?'completed':'aborted',reason:'page_closed',events:events.slice(acknowledged)};
 navigator.sendBeacon('finish',new Blob([JSON.stringify(body)],{type:'application/json'}));
});
</script></body></html>'''




def translate(lang: str, message: str, **values) -> str:
    return MESSAGES[message][lang].format(**values)


def localize_error(message: str, lang: str) -> str:
    return ERROR_ZH.get(message, message) if lang == "zh" else message


def render_html(lang: str = "en") -> str:
    if lang not in ("en", "zh"):
        raise ValueError("Language must be 'en' or 'zh'")
    page = HTML.replace("{{html_lang}}", "zh-CN" if lang == "zh" else "en")
    for key, translations in MESSAGES.items():
        page = page.replace("{{" + key + "}}", translations[lang])
    # Escape '<' so translation text cannot terminate the script element.
    messages = json.dumps({key: value[lang] for key, value in MESSAGES.items()}, ensure_ascii=False).replace("<", "\\u003c")
    return page.replace("__MESSAGES__", messages)


class ExperimentServer(HTTPServer):
    def __init__(self, address, output: Path, lang: str = "en"):
        self.html = render_html(lang)
        self.lang = lang
        self.output = output
        self.sessions: dict[str, Session] = {}
        self.token = secrets.token_urlsafe(24)
        super().__init__(address, ExperimentHandler)


class ExperimentHandler(BaseHTTPRequestHandler):
    server: ExperimentServer

    def log_message(self, *_):
        pass

    def reply(self, status, payload, content_type="application/json; charset=utf-8"):
        data = payload.encode("utf-8") if isinstance(payload, str) else json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        try:
            self.wfile.write(data)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def do_GET(self):
        if urlsplit(self.path).path == f"/{self.server.token}/":
            self.reply(200, self.server.html, "text/html; charset=utf-8")
        else:
            self.reply(404, {"error": localize_error("Not found", self.server.lang)})

    def do_POST(self):
        path = urlsplit(self.path).path
        prefix = f"/{self.server.token}/"
        if not path.startswith(prefix):
            self.reply(404, {"error": localize_error("Not found", self.server.lang)})
            return
        # Requests must originate from this local experiment page.
        origin = self.headers.get("Origin")
        expected = f"http://127.0.0.1:{self.server.server_port}"
        if origin and origin != expected:
            self.reply(403, {"error": localize_error("Unexpected origin", self.server.lang)})
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if not 0 < length <= 250000:
                raise ValueError("Invalid request size")
            body = json.loads(self.rfile.read(length))
            if not isinstance(body, dict):
                raise ValueError("Expected a JSON object")
            route = path[len(prefix):]
            if route == "start":
                session = Session(self.server.output, Config.parse(body, self.server.lang), body.get("environment", {}))
                self.server.sessions[session.id] = session
                result = session.presentation()
            else:
                session = self.server.sessions[body["session_id"]]
                if route == "record":
                    session.record(body["event"])
                    result = {"saved": len(session.rows)}
                elif route == "finish":
                    for event in body.get("events", []):
                        session.record(event)
                    result = session.finish(body["status"], str(body.get("reason", "")))
                else:
                    raise ValueError("Unknown action")
            self.reply(200, result)
        except (ValueError, KeyError, TypeError, AttributeError) as error:
            self.reply(400, {"error": localize_error(str(error), self.server.lang)})
        except OSError as error:
            self.reply(500, {"error": translate(self.server.lang, "write_error", error=error)})
        except RuntimeError as error:
            self.reply(500, {"error": localize_error(str(error), self.server.lang)})


def main():
    parser = argparse.ArgumentParser(description="Weber dot-comparison experiment (Python standard library, local browser interface)")
    parser.add_argument("--output-dir", type=Path, default=Path(__file__).resolve().parent / "results", help="Directory for results (default: results next to this script)")
    parser.add_argument("--port", type=int, default=0, help="Local port (default: automatically select an available port)")
    parser.add_argument("--no-browser", action="store_true", help="Print the URL without opening a browser")
    parser.add_argument("--lang", choices=("en", "zh"), default="en", help="Web interface language (default: en); terminal output is always English")
    args = parser.parse_args()
    output = args.output_dir.expanduser().resolve()
    output.mkdir(parents=True, exist_ok=True)
    server = ExperimentServer(("127.0.0.1", args.port), output, args.lang)
    url = f"http://127.0.0.1:{server.server_port}/{server.token}/"
    print(f"\nWeber dot-comparison experiment\nOpen: {url}\nWeb interface language: {args.lang}\nResults directory: {output}\nPress Ctrl+C in this terminal to quit when finished.\n", flush=True)
    if not args.no_browser:
        threading.Timer(0.4, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down. Previously saved CSV files will be kept.")
    finally:
        for session in server.sessions.values():
            if session.status == "running":
                try:
                    session.finish("aborted", "server_stopped")
                except OSError as error:
                    print(f"Unable to update session status: {error}")
        server.server_close()


if __name__ == "__main__":
    main()
