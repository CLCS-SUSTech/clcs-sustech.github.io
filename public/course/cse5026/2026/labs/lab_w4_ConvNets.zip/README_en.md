# Week 4 lab: Vision, ConvNets, and representational similarity

[中文说明](README_zh.md)

Use **[lab_w4_ConvNets.ipynb](lab_w4_ConvNets.ipynb)** to build and train a convolutional neural network on MNIST, then compare how its layers represent the same images. The answer notebook is [lab_w4_ConvNets_sol.ipynb](lab_w4_ConvNets_sol.ipynb).

## Environment and launch

Use a Python environment with PyTorch, torchvision, NumPy, Matplotlib, SciPy, and Jupyter. A CPU is sufficient. From this folder, an example setup is:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install torch torchvision numpy matplotlib scipy jupyterlab
python -m jupyterlab lab_w4_ConvNets.ipynb
```

On Windows, activate the environment with `.venv\Scripts\activate` instead. You may use an existing environment with these packages; select its Python kernel. Scikit-learn is optional and is needed only if you choose its `cosine_similarity` implementation.

Run the notebook from its own folder. MNIST is downloaded to `./MNIST/` if needed and reused on subsequent runs. Each execution of the setup cell creates a new `outputs/w4_vision_<timestamp>/` folder for the saved results.

Complete every `TODO(...)` expression, using the `### START YOUR CODE ###` / `### END YOUR CODE ###` comments to locate the marked answer regions, and fill in the written observations. Unfinished placeholders raise `NotImplementedError`. Also complete the cosine-similarity placeholder in the report extension. Run cells in order; after completing the notebook, restart the kernel and run all cells as a final check.

## Exercises

| Exercise | Your task |
|---|---|
| **0 — Inspect MNIST** | Record image height and width in pixels, the number of channels, the meaning of each batch dimension, and the number of output classes. |
| **1 — Define the ConvNet** | Complete two convolutional layers and three fully connected layers, including the forward pass. Both convolutions use 3 × 3 filters, stride 1, and padding 1, followed by ReLU and 2 × 2 max pooling. Calculate the FC 1 input size and the tensor shape at each stage. |
| **2 — Train the network** | Complete gradient clearing, forward pass, loss, backpropagation, parameter update, class prediction, and batch accuracy. Reach at least 95% rolling training accuracy. |
| **3 — Compute representation similarity** | Use the supplied image-by-image Pearson similarities and implement `RDM = 1 - similarity`. In the report extension, implement and investigate one alternative similarity metric, such as cosine. |
| **4 — Compare RDMs** | Compute symmetric 5 × 5 matrices of Spearman scores for `l1`, `l2`, `l3`, `l4`, and `y`, using both Pearson-based and alternative-metric RDMs. For each matrix, identify the strongest pair of distinct layers, give its score, and report all tied maxima. |

### Training

The target is **at least 95% mean training accuracy over the most recent 100 mini-batches**, with 16 images per batch. The stopping accuracy uses logits computed before that step's parameter update. This usually takes approximately **800–1,500 optimizer steps**, depending on initialization and the software environment; a step is one mini-batch, not one epoch.

The loop checks every 100 steps and allows up to 2,000 steps. If the target is not reached, inspect the implementation and learning curve before increasing the cap. Re-running the training cell initializes a new model. This criterion is not held-out test accuracy.

### Representation analysis

Use **100 fixed test images, 10 per digit**, ordered by digit label. Every layer and metric must use the same images, in the same order, with the already trained network.

Each flattened activity matrix has shape **N images × P features**. `np.corrcoef(new_val)` compares image-response rows within one layer, producing an **N × N** similarity matrix. For Pearson, `RDM = 1 - similarity` ranges from 0 to 2. The supplied checks stop for undefined correlations from constant response vectors.

For each pair of layers, compare the corresponding **upper-triangle RDM entries, excluding the diagonal**: 4,950 unique image pairs for 100 images. Find the largest signed score among distinct layer pairs, without taking its absolute value. A Spearman score near 1 means that the layers agree about which image pairs are relatively similar or dissimilar.

For the alternative metric, state its formula, interpretation, and conversion to dissimilarity. The supplied scaffold uses cosine similarity, which does not subtract each response vector's mean. Reusing Pearson through a different software function does not count as a new metric.

## Submission

Submit:

1. Your completed `.ipynb`, with all code executed in order and the relevant outputs visible.
2. A **separate PDF report** on Exercises 3 and 4. The notebook alone does not replace the report.

The report must contain:

- **Exercise 3:** RDM results for all five layers under the Pearson baseline and **one alternative similarity metric** (for example, cosine). Briefly explain what an entry in the similarity matrix measures.
- **Exercise 4:** The 5 × 5 Spearman score matrices for **both the Pearson-based and alternative-metric RDMs** (for example, cosine). For each matrix, name the **two distinct layers with the highest correlation and give their numerical score**, listing every tied maximum if needed. Do not assume adjacent layers must win.

Use figures and numbers produced by your own run. **Do not submit the downloaded MNIST dataset.**
