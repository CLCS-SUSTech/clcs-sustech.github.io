# Week 4 lab: Vision, ConvNets, and RSA

[中文说明](README_zh.md)

Use **[lab_ConvNets_RSA.ipynb](lab_ConvNets_RSA.ipynb)** for the new lab. It is an English student notebook with exercises 0–4 and explicit `TODO(...)` placeholders. Submit the completed notebook and a **separate PDF report** covering Exercises 3 and 4.

## Files

| File | Purpose |
|---|---|
| `lab_ConvNets_RSA.ipynb` | New student exercises; start here. |
| `ConvNets_origin.ipynb` | Main reference notebook. |
| `ANN-Primer_2020.pdf` | Background reading on neural networks and RSA. |
| `lab_ConvNets.ipynb`, `lab_ConvNets_sol.ipynb` | Previous-semester materials, preserved unchanged. They are not the new assignment or its answer key. |

## Environment and launch

Use a Python environment with PyTorch, torchvision, NumPy, Matplotlib, SciPy, and JupyterLab. A CPU is sufficient. From this folder, an example setup is:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install torch torchvision numpy matplotlib scipy jupyterlab
python -m jupyterlab lab_ConvNets_RSA.ipynb
```

On Windows, activate the environment with `.venv\Scripts\activate` instead. You may use an existing course environment if it has these packages; select that environment's Python kernel. Scikit-learn is optional: the cosine exercise can be implemented directly with NumPy. Install `scikit-learn` only if you choose its `cosine_similarity` function.

Keep the notebook's working directory as `lab_w4_vision`. The first dataset cell downloads MNIST to `./MNIST/` if necessary, so internet access is needed on the first run. Existing data in that folder will be reused.

Replace each `TODO(...)` expression with your implementation, and complete the written observations. An unfinished placeholder intentionally raises `NotImplementedError`. After completing the work, restart the kernel and run every cell in order; a blank student template is not expected to run through all exercises.

## Exercises

| Exercise | Required work |
|---|---|
| **0 — MNIST** | Inspect image height and width in pixels, input channels, batch dimensions, and class labels. |
| **1 — ConvNet** | Complete two convolutional layers and three fully connected layers. Conv outputs are 6 and 16 channels; both filters are 3 × 3 with padding 1. After each convolution, apply ReLU and 2 × 2 max pooling. Calculate the first FC input size; hidden FC outputs are 120 and 84. Complete the forward pass. The readout branch is supplied. |
| **2 — Training** | Fill in gradient clearing, forward pass, loss, backpropagation, optimizer update, class prediction, and batch accuracy. Reach at least 95% rolling training accuracy. |
| **3 — Representation similarity** | Explain image-by-image Pearson correlation, construct RDMs from similarity, and investigate one alternative similarity metric for the report. |
| **4 — RDM comparison** | Compute pairwise Spearman scores for the RDMs of `l1`, `l2`, `l3`, `l4`, and `y`; identify the strongest pair of distinct layers. |

The preferred-stimulus search is omitted. Only the first supplementary plotting cell from the reference is retained and adapted; the new RDM-comparison exercise follows it.

### Training criterion

The target is **95% mean training accuracy over the most recent 100 mini-batches**, with 16 images per batch. Accuracy is computed from each training step's logits before that step's parameter update. The loop checks every 100 steps. Approximately 500–1,000 optimizer steps are expected, but this is not a guarantee across implementations and environments. One step is one mini-batch, not one epoch.

The default learning rate is 0.003 with Adam; the loop has a 2,000-step cap. If it misses the target, check your code and learning curve before increasing the cap. Re-running the training cell starts a new model. Training accuracy is not held-out test accuracy.

### How to read the RSA experiment

- The analysis uses **100 fixed test images, 10 per digit**, in digit-label order. All layers and all metrics use the same image identities and order, with the same trained weights.
- Each flattened activity matrix has shape **N images × P features**. With NumPy's default row-wise convention, `np.corrcoef(new_val)` compares the response vectors of two images within one layer, producing an **N × N** similarity matrix. It does not compare neurons or different layers.
- For Pearson and cosine, the RDM is `1 - similarity`. These dissimilarities can range from 0 to 2. Constant response vectors make Pearson undefined; zero vectors make cosine undefined. Inspect such cases rather than silently replacing invalid values.
- Spearman compares two layers' RDMs using corresponding **upper-triangle entries, excluding the diagonal**. There are 4,950 unique pairs for 100 images. Find the largest signed correlation among distinct layer pairs; exclude self-correlations and report all tied maxima.
- The supplementary percentile plots show **50 images, five per digit**, for display only. The Spearman analysis uses the full, raw 100-image RDMs. Ties receive equal average ranks in the percentile plots.
- A high Spearman score means similar ordering of image-pair dissimilarities, not identical activations or distances. The lab uses scores descriptively; the ordinary Spearman p-value is not a valid RSA significance test for dependent RDM entries.

### An alternative metric

The report extension supplies a scaffold for **cosine similarity**. You may use another justified alternative to Pearson, but merely changing the function used to compute Pearson does not count.

## Report and submission

Submit the completed, executed notebook and a **separate PDF report**. The report must include:

1. **Context:** image dimensions and channels, the first FC input-size calculation, seed, training steps, final rolling accuracy, and RSA image selection/order.
2. **Exercise 3:** RDM results for all five layers using Pearson and **one alternative similarity metric**; metric definitions, similarity-to-dissimilarity conversions, labeled figures, and a discussion of the observed differences. Different metrics' color scales are not interchangeable units.
3. **Exercise 4:** the 5 × 5 Spearman score matrix for the Pearson-based RDMs; the names and numerical score of the **most strongly correlated pair of distinct layers**; how duplicate pairs and self-comparisons were excluded; and an interpretation of the score. Report all tied maxima. Alternative-metric RSA matrices are generated for an optional robustness discussion.

Report your measured results; do not assume adjacent layers must have the largest score. Include the actual figures in the report, not only paths to files. Do not submit the MNIST dataset.

Each run creates a new `outputs/w4_vision_<timestamp>/` folder containing training plots/history, model weights, selected test indices and features, RDM arrays, RDM figures, layer-correlation CSVs/figures, and a `run_summary.json` with settings, software versions, and strongest pairs. These artifacts support the report; they do not replace it. The original `figures/` directory is not overwritten.

## References

- [Yang & Wang: Artificial Neural Networks for Neuroscientists: A Primer](https://doi.org/10.1016/j.neuron.2020.09.005)
- [Kriegeskorte et al.: Representational Similarity Analysis](https://doi.org/10.3389/neuro.06.004.2008)
- [NumPy corrcoef](https://numpy.org/doc/stable/reference/generated/numpy.corrcoef.html)
- [SciPy spearmanr](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.spearmanr.html)
