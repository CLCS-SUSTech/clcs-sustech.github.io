# 第 4 周实验：视觉、卷积神经网络与 RSA

[English instructions](README_en.md)

本次实验使用新的 **[lab_ConvNets_RSA.ipynb](lab_ConvNets_RSA.ipynb)**。学生版 notebook 使用英文，包含练习 0–4 和明确标记的 `TODO(...)` 填空。提交完成的 notebook，以及一份讨论练习 3、4 结果的**独立 PDF 报告**。

## 文件说明

| 文件 | 用途 |
|---|---|
| `lab_ConvNets_RSA.ipynb` | 新版学生练习，从这里开始。 |
| `ConvNets_origin.ipynb` | 主要参考 notebook。 |
| `ANN-Primer_2020.pdf` | 神经网络和 RSA 的背景阅读材料。 |
| `lab_ConvNets.ipynb`、`lab_ConvNets_sol.ipynb` | 保留的上学期材料，不是本次作业或其答案。 |

## 环境与启动

需要安装 PyTorch、torchvision、NumPy、Matplotlib、SciPy 和 JupyterLab，使用 CPU 即可。在本文件夹中，可按以下方式创建环境并启动：

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install torch torchvision numpy matplotlib scipy jupyterlab
python -m jupyterlab lab_ConvNets_RSA.ipynb
```

Windows 用户将激活命令换为 `.venv\Scripts\activate`。也可以使用已安装上述依赖的课程环境；请在 Jupyter 中选择对应的 Python 内核。Scikit-learn 不是必需依赖，cosine similarity 可以直接用 NumPy 实现；选择使用其 `cosine_similarity` 函数时，再安装 `scikit-learn`。

请将 notebook 的工作目录保持为 `lab_w4_vision`。如果 `./MNIST/` 下没有数据，数据加载单元会自动下载，首次运行需要联网；已有数据会直接复用。

将每个 `TODO(...)` 表达式替换为自己的实现，并补充文字回答。未填写的占位符会主动抛出 `NotImplementedError`，这是预期行为。完成后，重启内核并按顺序运行所有单元；尚未填写的学生模板不能直接运行到底。

## 练习安排

| 练习 | 任务 |
|---|---|
| **0 — MNIST** | 观察单张图片的高和宽各是多少像素，以及通道数、批次张量维度和类别标签。 |
| **1 — ConvNet** | 补全两个卷积层和三个全连接层。卷积输出通道分别为 6、16，均使用 3 × 3 卷积核和 padding=1；每层卷积后依次经过 ReLU 和 2 × 2 最大池化。计算第一个全连接层的输入尺寸，两个隐藏全连接层输出分别为 120、84。补全 forward；readout 分支已完整提供。 |
| **2 — 训练** | 补全梯度清零、前向传播、损失计算、反向传播、参数更新、类别预测和批次准确率，达到至少 95% 的滚动训练准确率。 |
| **3 — 表征相似度** | 解释图片响应之间的 Pearson 相关，计算从 similarity 到 dissimilarity 的 RDM，并为报告尝试另外一种相似度指标。 |
| **4 — RDM 比较** | 对 `l1`、`l2`、`l3`、`l4`、`y` 的 RDM 两两计算 Spearman 相关，找出相关性最高的一对不同表征层。 |

不包含 preferred-stimulus 搜索。原参考 notebook 的 Supplementary materials 只保留并改写第一个绘图单元，随后加入新的 RDM 比较练习。

### 训练目标的含义

目标为**最近 100 个 mini-batch 的平均训练准确率达到 95%**，每批 16 张图片。每步准确率根据该步参数更新前算出的 logits 计算。程序每 100 步检查一次，预计约需 500–1,000 次优化器更新，但不同实现和运行环境可能有所变化。一步是一个 mini-batch，不是一个 epoch。

默认使用 Adam，学习率为 0.003，最多运行 2,000 步。未达到目标时，应先检查代码和学习曲线，再决定是否提高步数上限。重新运行训练单元会从新模型开始训练。这里的训练准确率不等于独立测试集上的准确率。

### RSA 实验中比较的是什么

- 固定选取 **100 张测试图片，每个数字 10 张**，按数字标签排序。所有表征层、所有指标使用同一批图片、同一图片顺序和同一个训练好的模型。
- 展平后的响应矩阵为 **N 张图片 × P 个特征**。`np.corrcoef(new_val)` 默认按行计算，比较同一层中两张图片各自引发的响应向量，输出 **N × N** 的相似度矩阵。它不是神经元之间的相关，也还不是不同层之间的相关。
- 对 Pearson 和 cosine，使用 `RDM = 1 - similarity`，可能的差异度范围为 0–2。常数响应向量的 Pearson 相关没有定义，零向量的 cosine 没有定义；遇到这些情况应检查原因，不应将无效值直接替换成零。
- 层间 Spearman 比较提取两张 RDM 对应的**上三角元素，不含对角线**。100 张图片对应 4,950 个不重复图片对。寻找不同层之间数值最大的相关系数，不取绝对值，不计入自相关；并列最大时全部报告。
- 补充绘图只显示 **50 张图片，每类 5 张**，颜色表示差异度的百分位秩，仅用于展示；Spearman 计算仍使用完整 100 张图片的原始 RDM。相同差异度在绘图中使用相同的平均秩。
- Spearman 高分表示两层对图片对差异程度的排序相似，不表示激活值或距离数值相同。本实验作描述性比较；RDM 元素之间存在依赖，不能将常规 Spearman p 值直接当作有效的 RSA 显著性检验。

### 一种替代指标

报告扩展部分提供 **cosine similarity** 的填空框架。也可选择一种有明确依据的其他指标，但仅换一个函数计算 Pearson 不算新指标。

## 报告与提交

提交完成且保留运行结果的 notebook，以及一份**独立 PDF 报告**。报告至少包括：

1. **实验背景：** 图片长宽和通道数、第一个全连接层输入尺寸的计算、随机种子、训练步数、最终滚动训练准确率，以及 RSA 图片的选取和排序方式。
2. **练习 3：** Pearson 基线和**另外一种相似度指标**下，全部五个表征层的 RDM 结果；各指标定义、相似度到差异度的转换、标明坐标和色标的图，以及观察到的异同。不同指标的颜色尺度不能当作相同单位直接比较。
3. **练习 4：** 基于 Pearson RDM 得到的 5 × 5 Spearman 得分矩阵；**相关性最高的两个不同表征层的名称及其数值**；如何排除重复图片对和自比较；如何解读结果。并列最大时全部报告。程序也会生成替代指标的层间 RSA 矩阵，可用于可选的稳健性讨论。

应报告实际运行结果，不预设相邻层一定最高。请将具体图表放入报告，不要只给出文件夹路径。不需要提交下载的 MNIST 数据。

每次运行会创建新的 `outputs/w4_vision_<时间戳>/` 文件夹，保存训练图和记录、模型权重、所选测试图片索引和特征、RDM 数组和图、层间相关 CSV 和图，以及记录参数、软件版本和最强层对的 `run_summary.json`。这些文件用于支持报告，不能代替报告。原有 `figures/` 目录不会被覆盖。

## 参考资料

- [Yang & Wang: Artificial Neural Networks for Neuroscientists: A Primer](https://doi.org/10.1016/j.neuron.2020.09.005)
- [Kriegeskorte 等：Representational Similarity Analysis](https://doi.org/10.3389/neuro.06.004.2008)
- [NumPy corrcoef](https://numpy.org/doc/stable/reference/generated/numpy.corrcoef.html)
- [SciPy spearmanr](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.spearmanr.html)
