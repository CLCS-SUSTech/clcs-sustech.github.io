# 第 4 周实验：视觉、卷积神经网络与表征相似性

[English instructions](README_en.md)

使用 **[lab_w4_ConvNets.ipynb](lab_w4_ConvNets.ipynb)** 在 MNIST 上构建并训练卷积神经网络，再比较各层如何表征同一批图片。答案版为 [lab_w4_ConvNets_sol.ipynb](lab_w4_ConvNets_sol.ipynb)。

## 环境与启动

需要安装 PyTorch、torchvision、NumPy、Matplotlib、SciPy 和 Jupyter，使用 CPU 即可。在本文件夹中，可按以下方式创建环境并启动：

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install torch torchvision numpy matplotlib scipy jupyterlab
python -m jupyterlab lab_w4_ConvNets.ipynb
```

Windows 用户将激活命令换为 `.venv\Scripts\activate`。也可以使用已安装上述依赖的环境，并选择对应的 Python 内核。Scikit-learn 为可选依赖，仅在选择其 `cosine_similarity` 实现时需要安装。

请从 notebook 所在文件夹运行。程序会按需将 MNIST 下载到 `./MNIST/`，后续运行复用已有数据。每次执行 setup 单元都会创建新的 `outputs/w4_vision_<时间戳>/` 文件夹，用于保存运行结果。

补全每个 `TODO(...)` 表达式，可通过 `### START YOUR CODE ###` / `### END YOUR CODE ###` 注释定位已标记的作答区域，并填写文字观察。未完成的占位符会抛出 `NotImplementedError`。报告扩展部分的 cosine similarity 占位符也需要完成。按顺序运行各单元；完成后，重启内核并运行所有单元，作为最终检查。

## 练习安排

| 练习 | 任务 |
|---|---|
| **0 — 观察 MNIST** | 记录图片的像素高宽、通道数、批次张量各维度的含义及输出类别数。 |
| **1 — 定义 ConvNet** | 补全两个卷积层、三个全连接层及前向传播。两个卷积层均使用 3 × 3 卷积核、stride=1、padding=1，随后接 ReLU 和 2 × 2 最大池化。计算 FC 1 输入尺寸及各阶段的张量形状。 |
| **2 — 训练网络** | 补全梯度清零、前向传播、损失计算、反向传播、参数更新、类别预测和批次准确率，达到至少 95% 的滚动训练准确率。 |
| **3 — 计算表征相似度** | 使用已提供的图片间 Pearson 相似度，实现 `RDM = 1 - similarity`。在报告扩展部分实现并探究另外一种相似度指标，例如 cosine。 |
| **4 — 比较 RDM** | 分别基于 Pearson 和替代指标的 RDM，对 `l1`、`l2`、`l3`、`l4`、`y` 计算对称的 5 × 5 Spearman 得分矩阵。在每个矩阵中找出相关性最高的一对不同表征层并给出得分，并列最大时全部报告。 |

### 训练目标

目标为**最近 100 个 mini-batch 的平均训练准确率至少达到 95%**，每批 16 张图片。用于判断停止的准确率由该步参数更新前的 logits 计算。通常约需 **800–1,500 次优化器更新**，具体取决于初始化和软件环境；一步对应一个 mini-batch，不是一个 epoch。

程序每 100 步检查一次，最多运行 2,000 步。未达到目标时，应先检查实现和学习曲线，再决定是否提高步数上限。重新运行训练单元会初始化新模型。此处的训练指标不代表独立测试集准确率。

### 表征分析

固定使用 **100 张测试图片，每个数字 10 张**，按数字标签排序。所有层和指标都必须使用同一批图片、相同顺序和已训练好的网络。

展平后的响应矩阵形状为 **N 张图片 × P 个特征**。`np.corrcoef(new_val)` 比较同一层中的图片响应行，产生 **N × N** 的相似度矩阵。Pearson 对应的 `RDM = 1 - similarity` 取值范围为 0–2。常数响应向量会导致相关系数无定义，提供的检查会在此时停止运行。

比较两层时，提取对应 RDM 的**上三角元素，不含对角线**：100 张图片对应 4,950 个不重复图片对。在不同层的配对中寻找带符号数值最大的得分，不取绝对值。Spearman 得分接近 1 表示两层对哪些图片对相对相似或相异的判断一致。

对替代指标，说明其公式、含义及转换为差异度的方法。提供的框架采用 cosine similarity，它不会减去各响应向量的均值。仅换一个软件函数计算 Pearson 不算新指标。

## 提交要求

提交：

1. 完成的 `.ipynb`，所有代码按顺序执行，并保留相关输出。
2. 一份讨论练习 3、4 的**独立 PDF 报告**。Notebook 不能代替报告。

报告必须包含：

- **练习 3：** Pearson 基线和**另外一种相似度指标**（例如 cosine）下全部五个表征层的 RDM 结果。简要说明相似度矩阵中的一个元素衡量什么。
- **练习 4：** 展示**分别基于 Pearson 和替代相似度指标（例如 cosine）的 RDM** 得到的 5 × 5 Spearman 得分矩阵。针对每个矩阵，给出**相关性最高的两个不同表征层的名称及其数值**；并列最大时全部列出，不要预设相邻层一定最高。

使用自己运行得到的图和数值。**不要提交下载的 MNIST 数据集。**
