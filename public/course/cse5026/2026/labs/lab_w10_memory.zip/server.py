#!/usr/bin/env python3
"""Local, dependency-free server for the Week 10 Sperling teaching experiment."""
import argparse
import json
import os
from pathlib import Path
import re
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import tempfile
import webbrowser

ROOT = Path(__file__).resolve().parent


def make_handler(data_dir):
    class Handler(SimpleHTTPRequestHandler):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, directory=str(ROOT / "web"), **kwargs)

        def end_headers(self):
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            super().end_headers()

        def reply(self, code, value):
            body = json.dumps(value, ensure_ascii=False).encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_POST(self):
            if self.path != "/api/session":
                return self.reply(404, {"error": "Unknown endpoint"})
            # Same-origin writes only; the server binds to loopback by default.
            origin = self.headers.get("Origin")
            if origin and origin != "http://" + self.headers.get("Host", ""):
                return self.reply(403, {"error": "Cross-origin request rejected"})
            try:
                size = int(self.headers.get("Content-Length", "0"))
                if not 0 < size <= 2_000_000:
                    return self.reply(413, {"error": "Invalid payload size"})
                session = json.loads(self.rfile.read(size))
                sid = session.get("id", "")
                if not re.fullmatch(r"[a-f0-9-]{36}", sid):
                    raise ValueError("Invalid session ID")
                if not isinstance(session.get("records"), list):
                    raise ValueError("Missing records")
                data_dir.mkdir(parents=True, exist_ok=True)
                target = data_dir / (sid + ".json")
                # Replace an entire snapshot atomically, including interrupted trials.
                with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=data_dir,
                                                 delete=False, suffix=".tmp") as f:
                    tmp = f.name
                    json.dump(session, f, ensure_ascii=False, indent=2)
                os.replace(tmp, target)
                self.reply(200, {"saved": True, "file": target.name})
            except (ValueError, TypeError, AttributeError, json.JSONDecodeError) as exc:
                self.reply(400, {"error": str(exc)})
            except OSError:
                self.reply(500, {"error": "Cannot save data; export JSON in the browser"})

    return Handler


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=8010)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--data-dir", type=Path, default=ROOT / "data")
    args = parser.parse_args()
    server = ThreadingHTTPServer((args.host, args.port), make_handler(args.data_dir.resolve()))
    url = "http://{}:{}/".format(args.host, server.server_port)
    print("Week 10 · Sperling memory lab\n{}\nData: {}\nCtrl+C to stop".format(
        url, args.data_dir.resolve()), flush=True)
    if not args.no_browser:
        webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
