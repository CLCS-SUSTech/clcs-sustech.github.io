(function (root) {
  "use strict";
  const LETTERS = "BCDFGHJKLMNPQRSTVWXYZ";
  function rng(seed) {
    return function () {
      let t = seed += 0x6D2B79F5;
      t = Math.imul(t ^ t >>> 15, t | 1);
      t ^= t + Math.imul(t ^ t >>> 7, t | 61);
      return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
  }
  function shuffle(items, random) {
    const out = [...items];
    for (let i = out.length - 1; i > 0; i--) {
      const j = Math.floor(random() * (i + 1));
      [out[i], out[j]] = [out[j], out[i]];
    }
    return out;
  }
  function makePlan(count, first, seed) {
    const random = rng(seed);
    const order = first === "random" ? (random() < .5 ? ["whole", "partial"] : ["partial", "whole"])
      : (first === "whole" ? ["whole", "partial"] : ["partial", "whole"]);
    const plan = [];
    for (const phase of ["practice", "main"]) {
      for (const condition of order) {
        const n = phase === "practice" ? 3 : count;
        const rows = shuffle(Array.from({length: n}, (_, i) => i % 3), random);
        for (let i = 0; i < n; i++) {
          plan.push({phase, condition, block_trial: i + 1,
            target_row: condition === "partial" ? rows[i] : null,
            letters: Array.from({length: 9}, () => LETTERS[Math.floor(random() * LETTERS.length)])});
        }
      }
    }
    return {order, plan};
  }
  function score(trial, response) {
    const target = trial.condition === "whole" ? trial.letters
      : trial.letters.slice(trial.target_row * 3, trial.target_row * 3 + 3);
    const correct = target.reduce((n, c, i) => n + (c === (response[i] || "").toUpperCase()), 0);
    return {correct, total: target.length, accuracy: correct / target.length,
      estimated_available: trial.condition === "partial" ? correct * 3 : correct};
  }
  function summarize(records) {
    return ["whole", "partial"].map(condition => {
      const rs = records.filter(r => r.phase === "main" && r.condition === condition && !r.invalid);
      const n = rs.length;
      const mean = field => n ? rs.reduce((s, r) => s + r[field], 0) / n : null;
      return {condition, trials: n, mean_correct: mean("correct"), accuracy: mean("accuracy"),
        estimated_available: mean("estimated_available")};
    });
  }
  const fields = ["session_id", "participant", "seed", "condition_order", "attempt", "phase", "condition",
    "block_trial", "target_row", "tone_hz", "letters", "response", "correct", "total", "accuracy",
    "estimated_available", "invalid", "invalid_reason", "timing_flag", "requested_ms", "frames",
    "frame_period_ms", "stimulus_font_px", "fixation_ready_wait_ms", "ready_to_stimulus_ms", "observed_ms", "max_frame_interval_ms", "cue_call_delay_ms",
    "audio_context_time_s", "audio_base_latency_s", "audio_output_latency_s", "response_ms", "timestamp"];
  function csv(session) {
    const quote = value => {
      let s = value == null ? "" : Array.isArray(value) ? value.map(x => x || "_").join(" ") : String(value);
      if (/^[=+@-]/.test(s)) s = "'" + s;
      return '"' + s.replaceAll('"', '""') + '"';
    };
    return "\uFEFF" + [fields.join(","), ...session.records.map(r => {
      const row = {...r, session_id: session.id, participant: session.participant, seed: session.seed,
        condition_order: session.order.join(" → ")};
      return fields.map(f => quote(row[f])).join(",");
    })].join("\r\n");
  }
  const api = {LETTERS, rng, makePlan, score, summarize, csv};
  if (typeof module !== "undefined") module.exports = api;
  else root.MemoryCore = api;
})(typeof window === "undefined" ? globalThis : window);
