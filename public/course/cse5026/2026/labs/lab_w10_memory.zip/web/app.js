"use strict";
const $ = id => document.getElementById(id);
const Core = window.MemoryCore;
const STORAGE = "cse5026-sperling-v2";
const EXPOSURE_MS = 100;
const STIMULUS_FONT_PX = 60;
const HZ = [2500, 650, 250];
const ROWS = ["top", "middle", "bottom"];
const NAMES = {whole: "Whole report", partial: "Partial report"};
let session = null, current = null, running = false, mode = "setup";
let audio = null, tone = null, framePeriod = null, frameSamples = [], refreshStable = false;
let frameId = 0, timer = 0, responseStart = 0, busy = false;
let confirmFixation = null;
let saveChain = Promise.resolve(), calibrationBusy = false;

function show(id) {
  mode = id;
  for (const view of document.querySelectorAll(".view")) view.hidden = view.id !== id;
  document.body.classList.toggle("responding", id === "response");
  $("stage").hidden = true;
  window.scrollTo(0, 0);
}
function message(text) {
  $("error").textContent = text;
  $("error").hidden = false;
  setTimeout(() => { $("error").hidden = true; }, 7000);
}
function persist() {
  if (!session) return;
  session.updated_at = new Date().toISOString();
  const payload = JSON.stringify(session);
  try {
    localStorage.setItem(STORAGE, payload);
    $("save-status").textContent = "Saved in browser · Syncing local file…";
  } catch (_) {
    $("save-status").textContent = "Browser storage unavailable; export your data now";
  }
  // Serialize requests so an older snapshot cannot overwrite a newer one.
  saveChain = saveChain.then(async () => {
    try {
      const r = await fetch("/api/session", {method: "POST", headers: {"Content-Type": "application/json"}, body: payload});
      if (!r.ok) throw new Error("save");
      $("save-status").textContent = "Saved in browser and local data folder";
    } catch (_) {
      $("save-status").textContent = "Local file sync failed; export CSV / JSON";
    }
  });
}
async function initAudio() {
  const Audio = window.AudioContext || window.webkitAudioContext;
  if (!Audio) throw new Error("Web Audio is unavailable. Use desktop Chrome, Edge, or Firefox.");
  if (!audio) audio = new Audio({latencyHint: "interactive"});
  await audio.resume();
  if (audio.state !== "running") throw new Error("Audio is not active. Click a tone to try again.");
}
function prepareTone(row) {
  const oscillator = audio.createOscillator(), gain = audio.createGain();
  oscillator.type = "sine";
  oscillator.frequency.value = HZ[row];
  oscillator.connect(gain); gain.connect(audio.destination);
  return {oscillator, gain};
}
function startTone(node) {
  const when = audio.currentTime;
  node.gain.gain.setValueAtTime(0, when);
  node.gain.gain.linearRampToValueAtTime(.12, when + .008);
  node.gain.gain.setValueAtTime(.12, when + .49);
  node.gain.gain.linearRampToValueAtTime(0, when + .5);
  node.oscillator.start(when); node.oscillator.stop(when + .5);
  node.oscillator.onended = () => { node.oscillator.disconnect(); node.gain.disconnect(); };
  return when;
}
function stopTone() {
  if (tone) { try { tone.oscillator.stop(); } catch (_) {} tone = null; }
}
async function calibrate() {
  if (calibrationBusy) return;
  calibrationBusy = true;
  $("begin").disabled = true;
  $("calibration").textContent = "Measuring display refresh interval. Keep this window in the foreground…";
  try {
    const times = await new Promise(resolve => {
      const out = [];
      function sample(t) {
        out.push(t);
        if (out.length < 91) requestAnimationFrame(sample); else resolve(out);
      }
      requestAnimationFrame(sample);
    });
    frameSamples = times.slice(11).map((t, i) => t - times[i + 10]);
    const sorted = [...frameSamples].sort((a, b) => a - b);
    framePeriod = sorted[Math.floor(sorted.length / 2)];
    refreshStable = framePeriod >= 3 && framePeriod <= 25 && frameSamples.filter(x => Math.abs(x - framePeriod) > framePeriod * .2).length <= 4;
    const frames = Math.max(1, Math.round(EXPOSURE_MS / framePeriod));
    const estimated = frames * framePeriod;
    $("calibration").textContent = `Measured ${(1000 / framePeriod).toFixed(1)} Hz; ${frames} frames ≈ ${estimated.toFixed(1)} ms.` +
      (refreshStable ? "" : " Refresh timing is unstable. Close background tasks or use a fixed-refresh display, then measure again.");
    if (Math.abs(estimated - EXPOSURE_MS) > 3) $("calibration").textContent += " This refresh rate cannot produce exactly 100 ms. The approximate duration is recorded in your data.";
    if (!refreshStable) {
      const retry = document.createElement("button");
      retry.textContent = "Measure again"; retry.type = "button";
      retry.onclick = calibrate; $("calibration").append(" ", retry);
    }
  } finally {
    calibrationBusy = false;
    $("begin").disabled = !refreshStable || !$("sound-confirm").checked;
  }
}
$("sound-confirm").onchange = () => { $("begin").disabled = !refreshStable || !$("sound-confirm").checked; };
for (const b of document.querySelectorAll("[data-tone]")) b.onclick = async () => {
  try { await initAudio(); stopTone(); tone = prepareTone(Number(b.dataset.tone)); startTone(tone); }
  catch (e) { message(e.message); }
};

$("setup-form").onsubmit = async event => {
  event.preventDefault();
  if (busy) return;
  if (session && !confirm("A new session will replace the current browser record. Export it first. Continue?")) return;
  busy = true;
  try {
    await initAudio();
    const seed = crypto.getRandomValues(new Uint32Array(1))[0];
    const count = Number($("count").value);
    const generated = Core.makePlan(count, $("order").value, seed);
    session = {version: 2, id: crypto.randomUUID(), participant: $("participant").value.trim(),
      seed, count, order: generated.order, plan: generated.plan, index: 0, records: [], pending: null,
      created_at: new Date().toISOString(), status: "in_progress", requested_ms: EXPOSURE_MS,
      user_agent: navigator.userAgent, display: {width: screen.width, height: screen.height, dpr: devicePixelRatio},
      protocol: "3x3 consonants with replacement; self-paced fixation then 500ms delay; frame-based 100ms; immediate auditory partial report; 500ms blank before response"};
    $("export-anytime").hidden = false;
    persist(); show("prepare"); calibrate();
  } catch (e) { message(e.message); }
  finally { busy = false; }
};
$("begin").onclick = async () => {
  try {
    await initAudio(); stopTone();
    session.frame_period_ms = framePeriod;
    session.frame_intervals_ms = frameSamples;
    await enterFullscreen();
    persist(); next();
  } catch (e) { message(e.message); }
};
async function enterFullscreen() {
  try { if (!document.fullscreenElement && document.documentElement.requestFullscreen) await document.documentElement.requestFullscreen(); }
  catch (_) { /* Fullscreen is optional; a denied request must not prevent the task. */ }
}
$("fullscreen").onclick = enterFullscreen;
function next() {
  if (session.index >= session.plan.length) {
    session.status = "complete"; persist(); results(); return;
  }
  const trial = session.plan[session.index];
  show("between");
  $("block-label").textContent = trial.phase === "practice" ? "PRACTICE" : "MAIN EXPERIMENT";
  $("block-title").textContent = NAMES[trial.condition];
  $("block-instructions").textContent = trial.condition === "whole"
    ? "Remember the letters and their positions. After the display disappears, fill in the entire array."
    : "Listen when the letters disappear: high tone = top row, medium = middle row, low = bottom row.";
  $("block-count").textContent = `Trial ${trial.block_trial} / ${trial.phase === "practice" ? 3 : session.count} in this block`;
  $("next-trial").focus();
}
function canvasSetup() {
  const canvas = $("stimulus");
  canvas.width = Math.round(innerWidth * devicePixelRatio);
  canvas.height = Math.round(innerHeight * devicePixelRatio);
  const ctx = canvas.getContext("2d");
  ctx.scale(devicePixelRatio, devicePixelRatio);
  return ctx;
}
function clearCanvas(ctx) { ctx.fillStyle = "#111"; ctx.fillRect(0, 0, innerWidth, innerHeight); }
async function startTrial() {
  if (mode !== "between" || busy) return;
  busy = true;
  try {
    await initAudio(); stopTone();
    const trial = session.plan[session.index];
    const frames = Math.max(1, Math.round(EXPOSURE_MS / framePeriod));
    current = {...trial, letters: [...trial.letters], attempt: session.records.length + 1,
      timestamp: new Date().toISOString(), requested_ms: EXPOSURE_MS, frames,
      frame_period_ms: framePeriod, stimulus_font_px: STIMULUS_FONT_PX,
      tone_hz: trial.condition === "partial" ? HZ[trial.target_row] : null,
      audio_base_latency_s: audio.baseLatency ?? null, audio_output_latency_s: audio.outputLatency ?? null};
    session.pending = current; persist();
    if (trial.condition === "partial") tone = prepareTone(trial.target_row);
    const ctx = canvasSetup();
    show("stage"); $("stage").hidden = false; mode = "fixation"; running = true;
    clearCanvas(ctx); ctx.fillStyle = "#eee"; ctx.font = "28px monospace";
    ctx.textAlign = "center"; ctx.textBaseline = "middle"; ctx.fillText("+", innerWidth / 2, innerHeight / 2);
    const fixationShown = performance.now();
    ctx.fillStyle = "#aaa"; ctx.font = "16px system-ui";
    ctx.fillText("Fixate on +. Press Space when ready.", innerWidth / 2, innerHeight - 65);
    let readyAt = null, onset = null, previous = null, count = 0, maxInterval = 0;
    function tick(t) {
      if (!running) return;
      if (t - readyAt < 500) { frameId = requestAnimationFrame(tick); return; }
      if (onset === null) {
        clearCanvas(ctx);
        ctx.fillStyle = "#eee"; ctx.font = `500 ${STIMULUS_FONT_PX}px ui-monospace, Menlo, Consolas, monospace`;
        const spacingX = 88, spacingY = 76;
        trial.letters.forEach((c, i) => ctx.fillText(c, innerWidth / 2 + (i % 3 - 1) * spacingX,
          innerHeight / 2 + (Math.floor(i / 3) - 1) * spacingY));
        onset = t; previous = t; current.onset_raf_ms = t;
        current.ready_to_stimulus_ms = t - readyAt;
      } else {
        maxInterval = Math.max(maxInterval, t - previous); previous = t; count++;
        if (count >= frames) {
          clearCanvas(ctx);
          current.offset_raf_ms = t; current.observed_ms = t - onset;
          current.max_frame_interval_ms = maxInterval;
          current.timing_flag = maxInterval > framePeriod * 1.5 || Math.abs(current.observed_ms - EXPOSURE_MS) > 5;
          if (tone) {
            current.cue_call_delay_ms = performance.now() - t;
            current.audio_context_time_s = startTone(tone);
          }
          // Keep a uniform dark field during cueing; do not show a row label or response mask here.
          timer = setTimeout(responseScreen, 500);
          return;
        }
      }
      frameId = requestAnimationFrame(tick);
    }
    // Stay on fixation indefinitely. Only a fresh Space press starts the 500 ms delay.
    confirmFixation = () => {
      if (mode !== "fixation" || !running) return;
      confirmFixation = null; mode = "stage";
      readyAt = performance.now();
      current.fixation_ready_wait_ms = readyAt - fixationShown;
      clearCanvas(ctx); ctx.fillStyle = "#eee"; ctx.font = "28px monospace";
      ctx.fillText("+", innerWidth / 2, innerHeight / 2);
      frameId = requestAnimationFrame(tick);
    };
  } catch (e) { message(e.message); running = false; if (current) interrupt("An audio or display error interrupted the trial."); }
  finally { busy = false; }
}
$("next-trial").onclick = startTrial;
function responseScreen() {
  if (!running) return;
  show("response");
  $("response-phase").textContent = current.phase === "practice" ? "PRACTICE" : "MAIN EXPERIMENT";
  $("response-title").textContent = current.condition === "whole" ? "Fill in all nine positions" : "Fill in the row indicated by the tone";
  const grid = $("response-grid"); grid.replaceChildren();
  const n = current.condition === "whole" ? 9 : 3;
  for (let i = 0; i < n; i++) {
    const input = document.createElement("input");
    input.type = "text"; input.maxLength = 1; input.autocomplete = "off";
    input.spellcheck = false; input.autocapitalize = "characters";
    input.setAttribute("aria-label", `Row ${Math.floor(i / 3) + 1}, column ${i % 3 + 1}`);
    input.oninput = () => {
      input.value = input.value.replace(/[^a-z]/gi, "").toUpperCase();
      if (input.value && input.nextElementSibling) input.nextElementSibling.focus();
    };
    input.onkeydown = e => {
      let dest = i;
      if (e.key === "ArrowRight") dest++;
      else if (e.key === "ArrowLeft") dest--;
      else if (e.key === "ArrowUp") dest -= 3;
      else if (e.key === "ArrowDown") dest += 3;
      else if (e.key === "Backspace" && !input.value) dest--;
      else return;
      e.preventDefault(); if (grid.children[dest]) { grid.children[dest].focus(); grid.children[dest].select(); }
    };
    input.onfocus = () => input.select(); grid.append(input);
  }
  responseStart = performance.now(); grid.firstElementChild.focus();
}
$("response-form").onsubmit = event => {
  event.preventDefault(); if (mode !== "response" || !running) return;
  const response = [...$("response-grid").children].map(x => x.value.toUpperCase());
  if (response.every(x => !x) && !confirm("All positions are blank and will score zero. Submit?")) return;
  running = false; current.response = response; current.response_ms = performance.now() - responseStart;
  Object.assign(current, Core.score(current, response), {invalid: false});
  session.records.push(current); session.index++; session.pending = null; persist();
  if (current.phase === "practice") {
    show("feedback");
    $("feedback-title").textContent = `${current.correct} / ${current.total} letters correct`;
    $("feedback-note").textContent = current.condition === "partial" ? `The tone cued the ${ROWS[current.target_row]} row. Check that you know which row each tone indicates.` : "A letter scores only when both the letter and its position are correct.";
    const target = current.condition === "whole" ? current.letters : current.letters.slice(current.target_row * 3, current.target_row * 3 + 3);
    const format = xs => xs.map(x => x || "_").join(" ").replace(/((?:\S ){2}\S) /g, "$1\n");
    $("target-answer").textContent = format(target); $("your-answer").textContent = format(response);
  } else next();
};
$("feedback-next").onclick = next;
function interrupt(reason) {
  if (!running && !session?.pending) return;
  running = false; confirmFixation = null; cancelAnimationFrame(frameId); clearTimeout(timer); stopTone();
  const invalid = current || session.pending;
  if (invalid) session.records.push({...invalid, invalid: true, invalid_reason: reason});
  session.pending = null;
  // Avoid repeating an already viewed array after an interruption, preserving condition/row balance.
  const random = Core.rng(session.seed ^ Math.imul(session.records.length + 1, 2654435761));
  session.plan[session.index].letters = Array.from({length: 9}, () => Core.LETTERS[Math.floor(random() * Core.LETTERS.length)]);
  persist(); show("interrupted"); $("interrupt-reason").textContent = reason;
}
$("retry").onclick = () => { show("prepare"); $("sound-confirm").checked = false; calibrate(); };
document.addEventListener("visibilitychange", () => { if (document.hidden && running) interrupt("The tab was hidden or the window was minimized during the trial."); });
window.addEventListener("blur", () => { if (running) interrupt("The experiment window lost focus."); });
window.addEventListener("resize", () => { if (running) interrupt("The window was resized during the trial."); });
document.addEventListener("fullscreenchange", () => { if (running) interrupt("Fullscreen mode changed during the trial."); });
document.addEventListener("keydown", e => {
  if (e.key === "Escape" && running) { e.preventDefault(); interrupt("Escape was pressed to pause the trial."); }
  else if (e.code === "Space" && ["between", "fixation", "feedback"].includes(mode)) {
    e.preventDefault();
    if (e.repeat) return;
    if (mode === "feedback") next();
    else if (mode === "between") startTrial();
    else confirmFixation?.();
  }
});
function results() {
  show("results");
  const summary = Core.summarize(session.records), finished = session.status === "complete";
  $("results-title").textContent = finished ? "Seeing and reporting" : "Restored session";
  const flagged = session.records.filter(r => r.phase === "main" && !r.invalid && r.timing_flag).length;
  const invalid = session.records.filter(r => r.invalid).length;
  $("results-note").textContent = `${session.participant} · ${finished ? "Main experiment complete" : "Session incomplete"} · ${flagged} timing flags · ${invalid} interrupted attempts.`;
  $("summary").replaceChildren(); $("comparison").replaceChildren();
  const num = (n, digits = 2) => n === null ? "—" : n.toFixed(digits);
  for (const s of summary) {
    const tr = document.createElement("tr");
    for (const value of [NAMES[s.condition], s.trials, num(s.mean_correct), s.accuracy === null ? "—" : (s.accuracy * 100).toFixed(1) + "%", num(s.estimated_available)]) {
      const td = document.createElement("td"); td.textContent = value; tr.append(td);
    }
    $("summary").append(tr);
    const row = document.createElement("div"); row.className = "bar-row";
    const label = document.createElement("span"); label.textContent = NAMES[s.condition];
    const track = document.createElement("div"); track.className = "bar-track";
    const bar = document.createElement("div"); bar.className = "bar"; bar.style.width = `${(s.estimated_available || 0) / 9 * 100}%`; track.append(bar);
    const value = document.createElement("span"); value.textContent = num(s.estimated_available, 1);
    row.append(label, track, value); $("comparison").append(row);
  }
  if (!finished) {
    const button = document.createElement("button"); button.className = "primary"; button.textContent = "Check audio & resume experiment";
    button.onclick = async () => { try { await initAudio(); show("prepare"); calibrate(); } catch (e) { message(e.message); } };
    $("comparison").append(button);
  }
}
function download(type) {
  if (!session) return;
  const data = type === "csv" ? Core.csv(session) : JSON.stringify({...session, summary: Core.summarize(session.records)}, null, 2);
  const blob = new Blob([data], {type: type === "csv" ? "text/csv;charset=utf-8" : "application/json;charset=utf-8"});
  const a = document.createElement("a"); a.href = URL.createObjectURL(blob);
  a.download = `sperling_${session.id}.${type}`; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}
$("csv").onclick = () => download("csv"); $("json").onclick = () => download("json");
$("export-anytime").onclick = () => download("json");
$("new-session").onclick = () => { if (confirm("Export your current data first. Return to setup?")) { show("setup"); $("recovery").hidden = false; } };
let stored = null;
try { stored = JSON.parse(localStorage.getItem(STORAGE)); } catch (_) {}
if (stored && stored.version === 2 && Array.isArray(stored.plan) && Array.isArray(stored.records)) $("recovery").hidden = false;
$("resume").onclick = () => {
  try { stored = JSON.parse(localStorage.getItem(STORAGE)); } catch (_) {}
  if (!stored) { message("No saved session is available."); return; }
  session = stored; $("export-anytime").hidden = false;
  if (session.pending && session.index < session.plan.length) {
    current = session.pending; interrupt("The page was closed or refreshed during the previous trial.");
  } else results();
};
