# Lab w10: Iconic Memory

A classroom adaptation of Sperling’s (1960) whole-report and immediate partial-report tasks. Each trial presents a **3 × 3 consonant array for a target duration of 100 ms**, using a 60 px font.

## Start

Requires Python 3.9+ and a desktop browser. No additional packages are needed.

From the course repository root:

```bash
cd labs_2026/lab_w10_memory
python3 server.py
```

The browser opens at <http://127.0.0.1:8010/>. Press Ctrl+C in the terminal to stop the server. If the port is busy, use `python3 server.py --port 8011`.

## Run the experiment

1. Enter a participant ID, choose the trial count (24 per condition by default), and select the block order.
2. Learn the cues: **high tone → top row; medium tone → middle row; low tone → bottom row**.
3. Complete six practice trials, followed by two main blocks. Press Space or click **Continue** after practice feedback.
4. For **whole report**, enter all nine letters in their original positions. For **partial report**, enter only the three letters in the cued row. Leave uncertain positions blank; use arrow keys to move and Enter to submit.
5. Review the results and export CSV / JSON files.

Each trial: open the dark fixation screen → look at the central + until ready → press Space → wait 500 ms → letter array for 100 ms → dark screen for about 500 ms → response entry. Fixation stays visible until you press Space. In partial report, the tone is requested when the array disappears. Each row is cued equally often.

## Scoring and data

- A response scores only when both the letter and its position are correct. Partial-report estimated available letters = correct letters × 3.
- Results include main, uninterrupted trials only. Timing-flagged trials remain included; inspect them in the export.
- Sessions are saved automatically in the browser and in `data/<session ID>.json`. CSV includes every attempt; JSON also includes the stimulus plan and session details. Keep an exported copy.
- Key fields: `target_row` (0 = top, 1 = middle, 2 = bottom), `invalid` (interrupted attempt), `timing_flag` (timing irregularity), and `observed_ms` (software-recorded display duration). In CSV, `_` marks an unanswered position.
- Switching windows, resizing, or pressing Escape interrupts the current trial. It is repeated with a new array. After refreshing the page, choose **Restore session** to continue. Earlier 50 ms sessions are stored separately from this version.

## Individual analysis and short report

Use only your own data to answer: **Do my results show a partial-report advantage, and how large is it?**

1. **Filter the data:** retain trials with `phase = main` and `invalid = false`. Inspect `timing_flag`; if excluding timing-flagged trials, apply the same rule to both conditions and record the exclusions.
2. **Make one summary table:** for each condition, report valid trial count, mean position accuracy, mean estimated available letters, and median `response_ms`. Accuracy is correct letters ÷ 9 for whole report and ÷ 3 for partial report. Do not compare unscaled correct-letter counts directly.
3. **Calculate your advantage:** first calculate estimated available letters for each valid trial: `correct` for whole report and `correct × 3` for partial report (the exported `estimated_available` field). Average these values within each condition, then subtract the whole-report mean from the partial-report mean. For example, means of four correct letters in whole report and two in partial report give estimated available letters of four and six, respectively: an advantage of two letters.
4. **Make two figures:**
   - **Trial-by-trial accuracy:** use the trial number within the block (`block_trial`) on the horizontal axis and position accuracy for that trial (`accuracy`, optionally as a percentage) on the vertical axis. Each point represents one valid main trial. Use separate subplots for whole and partial report to inspect fluctuations or trends within each condition.
   - **Condition means:** use report condition on the horizontal axis and mean estimated available letters from step 3 (0–9) on the vertical axis, with one bar per condition.

## Timing

Use a fixed-refresh display and wired headphones, and keep the experiment in the foreground. The 100 ms exposure is approximated using whole display frames; the preparation screen shows the estimated duration. Browser timestamps do not measure physical screen–speaker synchronization. This version is intended for classroom use and has not been calibrated with external hardware.

## Checks and reference

```bash
node tests/test_core.cjs
python3 -m unittest discover -s tests -v
```

Sperling, G. (1960). *The information available in brief visual presentations.* [https://doi.org/10.1037/h0093759](https://doi.org/10.1037/h0093759)

This adaptation uses a 100 ms exposure and does not include delayed-cue conditions.
