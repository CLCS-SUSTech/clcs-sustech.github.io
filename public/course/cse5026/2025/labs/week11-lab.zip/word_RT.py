import pandas as pd
import re

# Load CSV
df = pd.read_csv("onestop_demo.csv")

# --- Extract full paragraph ---
paragraph = df["paragraph"].dropna().iloc[0]

# --- Step 2: Extract all words from paragraph ---
# Normalize punctuation spacing
words = re.findall(r"[A-Za-z]+(?:'[A-Za-z]+)?", paragraph)

# --- Step 4: Compute reading time per word in sentence order ---

# Get fixation rows
fix_df = df[
    df["CURRENT_FIX_INTEREST_AREA_LABEL"].notna() &
    (df["CURRENT_FIX_INTEREST_AREA_LABEL"] != ".") &
    df["CURRENT_FIX_DURATION"].notna()
].copy()

fix_df["CURRENT_FIX_DURATION"] = pd.to_numeric(fix_df["CURRENT_FIX_DURATION"], errors="coerce")

# Sum durations per labeled word
word_times = (
    fix_df.groupby("CURRENT_FIX_INTEREST_AREA_LABEL")["CURRENT_FIX_DURATION"]
    .sum()
    .to_dict()
)

# Construct ordered reading time list
reading_time_ordered = [(w, word_times.get(w, 0)) for w in words]

print(len(reading_time_ordered))
print(reading_time_ordered)
print(len([rt for rt in reading_time_ordered if rt[1] >0]))
