import json
import pandas as pd
import matplotlib.pyplot as plt
from scipy.stats import pearsonr, linregress

json_path = "/mnt/shared-storage-user/hantao-dispatch/wzb_test/paragraph_word_fixation_times.json"
surprisal_path = "/mnt/shared-storage-user/hantao-dispatch/wzb_test/surprisal_results.json"

with open(json_path, "r", encoding="utf-8") as f:
    paragraphs = json.load(f)

with open(surprisal_path, "r", encoding="utf-8") as f:
    surprisal_data = json.load(f)

for para_idx, para in enumerate(paragraphs):
    reading_times = para["reading_times"]

    surprisal_list = surprisal_data[para_idx]["word_surprisals"]

    df_rt = pd.DataFrame(reading_times, columns=["word", "fixation_time"])
    df_sp = pd.DataFrame(surprisal_list)[["word", "surprisal"]]

    df = df_rt.merge(df_sp, on="word", how="inner")

    pearson_r, p_value = pearsonr(df["surprisal"], df["fixation_time"])

    slope, intercept, _, _, _ = linregress(df["surprisal"], df["fixation_time"])
    line_x = df["surprisal"]
    line_y = slope * line_x + intercept

    plt.figure(figsize=(7, 6))
    plt.scatter(df["surprisal"], df["fixation_time"], alpha=0.7)
    plt.plot(line_x, line_y, color="black",
             label=f"Regression (r={pearson_r:.3f}, p={p_value:.3f})")

    plt.title(f"Paragraph {para_idx + 1}: Surprisal vs Fixation Time")
    plt.xlabel("Word Surprisal")
    plt.ylabel("Fixation Time (ms)")
    plt.legend()
    plt.grid(alpha=0.3)
    plt.tight_layout()
    plt.savefig(f"/mnt/shared-storage-user/hantao-dispatch/wzb_test/vis{para_idx + 1}.png", dpi=500)
