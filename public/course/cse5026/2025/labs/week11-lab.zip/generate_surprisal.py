import json
import re
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM



def load_paragraphs_from_json(json_path):
    with open(json_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    paragraphs = []
    for item in data:
        paragraphs.append(item["paragraph"])
    return paragraphs

def compute_token_surprisal(text):
    encoded = tokenizer(
        text, return_offsets_mapping=True, return_tensors="pt"
    )

    input_ids = encoded["input_ids"].to(model.device)
    offsets = encoded["offset_mapping"][0].tolist()
    tokens = input_ids[0]

    with torch.no_grad():
        outputs = model(input_ids)
        logits = outputs.logits    # shape = [1, T, vocab]
        log_probs = torch.log_softmax(logits, dim=-1)

    token_surprisals = []
    for t in range(len(tokens)):
        token_id = tokens[t].item()
        if t == 0:
            log_prob = log_probs[0, t, token_id].item()
        else:
            log_prob = log_probs[0, t - 1, token_id].item()  # p(token_t | context)
        surprisal = -log_prob
        token_surprisals.append({
            "token": tokenizer.decode([token_id]),
            "token_id": token_id,
            "start": offsets[t][0],
            "end": offsets[t][1],
            "surprisal": surprisal
        })
 
    return token_surprisals

def compute_word_surprisal(text, token_surprisals):
    words = []
    word_spans = []

    for match in re.finditer(r"\S+", text):
        w = match.group()
        start, end = match.span()
        words.append(w)
        word_spans.append((start, end))

    result = []
    token_idx = 0
    total_tokens = len(token_surprisals)

    for w, (start, end) in zip(words, word_spans):
        word_tokens = []
        word_surprisal = 0.0

        while token_idx < total_tokens:
            t_item = token_surprisals[token_idx]
            t_start = t_item["start"]
            t_end = t_item["end"]

            if t_end <= start:
                token_idx += 1
                continue
            if t_start >= end:
                break
         
            word_tokens.append(t_item["token"])
            word_surprisal += t_item["surprisal"]
            token_idx += 1
       
        result.append({
            "word": w,
            "surprisal": word_surprisal,
            "tokens": word_tokens
        })

    return result


if __name__ == "__main__":
    model_name = "/mnt/shared-storage-user/hantao-dispatch/wzb_test/Qwen3-0.6B-Base"
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModelForCausalLM.from_pretrained(
        model_name, torch_dtype=torch.float16, device_map="auto"
    )
    model.eval()

    json_path = "/mnt/shared-storage-user/hantao-dispatch/wzb_test/paragraph_word_fixation_times.json"
    paragraphs = load_paragraphs_from_json(json_path)

    all_results = []

    for idx, text in enumerate(paragraphs, start=1):
        token_surprisals = compute_token_surprisal(text)
        word_surprisals = compute_word_surprisal(text, token_surprisals)

        all_results.append({
            "paragraph_index": idx,
            "text": text,
            "word_surprisals": word_surprisals
        })

    output_path = "/mnt/shared-storage-user/hantao-dispatch/wzb_test/surprisal_results.json"
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(all_results, f, indent=2, ensure_ascii=False)