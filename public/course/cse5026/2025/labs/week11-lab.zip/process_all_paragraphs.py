import pandas as pd
import re
import json

# 设置最大处理段落数
max_paragraph_num = 10

# 加载CSV文件
print("正在加载CSV文件...")
df = pd.read_csv("onestop_raw.csv")

# 提取所有唯一的完整段落（非空段落）
print("正在提取唯一段落...")
unique_paragraphs = df["paragraph"].dropna().unique()
print(f"找到 {len(unique_paragraphs)} 个唯一段落")
print(f"将处理前 {min(max_paragraph_num, len(unique_paragraphs))} 个段落")

# 存储所有结果
all_results = []

# 对每个段落进行处理
for para_idx, paragraph in enumerate(unique_paragraphs[:max_paragraph_num], 1):
    print(f"\n处理段落 {para_idx}/{min(max_paragraph_num, len(unique_paragraphs))}")
    
    # 提取段落中的所有单词
    words = re.findall(r"[A-Za-z]+(?:'[A-Za-z]+)?", paragraph)
    
    # 过滤出该段落相关的数据行
    para_df = df[df["paragraph"] == paragraph].copy()
    
    # 获取该段落的注视数据
    fix_df = para_df[
        para_df["CURRENT_FIX_INTEREST_AREA_LABEL"].notna() &
        (para_df["CURRENT_FIX_INTEREST_AREA_LABEL"] != ".") &
        para_df["CURRENT_FIX_DURATION"].notna()
    ].copy()
    
    # 将注视持续时间转换为数值
    fix_df["CURRENT_FIX_DURATION"] = pd.to_numeric(
        fix_df["CURRENT_FIX_DURATION"], 
        errors="coerce"
    )
    
    # 按单词标签汇总注视时间
    word_times = (
        fix_df.groupby("CURRENT_FIX_INTEREST_AREA_LABEL")["CURRENT_FIX_DURATION"]
        .sum()
        .to_dict()
    )
    
    # 构建按顺序的阅读时间列表
    reading_time_ordered = [(w, word_times.get(w, 0)) for w in words]
    
    # 存储结果
    result = {
        "paragraph_index": para_idx,
        "paragraph": paragraph,
        "word_count": len(words),
        "words_with_fixations": len([rt for rt in reading_time_ordered if rt[1] > 0]),
        "reading_times": reading_time_ordered
    }
    
    all_results.append(result)
    
    print(f"  单词数: {len(words)}, 有注视数据的单词数: {result['words_with_fixations']}")

# 保存结果到JSON文件
output_file = "paragraph_word_fixation_times.json"
print(f"\n正在保存结果到 {output_file}...")

# 先生成标准JSON字符串
json_str = json.dumps(all_results, ensure_ascii=False, indent=2)

# 使用正则表达式将reading_times字段改为紧凑格式
def compact_reading_times(match):
    indent = match.group(1)  # 缩进（包括前面的换行和空格）
    items_str = match.group(2)  # 数组内容（包含所有嵌套的数组）
    
    # 提取所有 [word, number] 对，处理可能的多行格式
    items = re.findall(r'\[\s*"([^"]+)",\s*(\d+)\s*\]', items_str)
    # 重新格式化为紧凑格式
    compact_items = ', '.join([f'["{word}", {num}]' for word, num in items])
    
    return f'{indent}"reading_times": [{compact_items}]'

# 匹配模式：匹配从 "reading_times": [ 开始到对应的 ] 结束的整个字段
# 需要匹配嵌套的数组结构，使用更精确的模式
# 匹配格式: "reading_times": [\n      [\n        "word",\n        number\n      ], ... \n    ]
pattern = r'(\n\s+)"reading_times": \[\s*((?:\[\s*"[^"]+",\s*\d+\s*\](?:,\s*)?)+)\s*\]'
json_str = re.sub(pattern, compact_reading_times, json_str, flags=re.MULTILINE | re.DOTALL)

with open(output_file, "w", encoding="utf-8") as f:
    f.write(json_str)

# 统计总单词数
total_words = sum(len(result["reading_times"]) for result in all_results)

print(f"\n完成！")
print(f"- JSON格式结果已保存到: {output_file}")
print(f"- 总共处理了 {len(all_results)} 个段落")
print(f"- 总共提取了 {total_words} 个单词的注视时间数据")

