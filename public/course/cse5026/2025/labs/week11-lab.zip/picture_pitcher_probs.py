import torch
import numpy as np
from pathlib import Path
import matplotlib.pyplot as plt
from scipy.interpolate import interp1d

from qwen3 import (
    download_qwen3_small,
    Qwen3Tokenizer,
    Qwen3Model,
    QWEN_CONFIG_06_B
)
from ch02_ex import (
    generate_text_basic_stream_cache
)

def load_model_and_tokenizer(which_model, device, use_compile, local_dir="qwen3"):
    if which_model == "base":

        download_qwen3_small(
            kind="base", tokenizer_only=False, out_dir=local_dir
        )

        tokenizer_path = Path(local_dir) / "tokenizer-base.json"
        model_path = Path(local_dir) / "qwen3-0.6B-base.pth"
        tokenizer = Qwen3Tokenizer(tokenizer_file_path=tokenizer_path)

    elif which_model == "reasoning":

        download_qwen3_small(
            kind="reasoning", tokenizer_only=False, out_dir=local_dir
        )

        tokenizer_path = Path(local_dir) / "tokenizer-reasoning.json"
        model_path = Path(local_dir) / "qwen3-0.6B-reasoning.pth"
        tokenizer = Qwen3Tokenizer(
            tokenizer_file_path=tokenizer_path,
            apply_chat_template=True,
            add_generation_prompt=True,
            add_thinking=True,
        )

    else:
        raise ValueError(f"Invalid choice: which_model={which_model}")

    model = Qwen3Model(QWEN_CONFIG_06_B)
    model.load_state_dict(torch.load(model_path))

    model.to(device)

    if use_compile:
        torch._dynamo.config.allow_unspec_int_on_nn_module = True
        model = torch.compile(model)

    return model, tokenizer


def compute_word_probability(context, target_word, tokenizer, model, device):
    """
    Compute the probability of a target word given a context.
    
    Args:
        context: Context string
        target_word: Target word to compute probability for
        tokenizer: Qwen3Tokenizer instance
        model: Qwen3Model instance
        device: Device to run computation on
    
    Returns:
        probability: Probability value
        log_prob: Log probability
        surprisal: Surprisal value (-log_prob)
    """
    # Encode context
    context_ids = tokenizer.encode(context)
    
    # Encode full text (context + space + target word) to get proper tokenization
    # This ensures the target word is tokenized correctly with its leading space
    full_text = context + " " + target_word
    full_ids = tokenizer.encode(full_text)
    
    # Extract the target word tokens (everything after the context)
    target_ids = full_ids[len(context_ids):]
    
    # Convert context to tensor and move to device
    context_tensor = torch.tensor([context_ids], device=device)
    
    # Forward pass to get logits for the context
    with torch.no_grad():
        logits = model(context_tensor)  # shape = [1, T, vocab_size]
        
        # Get logits at the last position (for predicting next token)
        last_logits = logits[0, -1, :]  # shape = [vocab_size]
        log_probs = torch.log_softmax(last_logits, dim=-1)
    
    # Compute probability for the target word
    # If the word is split into multiple tokens, compute joint probability
    if len(target_ids) == 1:
        # Single token word
        token_id = target_ids[0]
        log_prob = log_probs[token_id].item()
        prob = np.exp(log_prob)
        surprisal = -log_prob
    else:
        # Multi-token word: compute step by step
        current_input = context_tensor
        total_log_prob = 0.0
        
        for i, token_id in enumerate(target_ids):
            with torch.no_grad():
                logits = model(current_input)
                last_logits = logits[0, -1, :]
                log_probs = torch.log_softmax(last_logits, dim=-1)
                log_prob = log_probs[token_id].item()
                total_log_prob += log_prob
                
                # Prepare input for next token
                if i < len(target_ids) - 1:
                    new_token = torch.tensor([[token_id]], device=device)
                    current_input = torch.cat([current_input, new_token], dim=1)
        
        prob = np.exp(total_log_prob)
        surprisal = -total_log_prob
        log_prob = total_log_prob
    
    return prob, log_prob, surprisal


def plot_histogram():
    """
    Plot the histogram of the top k words based on p(w|context).
    """
    context = "On the wall I see"
    k = 20
    output_file = "histogram.pdf"
    
    # Determine device (use CPU if CUDA is not available)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"Using device: {device}")
    
    # Load model and tokenizer
    model, tokenizer = load_model_and_tokenizer("base", device, use_compile=False)
    model.eval()
    
    # Encode context
    context_ids = tokenizer.encode(context)
    context_tensor = torch.tensor([context_ids], device=device)
    
    # Forward pass to get logits for the context
    with torch.no_grad():
        logits = model(context_tensor)  # shape = [1, T, vocab_size]
        
        # Get logits at the last position (for predicting next token)
        last_logits = logits[0, -1, :]  # shape = [vocab_size]
        log_probs = torch.log_softmax(last_logits, dim=-1)
        probs = torch.exp(log_probs)  # shape = [vocab_size]
    
    # Get top k token IDs by probability
    top_k_probs, top_k_indices = torch.topk(probs, k, dim=-1)
    
    # Convert to numpy for easier handling
    # Convert BFloat16 to float32 first before converting to numpy
    top_k_probs_np = top_k_probs.cpu().float().numpy()
    top_k_indices_np = top_k_indices.cpu().numpy()
    
    # Decode tokens to get word representations
    # Note: Some tokens might be parts of words, so we decode each token individually
    top_k_words = []
    for token_id in top_k_indices_np:
        decoded = tokenizer.decode([token_id])
        # Clean up the decoded token - handle empty strings and whitespace
        if not decoded or decoded.strip() == "":
            # If it's a space or empty, show it as a visible representation
            decoded = "<space>" if decoded == " " else f"<token_{token_id}>"
        # Remove leading/trailing whitespace for display
        decoded = decoded.strip()
        if not decoded:
            decoded = f"<token_{token_id}>"
        top_k_words.append(decoded)
    
    # Create the histogram with density curve
    fig, ax = plt.subplots(figsize=(12, 6))
    
    # Plot bars
    bars = ax.bar(range(k), top_k_probs_np, color='steelblue', edgecolor='black', alpha=0.7, label='Probability')
    
    # Add density curve using interpolation
    # Create smooth curve by interpolating the probability values
    x_original = np.arange(k)
    x_smooth = np.linspace(0, k-1, 200)
    
    # Use cubic interpolation for smooth curve
    f = interp1d(x_original, top_k_probs_np, kind='cubic', bounds_error=False, fill_value='extrapolate')
    density_smooth = f(x_smooth)
    
    # Plot density curve on the same axis
    ax.plot(x_smooth, density_smooth, 'r-', linewidth=2, alpha=0.7, label='Density Curve')
    
    # Customize the plot
    ax.set_xlabel('Top k Words', fontsize=12)
    ax.set_ylabel('Probability p(w|context)', fontsize=12)
    ax.set_title(f'Top {k} Word Probabilities for Context: "{context}"', fontsize=14, fontweight='bold')
    ax.set_xticks(range(k))
    ax.set_xticklabels(top_k_words, rotation=45, ha='right')
    ax.grid(axis='y', alpha=0.3, linestyle='--')
    
    # Add value labels on top of bars
    for i, (bar, prob) in enumerate(zip(bars, top_k_probs_np)):
        height = bar.get_height()
        ax.text(bar.get_x() + bar.get_width()/2., height,
                f'{prob:.4f}',
                ha='center', va='bottom', fontsize=9)
    
    # Add legend
    ax.legend(loc='upper right')
    
    plt.tight_layout()
    
    # Save the plot
    plt.savefig(output_file, format='pdf', dpi=300, bbox_inches='tight')
    print(f"\nHistogram saved to {output_file}")
    
    # Display the plot
    plt.show()
    
    # Calculate surprisal (-log(p)) for top k words
    top_k_surprisal_np = -np.log(top_k_probs_np + 1e-10)  # Add small epsilon to avoid log(0)
    
    # Create the surprisal histogram with density curve
    fig2, ax2 = plt.subplots(figsize=(12, 6))
    
    # Plot bars for surprisal
    bars2 = ax2.bar(range(k), top_k_surprisal_np, color='darkgreen', edgecolor='black', alpha=0.7, label='Surprisal')
    
    # Add density curve using interpolation
    x_original = np.arange(k)
    x_smooth = np.linspace(0, k-1, 200)
    
    # Use cubic interpolation for smooth curve
    f2 = interp1d(x_original, top_k_surprisal_np, kind='cubic', bounds_error=False, fill_value='extrapolate')
    density_smooth2 = f2(x_smooth)
    
    # Plot density curve on the same axis
    ax2.plot(x_smooth, density_smooth2, 'r-', linewidth=2, alpha=0.7, label='Density Curve')
    
    # Customize the plot
    ax2.set_xlabel('Top k Words', fontsize=12)
    ax2.set_ylabel('Surprisal -log(p(w|context))', fontsize=12)
    ax2.set_title(f'Top {k} Word Surprisal for Context: "{context}"', fontsize=14, fontweight='bold')
    ax2.set_xticks(range(k))
    ax2.set_xticklabels(top_k_words, rotation=45, ha='right')
    ax2.grid(axis='y', alpha=0.3, linestyle='--')
    
    # Add value labels on top of bars
    for i, (bar, surprisal) in enumerate(zip(bars2, top_k_surprisal_np)):
        height = bar.get_height()
        ax2.text(bar.get_x() + bar.get_width()/2., height,
                f'{surprisal:.4f}',
                ha='center', va='bottom', fontsize=9)
    
    # Add legend
    ax2.legend(loc='upper right')
    
    plt.tight_layout()
    
    # Save the surprisal plot
    surprisal_output_file = "histogram_surprisal.pdf"
    plt.savefig(surprisal_output_file, format='pdf', dpi=300, bbox_inches='tight')
    print(f"Surprisal histogram saved to {surprisal_output_file}")
    
    # Display the plot
    plt.show()
    
    # Print top k words and their probabilities
    print(f"\nTop {k} words and their probabilities:")
    print("=" * 60)
    for i, (word, prob) in enumerate(zip(top_k_words, top_k_probs_np), 1):
        print(f"{i:2d}. {word:20s} : {prob:.6f}")
    
    # Print top k words and their surprisal values
    print(f"\nTop {k} words and their surprisal values:")
    print("=" * 60)
    for i, (word, surprisal) in enumerate(zip(top_k_words, top_k_surprisal_np), 1):
        print(f"{i:2d}. {word:20s} : {surprisal:.6f}")
    
    # Calculate entropy for each top-k subset
    # For position k, entropy is computed using top k words
    top_k_entropy_np = np.zeros(k)
    for i in range(k):
        # Get probabilities of top (i+1) words
        subset_probs = top_k_probs_np[:i+1]
        # Normalize to sum to 1 (they should already be normalized, but ensure it)
        subset_probs_normalized = subset_probs / subset_probs.sum()
        # Calculate entropy: H = -sum(p_i * log(p_i))
        # For i=0 (first word), entropy equals surprisal
        if i == 0:
            top_k_entropy_np[i] = top_k_surprisal_np[i]
        else:
            entropy = -np.sum(subset_probs_normalized * np.log(subset_probs_normalized + 1e-10))
            top_k_entropy_np[i] = entropy
    
    # Create the entropy histogram with surprisal bars side by side
    fig3, ax3 = plt.subplots(figsize=(14, 6))
    
    # Set bar width and positions
    bar_width = 0.35
    x_pos = np.arange(k)
    
    # Plot bars for surprisal and entropy side by side
    bars_surprisal = ax3.bar(x_pos - bar_width/2, top_k_surprisal_np, bar_width, 
                             color='darkgreen', edgecolor='black', alpha=0.7, label='Surprisal')
    bars_entropy = ax3.bar(x_pos + bar_width/2, top_k_entropy_np, bar_width,
                           color='purple', edgecolor='black', alpha=0.7, label='Entropy')
    
    # Add density curves using interpolation for both surprisal and entropy
    x_original = np.arange(k)
    x_smooth = np.linspace(0, k-1, 200)
    
    # Use cubic interpolation for smooth curve (surprisal)
    f3_surprisal = interp1d(x_original, top_k_surprisal_np, kind='cubic', bounds_error=False, fill_value='extrapolate')
    density_smooth_surprisal = f3_surprisal(x_smooth)
    
    # Use cubic interpolation for smooth curve (entropy)
    f3_entropy = interp1d(x_original, top_k_entropy_np, kind='cubic', bounds_error=False, fill_value='extrapolate')
    density_smooth_entropy = f3_entropy(x_smooth)
    
    # Plot density curves on the same axis
    ax3.plot(x_smooth, density_smooth_surprisal, 'r-', linewidth=2, alpha=0.7, label='Density Curve (Surprisal)')
    ax3.plot(x_smooth, density_smooth_entropy, 'orange', linewidth=2, alpha=0.7, linestyle='--', label='Density Curve (Entropy)')
    
    # Customize the plot
    ax3.set_xlabel('Top k Words', fontsize=12)
    ax3.set_ylabel('Surprisal / Entropy', fontsize=12)
    ax3.set_title(f'Top {k} Word Surprisal and Entropy for Context: "{context}"', fontsize=14, fontweight='bold')
    ax3.set_xticks(x_pos)
    ax3.set_xticklabels(top_k_words, rotation=45, ha='right')
    ax3.grid(axis='y', alpha=0.3, linestyle='--')
    
    # Add value labels on top of bars
    for i, (bar_s, bar_e, surprisal, entropy) in enumerate(zip(bars_surprisal, bars_entropy, 
                                                                 top_k_surprisal_np, top_k_entropy_np)):
        # Label for surprisal bar
        height_s = bar_s.get_height()
        ax3.text(bar_s.get_x() + bar_s.get_width()/2., height_s,
                f'{surprisal:.4f}',
                ha='center', va='bottom', fontsize=8)
        # Label for entropy bar
        height_e = bar_e.get_height()
        ax3.text(bar_e.get_x() + bar_e.get_width()/2., height_e,
                f'{entropy:.4f}',
                ha='center', va='bottom', fontsize=8)
    
    # Add legend
    ax3.legend(loc='upper right')
    
    plt.tight_layout()
    
    # Save the entropy plot
    entropy_output_file = "histogram_entropy.pdf"
    plt.savefig(entropy_output_file, format='pdf', dpi=300, bbox_inches='tight')
    print(f"Entropy histogram saved to {entropy_output_file}")
    
    # Display the plot
    plt.show()
    
    # Print top k words and their entropy values
    print(f"\nTop {k} words and their entropy values (using top-k subset):")
    print("=" * 60)
    for i, (word, entropy) in enumerate(zip(top_k_words, top_k_entropy_np), 1):
        print(f"{i:2d}. {word:20s} : {entropy:.6f}")


def main():
    # Determine device (use CPU if CUDA is not available)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"Using device: {device}")
    
    # Load model and tokenizer
    model, tokenizer = load_model_and_tokenizer("base", device, use_compile=False)
    model.eval()
    
    # Context for comparison
    context = "On the wall I see a"
    
    # Words to compare
    words = ["picture", "pitcher"]
    
    print(f"\nContext: '{context}'")
    print("=" * 60)
    
    # Compute probabilities for both words
    results = []
    for word in words:
        prob, log_prob, surprisal = compute_word_probability(
            context, word, tokenizer, model, device
        )
        results.append({
            "word": word,
            "probability": prob,
            "log_probability": log_prob,
            "surprisal": surprisal
        })
        
        print(f"\nWord: '{word}'")
        print(f"  Probability: {prob:.6f}")
        print(f"  Log probability: {log_prob:.6f}")
        print(f"  Surprisal: {surprisal:.6f}")
    
    # Compare results
    print("\n" + "=" * 60)
    print("Comparison:")
    if results[0]["probability"] > results[1]["probability"]:
        print(f"'{results[0]['word']}' has higher probability")
        ratio = results[0]["probability"] / results[1]["probability"]
        print(f"Probability ratio: {ratio:.2f}:1")
    else:
        print(f"'{results[1]['word']}' has higher probability")
        ratio = results[1]["probability"] / results[0]["probability"]
        print(f"Probability ratio: {ratio:.2f}:1")


if __name__ == "__main__":
    # main()
    plot_histogram()
