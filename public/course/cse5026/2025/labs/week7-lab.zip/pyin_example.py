import librosa
import librosa.display
import matplotlib.pyplot as plt
import numpy as np

# Load an audio file
# y, sr = librosa.load(librosa.ex('trumpet'), sr=None)
y, sr = librosa.load('u_no_what_I_mean?.wav', sr=None)

# Estimate fundamental frequency (F0) using pYIN
# fmin and fmax define the range of frequencies to search for F0
f0, voiced_flag, voiced_probs = librosa.pyin(y=y, sr=sr, 
                                            fmin=65, fmax=2093)

# Visualize the F0 contour on top of a spectrogram
S = np.abs(librosa.stft(y))
times = librosa.times_like(S, sr=sr)

fig, ax = plt.subplots(figsize=(10, 4))
librosa.display.specshow(librosa.amplitude_to_db(S, ref=np.max), 
                         y_axis='log', x_axis='time', ax=ax)
ax.plot(times, f0, linewidth=2, color='white', label='F0 contour')
ax.legend()
ax.set(title='Spectrogram with pYIN F0 Contour')
plt.savefig('pyin_example.png', dpi=300, bbox_inches='tight')
plt.show()

# You can also analyze the voicing information
print(f"Number of voiced frames: {np.sum(voiced_flag)}")
print(f"Number of unvoiced frames: {len(voiced_flag) - np.sum(voiced_flag)}")