import sys
import librosa
import numpy as np
import matplotlib.pyplot as plt


def extract_f0_amplitude(audio_path, method='pyin', hop_length=512, n_fft=2048, fmin=65, fmax=2093):
    """
    Extract F0 and its amplitude using 'pyin' method only.
    
    Args:
        audio_path (str): Path to audio file.
        method (str): 'pyin' only.
        hop_length (int): Samples between frames.
        n_fft (int): FFT window size (for amplitude extraction).
        fmin (float): Minimum frequency (Hz).
        fmax (float): Maximum frequency (Hz).
    
    Returns:
        f0 (np.ndarray): F0 values over time.
        f0_amplitude (np.ndarray): Amplitude of F0 over time.
        sr (int): Sample rate.
        times (np.ndarray): Time stamps.
    """
    # Load audio
    y, sr = librosa.load(audio_path, sr=None)
    
    # Estimate F0 using selected method
    if method == 'pyin':
        # Use librosa's PYIN algorithm (more robust for complex signals)
        ##########################
        # TODO: Call librosa.pyin to obtain F0
        f0, _, _ = librosa.pyin(
            y,
            fmin=fmin,
            fmax=fmax,
            sr=sr,
            hop_length=hop_length
        )
        ##########################
    else:
        raise ValueError("Method must be 'pyin' only.")
    
    # Compute STFT for amplitude extraction
    stft = librosa.stft(y, n_fft=n_fft, hop_length=hop_length)
    stft_amplitude = np.abs(stft)
    freq_bins = librosa.fft_frequencies(sr=sr, n_fft=n_fft) # It contains the frequencies to search over
    
    # Extract amplitude corresponding to F0
    n_frames = len(f0)
    f0_amplitude = np.zeros(n_frames)
    for t in range(n_frames):
        current_f0 = f0[t]
        if np.isnan(current_f0):
            f0_amplitude[t] = 0.0
        else:
            #########################
            # TODO: Find the closest frequency bin to the current F0
            closest_bin = np.argmin(np.abs(freq_bins - current_f0))
            f0_amplitude[t] = stft_amplitude[closest_bin, t]
            #########################
    # Time stamps
    times = librosa.times_like(f0, sr=sr, hop_length=hop_length)
    
    return f0, f0_amplitude, sr, times


# Example Usage
if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python f0_pyin.py <audio_path>")
        sys.exit(1)
    audio_path = sys.argv[1]  # Replace with your audio path
    
    # Extract using 'pyin' method 
    f0, amp, sr, times = extract_f0_amplitude(audio_path, method='pyin')
    
    # Plot results
    plt.figure(figsize=(14, 8))
    
    # Plot F0 
    plt.subplot(2, 1, 1)
    plt.plot(times, f0, label='PYIN F0', color='blue', alpha=0.7)
    plt.ylabel('Frequency (Hz)')
    plt.title('F0 Estimation Comparison')
    plt.legend()
    
    # Plot Amplitude 
    plt.subplot(2, 1, 2)
    plt.plot(times, amp, label='PYIN F0 Amplitude', color='red', alpha=0.7)
    plt.xlabel('Time (s)')
    plt.ylabel('Amplitude')
    plt.legend()
    
    plt.tight_layout()
    
    # Save the plot to a file before showing
    plt.savefig('f0.png', dpi=300, bbox_inches='tight')
    plt.show()