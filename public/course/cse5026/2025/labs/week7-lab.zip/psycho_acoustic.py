# Imports and constants
import numpy as np
import matplotlib.pyplot as plt
from IPython.display import Audio, display
from IPython.display import clear_output

plt.rcParams['figure.dpi'] = 140
SR = 48000  # sample rate
DUR = 2.0   # seconds



def pure_tone(f, amp=1.0):
    t = np.linspace(0, DUR, int(SR*DUR), endpoint=False)
    return amp * np.sin(2 * np.pi * f * t)

def add_tones(t1, t2):
    s = t1 + t2
    s = s / max(np.max(np.abs(s)), 1e-12)
    return s
def two_tones(f_mean, delta_f, amp1=1.0, amp2=1.0):
    f1 = f_mean - delta_f / 2
    f2 = f_mean + delta_f / 2
    t1 = pure_tone(f1, amp1)
    t2 = pure_tone(f2, amp2)
    s = add_tones(t1, t2)
    return s, t1, t2
def play(x, sr=SR):
    clear_output(wait=True)
    return Audio(x, rate=sr)

def plot_waveform(x, sr=SR, dur=1.0, title='Waveform', xlabel='Time (s)', ylabel='Amplitude'):
    x = x[:int(dur*sr)]
    t = np.arange(len(x)) / sr
    plt.figure(figsize=(8, 2.4))
    plt.plot(t, x)
    plt.title(title)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.xlim(t[0], t[-1])
    plt.grid(True, ls=':')
    plt.show()

def plot_spectrum(x, sr=SR, title='Spectrum', xlabel='Frequency (Hz)', ylabel='Magnitude (dB)'):
    # Hann window + zero-pad to next power of two for cleaner spectrum
    n = len(x)
    N = 1
    while N < n:
        N <<= 1
    w = np.hanning(n)
    X = np.fft.rfft(w * x, n=N)
    f = np.fft.rfftfreq(N, d=1/sr)
    mag = 20 * np.log10(np.maximum(np.abs(X), 1e-12))
    plt.figure(figsize=(8, 2.6))
    plt.semilogx(f, mag)
    plt.title(title)
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    plt.xlim(20, sr/2)
    plt.ylim(np.max(mag)-80, np.max(mag)+5)
    plt.grid(True, which='both', ls=':')
    plt.show()

for df, label in [(2, 'Beats (Δf=2 Hz)'), (20, 'Roughness (Δf=20 Hz)'), (100, 'Smooth (Δf=100 Hz)')]:
    mixed, t1, t2 = two_tones(f_mean=500, delta_f=df)
    plot_waveform(mixed, dur=0.2, title=f'500 Hz ± {df/2:.1f} Hz — {label}')
    display(play(mixed))

try:
    import ipywidgets as W
    from IPython.display import clear_output
    def ui_player(f_mean=500, delta_f=5):
        clear_output(wait=True)
        mixed,_,_ = two_tones(f_mean=f_mean, delta_f=delta_f)
        # plot_waveform(mixed, dur=0.2, title=f'Mixed Waveform ({f_mean} Hz ± {delta_f/2:.1f} Hz)')
        display(play(mixed))

    ui = W.interactive(ui_player,
            f_mean=W.FloatLogSlider(value=500, base=10, min=2, max=4.2, step=0.01, description='f (Hz)'),
            delta_f=W.FloatLogSlider(value=5, base=10, min=0, max=3.5, step=0.01, description='Δf (Hz)'),
            )
    display(ui)
except Exception as e:
    print('ipywidgets not available:', e)

# Sample listener data (replace):
f_meas = np.array([125, 250, 500, 1000, 2000, 4000, 8000], float)
cbw_obs = np.array([  40,  50,  80,    130,   240,   480,  1000], float)  # Hz
cbw_obs = np.maximum(cbw_obs, 1e-6)
print('Δf/f (sample):', np.round(cbw_obs/f_meas, 3))

from numpy.linalg import lstsq

def fit_cbw_power(f, cbw):
    f = f.astype(float)
    y = cbw.astype(float)
    # initial p via log-log after offset
    y_shift = y
    p_init, c = np.polyfit(np.log(f), np.log(y_shift), 1)
    # linear solve for a,b with fixed p
    def solve_ab(p):
        X = np.c_[np.ones_like(f), f**p]
        a, b = lstsq(X, y, rcond=None)[0]
        return a, b
    a, b = solve_ab(p_init)
    # small grid refine on p
    Ps = np.linspace(p_init-0.6, p_init+0.6, 49)
    best = (np.inf, a, b, p_init)
    for p in Ps:
        a_, b_ = solve_ab(p)
        pred = a_ + b_*(f**p)
        # weight by 1/y to balance low/high freqs
        w = 1/np.maximum(y, 1e-6)
        err = np.sqrt(np.mean(w*(pred - y)**2))
        if err < best[0]:
            best = (err, a_, b_, p)
    err, a, b, p = best
    return a, b, p, (lambda x: a + b*(x**p))

def cbw_ref_zwicker_like(f):
    f = np.asarray(f, float)
    return 24.7 * (4.37 * f / 1000 + 1)

a, b, p, CBW = fit_cbw_power(f_meas, cbw_obs)
f_grid = np.logspace(np.log10(80), np.log10(16000), 400)
plt.figure()
plt.xscale('log')
plt.plot(f_meas, cbw_obs, 'o', label='Observed')
plt.plot(f_grid, CBW(f_grid), '-', label=f'Fit: a={a:.1f}, b={b:.3f}, p={p:.2f}')
plt.plot(f_grid, cbw_ref_zwicker_like(f_grid), '--', label='Classic ref (Zwicker-like)')
plt.xlabel('Frequency f (Hz) [log]')
plt.ylabel('CBW(f) (Hz)')
plt.title('Critical Bandwidth: fit vs reference')
plt.grid(True, which='both', ls=':')
plt.legend()
plt.show()

import numpy as np
import matplotlib.pyplot as plt

# 你给定的函数（此处按你的定义使用）
def dissonance_pure(f1, f2, cbw_func):
    fm = 0.5*(f1 + f2)
    x = np.abs(f2 - f1) / max(cbw_func(fm), 1e-9)
    return np.exp(-3.5*x) - np.exp(-5.75*x)

def find_extrema(x, y):

    y = np.asarray(y)
    dy = np.diff(y)
    # 符号变化：dy[i-1] > 0 且 dy[i] < 0 -> 局部极大 at i
    #            dy[i-1] < 0 且 dy[i] > 0 -> 局部极小 at i
    sign = np.sign(dy)
    # 防抖：把 0 变成邻近非零符号（简化处理）
    for i in range(1, len(sign)-1):
        if sign[i] == 0:
            sign[i] = sign[i-1] if sign[i-1] != 0 else sign[i+1]
    peaks = np.where((sign[:-1] > 0) & (sign[1:] < 0))[0] + 1
    troughs = np.where((sign[:-1] < 0) & (sign[1:] > 0))[0] + 1
    return peaks, troughs

def plot_dissonance_vs_delta(fm=500.0, CBW=None, n=400, span=4.0, mark_extrema=True):
    
    cbw = CBW(fm)
    deltas = np.linspace(0, span*cbw, n)
    D = [dissonance_pure(fm - d/2, fm + d/2, CBW) for d in deltas]

    plt.figure(figsize=(6,4))
    plt.plot(deltas, D, label='D(|Δf|)')
    plt.xlabel('|f2 - f1| (Hz)')
    plt.ylabel('Dissonance D')
    plt.title(f'Dissonace vs |Δf| at fm={fm:.0f} Hz')

    # 标注 Δf = CBW(fm)
    plt.axvline(cbw, color='tab:orange', ls='--', lw=1.5, label=f'Δf = CBW({fm:.0f})')

    if mark_extrema:
        peaks, troughs = find_extrema(deltas, D)
        if len(peaks):
            plt.scatter(deltas[peaks], np.array(D)[peaks], c='tab:red', s=30, zorder=3, label='local maxima')
        if len(troughs):
            plt.scatter(deltas[troughs], np.array(D)[troughs], c='tab:green', s=30, zorder=3, label='local minima')

        # 可选：标注第一个极大值与极小值（常用关注点）
        if len(peaks):
            i = peaks[0]
            plt.annotate(f'peak\nΔf={deltas[i]:.2f}\nD={D[i]:.3f}',
                         (deltas[i], D[i]),
                         textcoords='offset points', xytext=(8,8),
                         fontsize=9)
        if len(troughs):
            i = troughs[0]
            plt.annotate(f'min\nΔf={deltas[i]:.2f}\nD={D[i]:.3f}',
                         (deltas[i], D[i]),
                         textcoords='offset points', xytext=(8,-14),
                         fontsize=9)

    plt.grid(True, ls=':')
    plt.legend(frameon=False)
    plt.tight_layout()
    plt.show()

# 示例：使用你的 CBW 函数名 CBW
# 假设已定义 CBW(f)
plot_dissonance_vs_delta(fm=500.0, CBW=CBW, n=400, span=4.0)

# electronic tone
def elec_tone(f, k=10, amp=1.0):
    t = np.linspace(0, DUR, int(SR*DUR), endpoint=False)
    x = np.zeros_like(t)
    for n in range(1, k+1):
        x += (amp / (n**2)) * np.sin(2 * np.pi * n * f * t)
    # 归一化
    x = x / max(np.max(np.abs(x)), 1e-12)
    return x

display(play(elec_tone(220.0, k=10)))

import numpy as np
import matplotlib.pyplot as plt

def find_extrema(x, y):
    y = np.asarray(y)
    dy = np.diff(y)
    sign = np.sign(dy)
    # 处理平台：把 0 用邻近非零符号补齐
    for i in range(1, len(sign)-1):
        if sign[i] == 0:
            sign[i] = sign[i-1] if sign[i-1] != 0 else sign[i+1]
    peaks = np.where((sign[:-1] > 0) & (sign[1:] < 0))[0] + 1
    troughs = np.where((sign[:-1] < 0) & (sign[1:] > 0))[0] + 1
    return peaks, troughs

def dissonance_complex(f1, f2, K=10, cbw_func=None):
    if cbw_func is None:
        cbw_func = CBW
    Dsum = 0.0
    for k in range(1, K+1):
        for m in range(1, K+1):
            a_k = 1.0/(k*k)
            a_m = 1.0/(m*m)
            fk = k*f1
            fm = m*f2
            fmid = 0.5*(fk+fm)
            x = abs(fm - fk) / max(cbw_func(fmid), 1e-9)
            Dij = (np.exp(-3.5*x) - np.exp(-5.75*x)) * np.sqrt(a_k*a_m)
            Dsum += max(Dij, 0.0)
    return Dsum

def plot_complex_dissonance_with_extrema(f1=220.0, rmin=1.0, rmax=2.0, N=300, K=10, CBW_func=None,
                                         annotate=True, print_all=True):
    if CBW_func is None:
        CBW_func = CBW

    ratios = np.linspace(rmin, rmax, N)
    Dcurve = np.array([dissonance_complex(f1, f1*r, K=K, cbw_func=CBW_func) for r in ratios])

    # 极值
    peaks, troughs = find_extrema(ratios, Dcurve)

    # 打印所有极大/极小
    if print_all:
        print('Local maxima (index, ratio, D):')
        for i in peaks:
            print(f'  {i:4d}  {ratios[i]:.6f}  {Dcurve[i]:.6f}')
        print('Local minima (index, ratio, D):')
        for i in troughs:
            print(f'  {i:4d}  {ratios[i]:.6f}  {Dcurve[i]:.6f}')

    # 绘图与标注
    plt.figure(figsize=(6,4))
    plt.plot(ratios, Dcurve, label='Dissonance')
    if len(peaks):
        plt.scatter(ratios[peaks], Dcurve[peaks], c='tab:red', s=28, zorder=3, label='local maxima')
    if len(troughs):
        plt.scatter(ratios[troughs], Dcurve[troughs], c='tab:green', s=28, zorder=3, label='local minima')

    if annotate:
        if len(peaks):
            for i in peaks:
                plt.annotate(f'peak r={ratios[i]:.3f}\nD={Dcurve[i]:.3f}',
                            (ratios[i], Dcurve[i]), textcoords='offset points', xytext=(8,8), fontsize=9)
        if len(troughs):
            for i in troughs:
                plt.annotate(f'min r={ratios[i]:.3f}\nD={Dcurve[i]:.3f}',
                            (ratios[i], Dcurve[i]), textcoords='offset points', xytext=(8,-14), fontsize=9)

    plt.xlabel('Frequency ratio (f2/f1)')
    plt.ylabel('Harmonic dissonance (arb.)')
    plt.title(f'Electronic tone dissonance vs ratio (K={K}, 1/k^2)')
    plt.grid(True, ls=':')
    plt.legend(frameon=False)
    plt.tight_layout()
    plt.show()

# 示例（假设已定义 CBW、SR、DUR）
plot_complex_dissonance_with_extrema(f1=220.0, rmin=1.0, rmax=2.0, N=300, K=10, CBW_func=CBW, print_all=True, annotate=False)    

x1 = elec_tone(220.0, k=10, amp=0.5)
x2 = elec_tone(220*1.5, k=10, amp=0.5)
x = add_tones(x1, x2)
plot_spectrum(x, SR)
display(play(x))
