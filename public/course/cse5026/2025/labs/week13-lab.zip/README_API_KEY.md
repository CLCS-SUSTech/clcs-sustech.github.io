# API 密钥配置说明

为了安全地使用 OpenAI API，请通过环境变量设置你的 API 密钥，而不是直接在代码中硬编码。

## 设置方法

### 方法 1：在终端中设置（推荐）

**macOS/Linux:**
```bash
export OPENAI_API_KEY="your-api-key-here"
```

**Windows (PowerShell):**
```powershell
$env:OPENAI_API_KEY="your-api-key-here"
```

**Windows (CMD):**
```cmd
set OPENAI_API_KEY=your-api-key-here
```

### 方法 2：在 shell 配置文件中永久设置

**macOS/Linux (bash/zsh):**
编辑 `~/.bashrc` 或 `~/.zshrc`，添加：
```bash
export OPENAI_API_KEY="your-api-key-here"
```
然后运行 `source ~/.bashrc` 或 `source ~/.zshrc`

**macOS/Linux (fish shell):**
编辑 `~/.config/fish/config.fish`，添加：
```fish
set -gx OPENAI_API_KEY "your-api-key-here"
```

### 方法 3：使用 .env 文件（需要安装 python-dotenv）

1. 安装 python-dotenv：
```bash
pip install python-dotenv
```

2. 在 `lab_w13` 目录下创建 `.env` 文件：
```
OPENAI_API_KEY=your-api-key-here
```

3. 在代码中添加加载 .env 文件的代码（在导入部分）：
```python
from dotenv import load_dotenv
load_dotenv()
```

## 验证设置

运行以下命令验证环境变量是否设置成功：

**macOS/Linux:**
```bash
echo $OPENAI_API_KEY
```

**Windows (PowerShell):**
```powershell
echo $env:OPENAI_API_KEY
```

## 安全提示

⚠️ **重要：**
- 永远不要将包含 API 密钥的代码提交到版本控制系统（如 Git）
- `.env` 文件已添加到 `.gitignore`，不会被意外提交
- 如果 API 密钥泄露，请立即在 OpenAI 官网撤销并重新生成

