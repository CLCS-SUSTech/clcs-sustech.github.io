# -*- coding: utf-8 -*-
"""
《认知科学前沿与导论》实验课作业
CSE5026 Introduction and Frontiers of Cognitive Science
主题：观察大语言模型 (LLMs) 在人类判断与决策任务上的表现
作者：南方科技大学计算机系
日期：2025年秋季学期
"""

from openai import OpenAI  # 以OpenAI API为例，可替换为其他LLM API（如Anthropic、通义千问等）
import pandas as pd
from datetime import datetime
import json
import os

# --------------------------
# 实验配置（学生需根据实际情况修改）
# --------------------------
# 1. 配置LLM API（以OpenAI为例，其他模型请参考对应API文档）
# 从环境变量读取API密钥（推荐方式，更安全）
# 设置方法：
#   - 在终端运行：export OPENAI_API_KEY="your-api-key-here"
#   - 或在 .env 文件中设置（需要安装 python-dotenv 包）
API_KEY = os.getenv("OPENAI_API_KEY")

# 如果环境变量未设置，提供友好的提示
if not API_KEY:
    print("=" * 60)
    print("警告：未找到 OPENAI_API_KEY 环境变量！")
    print("=" * 60)
    print("\n请通过以下方式之一设置 API 密钥：")
    print("\n方法1（推荐）：在终端设置环境变量")
    print("  export OPENAI_API_KEY='your-api-key-here'")
    print("\n方法2：在代码中临时设置（仅用于测试，不推荐用于生产环境）")
    print("  取消下面代码的注释并填入你的 API 密钥：")
    print("  # API_KEY = 'your-api-key-here'")
    print("\n注意：请勿将包含 API 密钥的代码提交到版本控制系统！")
    print("=" * 60)
    raise ValueError("请先设置 OPENAI_API_KEY 环境变量后再运行程序")

MODEL_NAME = "gpt-4o-mini"  # 可选择gpt-3.5-turbo、claude-3-haiku等模型
TEMPERATURE = 0.3  # 控制随机性，0-1之间，越低越稳定

# 初始化OpenAI客户端（新版API需要）
client = OpenAI(api_key=API_KEY)

# 2. 实验参数
EXPERIMENT_ID = f"LLM-DM-Experiment-{datetime.now().strftime('%Y%m%d%H%M%S')}"

# --------------------------
# 实验任务设计（基于课程PPT核心概念）
# 包含：代表性启发式、框架效应、基础概率忽略、风险偏好四个经典决策任务
# --------------------------
decision_tasks = [
    {
        "task_id": 1,
        "task_type": "代表性启发式",
        "task_description": "基于人物特征判断职业概率（PPT第13页案例改编）",
        "task_text": """一个由100人组成的群体中，70人是律师，30人是工程师。随机抽取一人，其描述如下：
"杰克，45岁，已婚，有3个孩子。他性格保守，做事谨慎，对政治不感兴趣，大部分业余时间用于做木工、航海和解决数学难题。"
请判断杰克是工程师的概率属于以下哪个范围？
A. 0%-30%
B. 31%-50%
C. 51%-70%
D. 71%-100%""",
        "options": ["A", "B", "C", "D"],
        "key_concept": "代表性启发式：人们倾向于依据事物与典型特征的契合度判断概率，忽略基础概率"
    },
    {
        "task_id": 2,
        "task_type": "框架效应（收益框架）",
        "task_description": "收益描述下的风险偏好选择（PPT第14页框架①改编）",
        "task_text": """一种罕见疾病即将爆发，预计会导致600人死亡。现有两种治疗方案可供选择：
方案A：肯定能拯救200人；
方案B：有1/3的概率拯救600人，有2/3的概率无人获救。
你会选择哪种方案？
A. 方案A
B. 方案B""",
        "options": ["A", "B"],
        "key_concept": "框架效应：收益框架下人们倾向于风险规避"
    },
    {
        "task_id": 3,
        "task_type": "框架效应（损失框架）",
        "task_description": "损失描述下的风险偏好选择（PPT第14页框架②改编）",
        "task_text": """一种罕见疾病即将爆发，预计会导致600人死亡。现有两种治疗方案可供选择：
方案C：肯定会导致400人死亡；
方案D：有1/3的概率无人死亡，有2/3的概率导致600人死亡。
你会选择哪种方案？
A. 方案C
B. 方案D""",
        "options": ["A", "B"],
        "key_concept": "框架效应：损失框架下人们倾向于风险寻求"
    },
    {
        "task_id": 4,
        "task_type": "基础概率忽略",
        "task_description": "忽略群体分布的概率判断（PPT第13页拓展）",
        "task_text": """某城市有两家出租车公司：甲公司的出租车占全市总量的85%，颜色为蓝色；乙公司的出租车占15%，颜色为绿色。
一天晚上发生了一起交通事故，目击者声称肇事出租车是绿色的。警方测试了该目击者在夜间识别出租车颜色的能力，结果显示：
当出租车实际是绿色时，目击者能正确识别的概率为80%；当出租车实际是蓝色时，目击者误判为绿色的概率为20%。
请问肇事出租车实际是绿色的概率最接近以下哪个选项？
A. 15%
B. 41%
C. 60%
D. 80%""",
        "options": ["A", "B", "C", "D"],
        "key_concept": "基础概率忽略：人们易过度关注具体证据（目击者准确率），忽略先验概率（出租车数量分布）"
    },
    {
        "task_id": 5,
        "task_type": "合取谬误",
        "task_description": "对事件概率的直觉判断（PPT启发式拓展）",
        "task_text": """琳达，31岁，单身，性格外向，聪明伶俐。她大学期间主修哲学，非常关注社会公平和环境保护问题，曾参与多次公益游行。
请判断以下哪个选项的概率更高？
A. 琳达是一名银行出纳员
B. 琳达是一名银行出纳员，并且积极参与环保活动""",
        "options": ["A", "B"],
        "key_concept": "合取谬误：人们倾向于认为两个事件同时发生的概率高于单个事件，违背概率公理"
    }
]

# --------------------------
# 工具函数：调用LLM获取响应
# --------------------------
def get_llm_response(task_text, model_name=MODEL_NAME, temperature=TEMPERATURE):
    """
    调用LLM API获取对决策任务的响应
    参数：
        task_text: 决策任务文本
        model_name: 模型名称
        temperature: 随机性参数
    返回：
        response: LLM的完整响应文本
    """
    try:
        # 构建提示词（明确要求LLM选择选项并简要说明理由）
        prompt = f"""请仔细阅读以下决策问题，从提供的选项中选择一个你认为最合理的答案，并简要说明选择理由（不超过50字）。
问题：{task_text}
要求：1. 先明确给出选项（如"A"、"B"等）；2. 再简要说明理由。"""
        
        # 调用OpenAI API（新版API调用方式）
        response = client.chat.completions.create(
            model=model_name,
            messages=[{"role": "user", "content": prompt}],
            temperature=temperature,
            timeout=30
        )
        
        return response.choices[0].message.content.strip()
    
    except Exception as e:
        print(f"调用LLM失败：{str(e)}")
        return f"Error: {str(e)}"

# --------------------------
# 实验执行：批量运行所有任务并记录结果
# --------------------------
def run_experiment(tasks):
    """
    执行所有决策任务，记录LLM响应结果
    参数：
        tasks: 决策任务列表
    返回：
        experiment_results: 包含所有任务结果的列表
    """
    experiment_results = []
    
    print(f"===== 开始实验：{EXPERIMENT_ID} =====")
    print(f"使用模型：{MODEL_NAME}")
    print(f"实验时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
    
    for task in tasks:
        print(f"----- 任务 {task['task_id']}：{task['task_type']} -----")
        print(f"任务描述：{task['task_description']}")
        print(f"任务文本：{task['task_text']}\n")
        
        # 获取LLM响应
        llm_response = get_llm_response(task['task_text'])
        print(f"LLM响应：{llm_response}\n")
        
        # 记录结果
        result = {
            "experiment_id": EXPERIMENT_ID,
            "task_id": task['task_id'],
            "task_type": task['task_type'],
            "task_text": task['task_text'],
            "llm_model": MODEL_NAME,
            "llm_response": llm_response,
            "key_concept": task['key_concept'],
            "timestamp": datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        experiment_results.append(result)
    
    print("===== 实验结束 =====")
    return experiment_results

# --------------------------
# 结果保存与分析
# --------------------------
def save_results(results, save_format=["csv", "json"]):
    """
    保存实验结果到文件
    参数：
        results: 实验结果列表
        save_format: 保存格式，支持csv和json
    """
    # 转换为DataFrame便于处理
    df = pd.DataFrame(results)
    
    # 保存文件
    base_filename = f"llm_decision_making_experiment_{datetime.now().strftime('%Y%m%d')}"
    
    if "csv" in save_format:
        csv_filename = f"{base_filename}.csv"
        df.to_csv(csv_filename, index=False, encoding="utf-8-sig")
        print(f"结果已保存为CSV文件：{csv_filename}")
    
    if "json" in save_format:
        json_filename = f"{base_filename}.json"
        with open(json_filename, "w", encoding="utf-8") as f:
            json.dump(results, f, ensure_ascii=False, indent=2)
        print(f"结果已保存为JSON文件：{json_filename}")
    
    return df

def analyze_results(df):
    """
    简单分析实验结果（统计LLM的决策偏差情况）
    参数：
        df: 实验结果DataFrame
    """
    print("\n===== 实验结果初步分析 =====")
    
    # 统计各任务类型的响应情况
    task_type_stats = df.groupby("task_type").size()
    print(f"\n1. 任务类型分布：")
    print(task_type_stats)
    
    # 识别LLM是否出现典型偏差（基于响应内容关键词）
    biases = []
    for idx, row in df.iterrows():
        task_type = row["task_type"]
        response = row["llm_response"].lower()
        
        if task_type == "代表性启发式":
            # 典型偏差：选择C/D（忽略70%律师的基础概率）
            if any(opt in response for opt in ["c", "d"]):
                biases.append("出现代表性启发式偏差")
            else:
                biases.append("未出现代表性启发式偏差")
        
        elif task_type == "框架效应（收益框架）":
            # 典型偏差：选择A（风险规避）
            if "a" in response:
                biases.append("符合收益框架的风险规避偏差")
            else:
                biases.append("不符合收益框架的风险规避偏差")
        
        elif task_type == "框架效应（损失框架）":
            # 典型偏差：选择B（风险寻求）
            if "b" in response:
                biases.append("符合损失框架的风险寻求偏差")
            else:
                biases.append("不符合损失框架的风险寻求偏差")
        
        elif task_type == "基础概率忽略":
            # 典型偏差：选择C/D（过度关注目击者准确率，忽略基础概率）
            if any(opt in response for opt in ["c", "d"]):
                biases.append("出现基础概率忽略偏差")
            else:
                biases.append("未出现基础概率忽略偏差")
        
        elif task_type == "合取谬误":
            # 典型偏差：选择B（认为合取事件概率更高）
            if "b" in response:
                biases.append("出现合取谬误偏差")
            else:
                biases.append("未出现合取谬误偏差")
    
    df["bias_analysis"] = biases
    print(f"\n2. LLM决策偏差分析：")
    print(df[["task_id", "task_type", "bias_analysis"]].to_string(index=False))

# --------------------------
# 主程序：执行实验流程
# --------------------------
if __name__ == "__main__":
    # 1. 运行实验
    experiment_results = run_experiment(decision_tasks)
    
    # 2. 保存结果
    results_df = save_results(experiment_results)
    
    # 3. 初步分析
    analyze_results(results_df)
    
    # 4. 实验报告提示
    print("\n===== 实验报告要求 =====")
    print("请基于实验结果完成以下分析：")
    print("1. 对比LLM的决策结果与人类典型偏差（PPT中讲解的启发式偏差）是否一致？")
    print("2. 不同任务类型中，LLM对框架效应的敏感度如何？")
    print("3. LLM是否能正确利用基础概率进行决策？")
    print("4. 结合双加工理论（系统1/系统2），分析LLM的决策机制与人类的异同。")
    print("5. 思考：LLM的决策偏差可能来自哪些因素？（如训练数据、模型结构等）")