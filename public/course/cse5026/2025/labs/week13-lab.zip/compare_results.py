# -*- coding: utf-8 -*-
"""
对比分析标准模式和推理模式的实验结果
"""

import json
import pandas as pd

# 读取两个结果文件
with open("llm_decision_making_experiment_请输入你的学号_20251201.json", "r", encoding="utf-8") as f:
    standard_results = json.load(f)

with open("llm_decision_making_experiment_reasoning_20251201.json", "r", encoding="utf-8") as f:
    reasoning_results = json.load(f)

print("=" * 80)
print("标准模式 vs 推理模式 - 实验结果对比分析")
print("=" * 80)

# 任务名称映射
task_names = {
    1: "代表性启发式",
    2: "框架效应（收益框架）",
    3: "框架效应（损失框架）",
    4: "基础概率忽略",
    5: "合取谬误"
}

# 提取选择结果
def extract_choice(response):
    """从响应中提取选择的选项"""
    response_lower = response.lower()
    # 查找明确的选项声明
    if "b. 31%-50%" in response_lower or "选择：b" in response_lower or "选择：b." in response_lower:
        return "B"
    if "a. 0%-30%" in response_lower or "选择：a" in response_lower or "选择：a." in response_lower:
        return "A"
    if "c." in response_lower and "51%-70%" in response_lower:
        return "C"
    if "d." in response_lower and "71%-100%" in response_lower:
        return "D"
    # 查找选项 A, B, C, D
    for opt in ["a", "b", "c", "d"]:
        if f"选项：{opt}" in response_lower or f"选择：{opt}" in response_lower:
            return opt.upper()
    # 如果没找到，尝试查找选项模式
    if "选项a" in response_lower or "方案a" in response_lower:
        return "A"
    if "选项b" in response_lower or "方案b" in response_lower or "方案d" in response_lower:
        return "B"
    if "选项c" in response_lower or "方案c" in response_lower:
        return "C"
    if "选项d" in response_lower:
        return "D"
    return "未知"

print("\n【任务选择对比】")
print("-" * 80)
print(f"{'任务':<20} {'标准模式(gpt-4o-mini)':<25} {'推理模式(gpt-4o)':<25} {'是否一致':<10}")
print("-" * 80)

comparison_data = []
for i in range(5):
    standard_task = standard_results[i]
    reasoning_task = reasoning_results[i]
    
    standard_choice = extract_choice(standard_task["llm_response"])
    reasoning_choice = extract_choice(reasoning_task["llm_response"])
    
    task_name = task_names[i+1]
    is_same = "✓" if standard_choice == reasoning_choice else "✗"
    
    print(f"{task_name:<20} {standard_choice:<25} {reasoning_choice:<25} {is_same:<10}")
    
    comparison_data.append({
        "task_id": i+1,
        "task_type": task_name,
        "standard_choice": standard_choice,
        "reasoning_choice": reasoning_choice,
        "same_choice": standard_choice == reasoning_choice
    })

print("\n" + "=" * 80)
print("【详细分析】")
print("=" * 80)

# 任务1：代表性启发式
print("\n1. 代表性启发式任务")
print("-" * 80)
print("标准模式选择：A (0%-30%)")
print("推理模式选择：B (31%-50%)")
print("\n差异分析：")
print("  - 标准模式：直接考虑基础概率（30%），选择A")
print("  - 推理模式：使用贝叶斯定理进行详细分析，虽然考虑了基础概率，但认为描述特征会增加概率，选择B")
print("  - 推理模式进行了更复杂的概率推理，但可能过度考虑了描述特征的影响")

# 任务2：框架效应（收益框架）
print("\n2. 框架效应（收益框架）")
print("-" * 80)
print("标准模式选择：B (风险偏好)")
print("推理模式选择：A (风险规避)")
print("\n差异分析：")
print("  - 标准模式：选择风险选项B，不符合人类典型的风险规避行为")
print("  - 推理模式：选择确定选项A，符合人类典型的风险规避行为")
print("  - 推理模式更符合人类在收益框架下的决策模式")

# 任务3：框架效应（损失框架）
print("\n3. 框架效应（损失框架）")
print("-" * 80)
print("标准模式选择：B (风险寻求)")
print("推理模式选择：B (风险寻求)")
print("\n差异分析：")
print("  - 两种模式都选择了B，符合人类在损失框架下的风险寻求行为")
print("  - 推理模式进行了详细的期望值分析，但最终选择与标准模式一致")

# 任务4：基础概率忽略
print("\n4. 基础概率忽略")
print("-" * 80)
print("标准模式选择：B (41%)")
print("推理模式选择：B (41%)")
print("\n差异分析：")
print("  - 两种模式都正确使用了贝叶斯定理，计算出41%")
print("  - 推理模式展示了完整的计算过程，体现了更强的推理能力")
print("  - 两种模式都未出现基础概率忽略偏差")

# 任务5：合取谬误
print("\n5. 合取谬误")
print("-" * 80)
print("标准模式选择：B (出现合取谬误)")
print("推理模式选择：A (未出现合取谬误)")
print("\n差异分析：")
print("  - 标准模式：选择了B，出现了合取谬误偏差")
print("  - 推理模式：选择了A，正确应用了概率论基本原则")
print("  - 推理模式明确识别了这是'结合谬误'问题，并正确应用了概率规则")

print("\n" + "=" * 80)
print("【总结】")
print("=" * 80)
print("\n主要发现：")
print("1. 推理模式在合取谬误任务中表现更好，正确应用了概率论原则")
print("2. 推理模式在收益框架下更符合人类典型的风险规避行为")
print("3. 两种模式在基础概率任务中都正确使用了贝叶斯定理")
print("4. 推理模式提供了更详细的推理过程，展示了系统2（慢思考）的特征")
print("5. 推理模式在代表性启发式任务中可能过度考虑了描述特征的影响")

print("\n偏差对比：")
bias_comparison = {
    "代表性启发式": {"standard": "未出现", "reasoning": "出现"},
    "框架效应（收益框架）": {"standard": "不符合", "reasoning": "符合"},
    "框架效应（损失框架）": {"standard": "符合", "reasoning": "符合"},
    "基础概率忽略": {"standard": "未出现", "reasoning": "未出现"},
    "合取谬误": {"standard": "出现", "reasoning": "未出现"}
}

for task, biases in bias_comparison.items():
    print(f"  {task}:")
    print(f"    标准模式: {biases['standard']}")
    print(f"    推理模式: {biases['reasoning']}")

print("\n" + "=" * 80)

