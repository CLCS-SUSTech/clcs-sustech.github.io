# 中文即时记忆实验 - Higgs Audio版本

## 更新说明

本版本使用**[Higgs Audio V2](https://github.com/boson-ai/higgs-audio)**作为语音合成引擎，这是一个基于10M+小时音频数据训练的音频基础模型。

## 为什么选择Higgs Audio？

根据[Higgs Audio V2的评测](https://github.com/boson-ai/higgs-audio)，该模型在多个基准测试中表现出色：

### 性能优势

1. **语音质量**：在EmergentTTS-Eval评测中，Higgs Audio V2在情感表达方面达到**75.71%的胜率**，超越了GPT-4o、Qwen等模型
2. **多语言支持**：支持高质量的中文语音合成
3. **开源免费**：完全开源，无需API密钥
4. **本地运行**：可在本地运行，保护隐私

### 技术特点

- **预训练数据**：超过1000万小时的音频数据
- **统一音频tokenizer**：同时捕获语义和声学特征
- **DualFFN架构**：增强LLM对声学token的建模能力
- **零样本TTS**：无需针对特定说话人进行微调

## 安装步骤

### 1. 安装Higgs Audio

```bash
pip install git+https://github.com/boson-ai/higgs-audio.git
```

### 2. 安装其他依赖

```bash
pip install torch torchaudio numpy ipywidgets matplotlib pandas
```

### 3. 首次运行

首次运行时，系统会自动下载Higgs Audio模型（约几GB）。请确保：
- 网络连接正常
- 有足够的磁盘空间（建议至少5GB）

## 使用方法

在Jupyter Notebook中：

```python
# 1. 导入Higgs Audio版本
%run memory_higgs.py

# 2. 创建并运行实验
experiment_higgs = MemoryExperimentHiggs()
experiment_higgs.display_ui()

# 3. 开始实验
# - 选择难度级别（简单/中等/困难）
# - 选择词汇数量（2-10个）
# - 点击"开始实验"按钮
# - 等待语音生成和播放
# - 输入记住的词汇
```

## 对比：Higgs Audio vs gTTS

| 特性 | Higgs Audio V2 | gTTS |
|------|----------------|------|
| **语音质量** | 极高（训练数据10M+小时） | 中等 |
| **情感表达** | 优秀（75.71%胜率） | 有限 |
| **运行方式** | 本地运行 | 需要联网 |
| **隐私保护** | 完全离线 | 数据上传到Google |
| **安装难度** | 中等（需要下载模型） | 简单 |
| **首次生成速度** | 较慢（加载模型） | 较快 |
| **后续生成速度** | 快（模型已加载） | 快 |
| **依赖** | PyTorch + Higgs Audio | gTTS + ffmpeg |
| **磁盘占用** | 较大（~5GB） | 很小 |

## 优势

### 1. 更高的语音质量
- 基于大量音频数据训练
- 自然的韵律和情感表达
- 更接近真人发音

### 2. 完全本地运行
- 无需互联网连接（首次下载模型后）
- 数据不上传
- 适合隐私要求高的场景

### 3. 开源免费
- Apache 2.0许可证
- 完全开源
- 无需API密钥或费用

### 4. 可定制化
- 可以微调和优化
- 支持更复杂的语音生成任务

## 技术细节

- **采样率**：24000 Hz（Higgs Audio的标准采样率）
- **音频格式**：numpy数组（float32）
- **声道**：自动转换为单声道
- **归一化**：音频值归一化到[-1, 1]范围
- **模型大小**：约几GB（具体取决于使用的模型）

## 故障排除

### 问题1：导入错误
```bash
# 解决：重新安装
pip install git+https://github.com/boson-ai/higgs-audio.git --upgrade
```

### 问题2：模型下载失败
**解决**：
- 检查网络连接
- 增加超时时间
- 或手动下载模型并放置到缓存目录

### 问题3：内存不足
**解决**：
- 使用较小的模型（如果有）
- 增加系统内存
- 使用GPU加速

### 问题4：生成速度慢
**解决**：
- 首次运行会较慢（需要加载模型）
- 模型加载后会加快
- 考虑使用GPU加速

## 系统要求

### 最低配置
- Python 3.8+
- 8GB RAM
- 5GB 磁盘空间
- 支持CPU运行

### 推荐配置
- Python 3.10+
- 16GB+ RAM
- 10GB+ 磁盘空间
- NVIDIA GPU（CUDA 11.8+）
- CUDA支持的PyTorch

## 性能建议

1. **首次运行**：第一次使用时会下载模型，需要耐心等待
2. **后续运行**：模型加载后，生成速度会显著提高
3. **批量生成**：可以在模型加载后批量生成多个词汇的语音
4. **GPU加速**：如果有GPU，会显著提高生成速度

## 参考资料

- **官方仓库**：[https://github.com/boson-ai/higgs-audio](https://github.com/boson-ai/higgs-audio)
- **技术博客**：[https://www.boson.ai/blog/higgs-audio-v2](https://www.boson.ai/blog/higgs-audio-v2)
- **评测结果**：详见GitHub README中的性能对比

## 版本选择建议

根据您的需求选择：

- **快速原型/演示**：使用gTTS版本（`memory_fixed.py`）
- **高质量研究**：使用Higgs Audio版本（`memory_higgs.py`）
- **离线环境**：使用Higgs Audio版本
- **隐私敏感**：使用Higgs Audio版本

## 作者信息

本实验代码集成Higgs Audio V2作为TTS引擎，提供高质量的语音合成能力用于认知科学研究。
