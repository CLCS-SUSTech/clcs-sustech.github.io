# 中文即时记忆实验 - Higgs Audio版本
# 使用Higgs Audio V2作为TTS引擎

# 导入必要库
import numpy as np
import random
import time
from IPython.display import Audio, display, clear_output
import ipywidgets as widgets
from IPython.display import HTML
import matplotlib.pyplot as plt
import os
import torch
import torchaudio

# 实验参数设置
SAMPLE_RATE = 24000  # Higgs Audio使用24kHz采样率
DURATION = 1.0
INTERVAL = 1.5
TEST_DELAY = 3.0

# 词汇库
WORD_LEVELS = {
    "简单": ["苹果", "香蕉", "桌子", "书本", "月亮", "太阳", "红色", "蓝色", 
            "高兴", "跑步", "飞机", "汽车", "学校", "家庭", "朋友"],
    "中等": ["思考", "分析", "判断", "理解", "坚持", "努力", "迅速", "缓慢",
            "困难", "容易", "详细", "简略", "勇敢", "谨慎", "智慧"],
    "困难": ["逻辑", "抽象", "辩证", "客观", "主观", "系统", "复杂", "精密",
            "卓越", "平凡", "独特", "普遍", "深刻", "肤浅", "全面"]
}

# 全局变量存储Higgs Audio模型
_higgs_model = None
_higgs_tokenizer = None

def load_higgs_model():
    """加载Higgs Audio模型"""
    global _higgs_model, _higgs_tokenizer
    
    if _higgs_model is None:
        try:
            from boson_multimodal import HiggsAudioForGeneration
            from boson_multimodal.processing_audio import HiggsAudioProcessor
            
            print("正在加载Higgs Audio模型...")
            
            # 加载模型和处理器
            _higgs_model = HiggsAudioForGeneration.from_pretrained("boson-ai/higgs-audio-v2")
            _higgs_tokenizer = HiggsAudioProcessor.from_pretrained("boson-ai/higgs-audio-v2")
            
            # 设置为评估模式
            _higgs_model.eval()
            
            print("Higgs Audio模型加载完成！")
            
        except ImportError:
            raise ImportError(
                "需要安装Higgs Audio包。"
                "请运行: pip install git+https://github.com/boson-ai/higgs-audio.git"
            )
        except Exception as e:
            print(f"加载模型时出错: {e}")
            raise
    
    return _higgs_model, _higgs_tokenizer

def generate_chinese_speech(text, duration=None, sr=None):
    """
    使用Higgs Audio生成中文语音
    Args:
        text: 要生成语音的中文文本
        duration: 保留参数（兼容性）
        sr: 保留参数（兼容性）
    Returns:
        numpy数组形式的音频数据
    """
    try:
        # 加载模型（如果尚未加载）
        model, processor = load_higgs_model()
        
        # 准备输入
        inputs = processor(text=[text], return_tensors="pt", padding=True)
        
        # 生成音频
        with torch.no_grad():
            outputs = model.generate(**inputs)
        
        # 提取音频数据
        audio_data = outputs.audio_values[0].numpy()
        
        # 转换为单声道（如果是立体声）
        if len(audio_data.shape) > 1:
            audio_data = audio_data.mean(axis=0)
        
        # 归一化到[-1, 1]
        if audio_data.max() > 1.0 or audio_data.min() < -1.0:
            audio_data = audio_data / np.max(np.abs(audio_data))
        
        return audio_data.astype(np.float32)
        
    except Exception as e:
        print(f"Higgs Audio生成失败: {e}")
        print("请确保已正确安装Higgs Audio并下载模型")
        # 返回静音
        return np.zeros(int(SAMPLE_RATE * 1.0), dtype=np.float32)

# 实验控制类
class MemoryExperimentHiggs:
    def __init__(self):
        self.reset()
        
        # 实验数据存储
        self.experiment_data = []
        self.session_id = time.strftime("%Y%m%d_%H%M%S")
        
        # 创建UI组件
        self.level_selector = widgets.Dropdown(
            options=["简单", "中等", "困难"],
            value="简单",
            description="难度:"
        )
        
        self.length_selector = widgets.IntSlider(
            value=3,
            min=2,
            max=10,
            step=1,
            description="词汇数量:"
        )
        
        self.start_button = widgets.Button(
            description="开始实验",
            button_style="success"
        )
        self.start_button.on_click(self.start_experiment)
        
        self.result_area = widgets.Output()
        self.response_input = widgets.Text(
            placeholder="请输入你记住的词汇，用空格分隔",
            description="答案:"
        )
        self.submit_button = widgets.Button(
            description="提交答案",
            button_style="primary"
        )
        self.submit_button.on_click(self.submit_answer)
        
        self.save_data_button = widgets.Button(
            description="保存数据",
            button_style="info"
        )
        self.save_data_button.on_click(self.save_data)
        
        self.show_stats_button = widgets.Button(
            description="显示统计",
            button_style="warning"
        )
        self.show_stats_button.on_click(self.show_statistics)
        
        # 布局
        self.ui = widgets.VBox([
            widgets.HTML("<h2>中文即时记忆实验 (Higgs Audio版)</h2>"),
            widgets.HTML("<p>实验说明: 你将听到一系列中文词汇，请尽力记住它们。播放结束后，请输入你记住的所有词汇。</p>"),
            widgets.HTML("<p style='color: green;'>✓ 使用Higgs Audio V2生成高质量中文语音</p>"),
            self.level_selector,
            self.length_selector,
            self.start_button,
            widgets.HBox([self.save_data_button, self.show_stats_button]),
            self.result_area
        ])
    
    def reset(self):
        """重置实验状态"""
        self.current_words = []
        self.user_responses = []
        self.start_time = 0
        self.end_time = 0
        self.is_running = False
    
    def display_ui(self):
        """显示实验UI"""
        display(self.ui)
    
    def play_all_words_together(self, words):
        """将所有词汇合并成一个音频一次性播放"""
        all_audio = []
        
        print(f"正在使用Higgs Audio生成语音...")
        for i, word in enumerate(words):
            print(f"生成中: {word} ({i+1}/{len(words)})")
            # 使用Higgs Audio生成每个词的语音
            word_audio = generate_chinese_speech(word)
            all_audio.append(word_audio)
            
            # 在词之间添加静音间隔（除了最后一个词）
            if i < len(words) - 1:
                silence_duration = INTERVAL
                silence_samples = int(SAMPLE_RATE * silence_duration)
                silence = np.zeros(silence_samples, dtype=np.float32)
                all_audio.append(silence)
        
        combined_audio = np.concatenate(all_audio)
        
        # 显示合并后的音频
        display(Audio(combined_audio, rate=SAMPLE_RATE, autoplay=True))
        return len(combined_audio) / SAMPLE_RATE
    
    def start_experiment(self, b):
        """开始实验"""
        self.reset()
        self.is_running = True
        
        # 获取设置
        level = self.level_selector.value
        word_count = self.length_selector.value
        
        # 选择词汇
        self.current_words = random.sample(WORD_LEVELS[level], word_count)
        
        with self.result_area:
            clear_output()
            print(f"实验开始！即将使用Higgs Audio播放 {word_count} 个{level}词汇，请集中注意力记忆...")
            time.sleep(1)
            
            # 使用Higgs Audio播放所有词汇
            clear_output()
            print(f"正在播放 {word_count} 个词汇，请仔细听...")
            self.start_time = time.time()
            
            # 合并所有音频并播放
            total_duration = self.play_all_words_together(self.current_words)
            
            print(f"\n音频总时长约 {total_duration:.2f} 秒")
            time.sleep(total_duration + 2)
            
            # 等待记忆时间
            clear_output()
            print("词汇播放完毕，请稍等...")
            time.sleep(TEST_DELAY)
            
            # 显示回答界面
            clear_output()
            print("请输入你记住的所有词汇，用空格分隔:")
            display(self.response_input)
            display(self.submit_button)
    
    def submit_answer(self, b):
        """提交答案并计算结果"""
        if not self.is_running:
            return
            
        self.end_time = time.time()
        self.user_responses = self.response_input.value.split()
        
        # 计算正确率
        correct = [word for word in self.user_responses if word in self.current_words]
        accuracy = len(correct) / len(self.current_words) if self.current_words else 0
        reaction_time = self.end_time - self.start_time
        
        # 记录实验数据
        trial_data = {
            'trial_id': len(self.experiment_data) + 1,
            'session_id': self.session_id,
            'timestamp': time.strftime("%Y-%m-%d %H:%M:%S"),
            'difficulty': self.level_selector.value,
            'word_count': len(self.current_words),
            'target_words': ', '.join(self.current_words),
            'user_responses': ', '.join(self.user_responses) if self.user_responses else '',
            'correct_words': ', '.join(correct),
            'correct_count': len(correct),
            'total_count': len(self.current_words),
            'accuracy': accuracy,
            'reaction_time': reaction_time
        }
        
        self.experiment_data.append(trial_data)
        
        # 显示结果
        with self.result_area:
            clear_output()
            print(f"实验结果 (Trial {trial_data['trial_id']}):\n")
            print(f"原始词汇: {', '.join(self.current_words)}")
            print(f"你的答案: {', '.join(self.user_responses) if self.user_responses else '无'}")
            print(f"正确数量: {len(correct)}/{len(self.current_words)}")
            print(f"正确率: {accuracy:.2%}")
            print(f"反应时间: {reaction_time:.2f}秒")
            
            # 可视化结果
            plt.figure(figsize=(8, 4))
            plt.bar(["正确", "错误"], [len(correct), len(self.current_words) - len(correct)])
            plt.title(f"记忆结果 (Trial {trial_data['trial_id']})")
            plt.ylim(0, len(self.current_words))
            plt.show()
            
            print(f"\n已记录 {len(self.experiment_data)} 次实验数据")
            print("点击'开始实验'可以再次进行测试")
        
        self.is_running = False
    
    def save_data(self, b):
        """保存数据到CSV"""
        if not self.experiment_data:
            with self.result_area:
                print("没有实验数据可保存")
            return
        
        import pandas as pd
        df = pd.DataFrame(self.experiment_data)
        filename = f"memory_experiment_data_{self.session_id}.csv"
        df.to_csv(filename, index=False, encoding='utf-8-sig')
        
        with self.result_area:
            clear_output()
            print(f"数据已保存到: {filename}")
            print(f"共保存 {len(self.experiment_data)} 条实验记录")
    
    def show_statistics(self, b):
        """显示统计信息"""
        if not self.experiment_data:
            with self.result_area:
                print("没有实验数据可显示")
            return
        
        import pandas as pd
        df = pd.DataFrame(self.experiment_data)
        
        with self.result_area:
            clear_output()
            print("=== 实验统计信息 ===\n")
            print(f"总实验次数: {len(self.experiment_data)}")
            print(f"平均正确率: {df['accuracy'].mean():.2%}")
            print(f"平均反应时间: {df['reaction_time'].mean():.2f}秒")
            print(f"最高正确率: {df['accuracy'].max():.2%}")
            print(f"最低正确率: {df['accuracy'].min():.2%}")

# 使用示例
# experiment_higgs = MemoryExperimentHiggs()
# experiment_higgs.display_ui()

"""
安装说明：
==========

在运行此实验前，需要安装Higgs Audio：

1. 安装Higgs Audio包：
   pip install git+https://github.com/boson-ai/higgs-audio.git

2. 安装其他依赖：
   pip install torch torchaudio numpy ipywidgets matplotlib pandas

3. 首次运行时会自动下载Higgs Audio模型（约几GB）

优势：
- 高质量的语音合成（基于10M+小时音频训练）
- 支持多语言和情感表达
- 开源且免费
- 更好的语音自然度

参考：https://github.com/boson-ai/higgs-audio
"""
