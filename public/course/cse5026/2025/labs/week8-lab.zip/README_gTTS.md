# 中文即时记忆实验 - gTTS版本

## 更新说明

本版本已更新为使用**Google Text-to-Speech (gTTS)**来生成真实的中文语音，替代了之前的模拟音调方法。

## 主要改进

1. **真实中文语音**：使用gTTS生成标准的中文语音，不再是模拟的音调
2. **更好的用户体验**：被试者可以听到清晰、自然的中文发音
3. **提高实验准确性**：真实语音更接近实际的记忆实验场景

## 安装依赖

在运行实验前，请先安装必要的依赖包：

```bash
pip install gtts pydub
```

**注意：** pydub依赖ffmpeg来处理音频文件。如果遇到问题，请安装ffmpeg：

### macOS
```bash
brew install ffmpeg
```

### Ubuntu/Debian
```bash
sudo apt-get install ffmpeg
```

### Windows
1. 从 [ffmpeg官网](https://ffmpeg.org/download.html) 下载
2. 解压并添加到系统PATH

## 使用方法

在Jupyter Notebook中：

1. 导入修复版实验代码：
```python
%run memory_fixed.py
```

2. 创建并运行实验：
```python
experiment_fixed = MemoryExperimentFixed()
experiment_fixed.display_ui()
```

3. 开始实验：
   - 选择难度级别（简单/中等/困难）
   - 选择词汇数量（2-10个）
   - 点击"开始实验"按钮
   - 等待语音生成和播放
   - 输入记住的词汇

## 工作原理

1. **语音生成**：使用gTTS将每个中文词汇转换为真实的语音文件
2. **音频处理**：使用pydub将MP3音频文件转换为numpy数组
3. **音频合并**：将所有词汇的音频与静音间隔合并成一个完整的音频
4. **播放**：在Jupyter中一次性播放合并后的音频

## 注意事项

1. **网络连接**：gTTS需要连接到Google的服务器，确保网络连接正常
2. **首次使用**：首次生成语音可能需要较长时间
3. **缓存**：可以缓存已生成的语音以提高后续速度（需要额外实现）
4. **离线使用**：如果需要离线使用，可以考虑使用本地的TTS引擎

## 故障排除

### 问题：导入错误
**解决**：确保已安装所有依赖
```bash
pip install gtts pydub numpy ipywidgets matplotlib pandas
```

### 问题：ffmpeg错误
**解决**：安装ffmpeg（见安装依赖部分）

### 问题：网络连接错误
**解决**：
- 检查网络连接
- 确认可以访问Google服务器
- 考虑使用VPN（如果在某些地区）

### 问题：音频播放无声
**解决**：
- 检查音量设置
- 尝试手动播放音频控件
- 检查浏览器音频权限

## 技术细节

- **采样率**：44100 Hz
- **音频格式**：MP3 → numpy数组（float32）
- **声道**：自动转换为单声道
- **归一化**：音频值归一化到[-1, 1]范围

## 作者信息

本实验代码基于中文即时记忆实验需求，使用gTTS实现真实的中文语音合成。
