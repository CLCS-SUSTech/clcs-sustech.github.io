# 修复版中文即时记忆实验
# 修复了音频播放无法正常工作的问题

# 重新导入必要库（如果在notebook中需要再次运行）
import numpy as np
import random
import time
from IPython.display import Audio, display, clear_output
import ipywidgets as widgets
from IPython.display import HTML
import matplotlib.pyplot as plt
from gtts import gTTS
import io
import os
import subprocess
import tempfile
import threading

# 实验参数设置（与原来相同）
SAMPLE_RATE = 44100
DURATION = 1.0
INTERVAL = 1.5
TEST_DELAY = 3.0

# 中文词汇库（与原来相同）
WORD_LEVELS = {
    "simple": ["苹果", "香蕉", "桌子", "书本", "月亮", "太阳", "红色", "蓝色", 
            "高兴", "跑步", "飞机", "汽车", "学校", "家庭", "朋友"],
    "medium": ["思考", "分析", "判断", "理解", "坚持", "努力", "迅速", "缓慢",
            "困难", "容易", "详细", "简略", "勇敢", "谨慎", "智慧"],
    "hard": ["逻辑", "抽象", "辩证", "客观", "主观", "系统", "复杂", "精密",
            "卓越", "平凡", "独特", "普遍", "深刻", "肤浅", "全面"]
}

# 英文词汇库
WORD_LEVELS_EN = {
    "simple": ["apple", "banana", "table", "book", "moon", "sun", "red", "blue",
            "happy", "run", "plane", "car", "school", "family", "friend"],
    "medium": ["think", "analyze", "judge", "understand", "persist", "effort", "fast", "slow",
            "difficult", "easy", "detail", "brief", "brave", "careful", "wisdom"],
    "hard": ["logic", "abstract", "dialectic", "objective", "subjective", "system", "complex", "precise",
            "excellent", "ordinary", "unique", "general", "deep", "superficial", "comprehensive"]
}

# 语音生成函数 - 使用gTTS生成真实的中文或英文语音
def generate_speech(text, lang='en', slow=False, duration=None, sr=None):
    """
    使用gTTS生成真实的中文或英文语音
    Args:
        text: 要生成语音的文本
        lang: 语言代码，'zh'表示中文，'en'表示英文
        duration: 保留参数（用于兼容性，忽略）
        sr: 保留参数（用于兼容性，忽略）
    Returns:
        numpy数组形式的音频数据
    """
    try:
        # 创建临时文件存储音频
        temp_file = f"temp_audio_{abs(hash(text))}.mp3"
        
        # 根据语言选择对应的语言代码
        if lang == 'zh':
            lang_code = 'zh'
        elif lang == 'en':
            lang_code = 'en-us'
        else:
            raise ValueError(f"不支持的语言: {lang}")
        
        # 使用gTTS生成语音
        tts = gTTS(text=text, lang=lang_code, slow=slow)
        tts.save(temp_file)
        
        # 读取音频文件
        try:
            from pydub import AudioSegment
            # 使用pydub加载MP3文件
            audio_segment = AudioSegment.from_mp3(temp_file)
            
            # 转换为numpy数组
            audio_array = np.array(audio_segment.get_array_of_samples())
            
            # 如果是立体声，转换为单声道（取平均或单个声道）
            if audio_segment.channels == 2:
                audio_array = audio_array.reshape((-1, 2))
                audio_array = audio_array.mean(axis=1)  # 取平均值
        
            # 归一化到[-1, 1]范围
            if audio_array.dtype == np.int16:
                audio_array = audio_array.astype(np.float32) / 32768.0
            elif audio_array.dtype == np.int32:
                audio_array = audio_array.astype(np.float32) / 2147483648.0
            elif audio_array.dtype == np.int32:
                audio_array = audio_array.astype(np.float32) / 128.0
                
            # 确保数据类型正确
            audio_array = audio_array.astype(np.float32)
            
        except ImportError:
            raise ImportError(
                "需要安装pydub来处理音频文件。"
                "请运行: pip install pydub"
            )
            
        # 删除临时文件
        try:
            if os.path.exists(temp_file):
                os.remove(temp_file)
        except:
            pass
        
        return audio_array
        
    except Exception as e:
        print(f"gTTS生成失败: {e}")
        print("提示：请确保已安装gTTS和pydub: pip install gtts pydub")
        # 返回静音
        return np.zeros(44100, dtype=np.float32)

# 修复版实验类
class MemoryExperimentFixed:
    def __init__(self):
        self.reset()
        
        # 实验数据存储
        self.experiment_data = []
        self.session_id = time.strftime("%Y%m%d_%H%M%S")
        self.current_language = "zh"  # 记录当前使用的语言
        
        # 创建UI组件
        self.language_selector = widgets.Dropdown(
            options=[("English", "en"), ("Chinese", "zh")],
            value="en",
            description="语言:"
        )
        
        self.level_selector = widgets.Dropdown(
            options=["simple", "medium", "hard"],
            value="simple",
            description="难度:"
        )
        
        self.length_selector = widgets.IntSlider(
            value=4,
            min=2,
            max=10,
            step=1,
            description="词汇数量:"
        )
        
        self.start_button = widgets.Button(
            description="开始实验",
            button_style="success"
        )
        self.start_button.on_click(self.start_experiment)
        
        self.result_area = widgets.Output()
        self.response_input = widgets.Text(
            placeholder="请输入你记住的单词，用空格分隔",
            description="答案:"
        )
        self.submit_button = widgets.Button(
            description="提交答案",
            button_style="primary"
        )
        self.submit_button.on_click(self.submit_answer)
        
        self.save_data_button = widgets.Button(
            description="保存数据",
            button_style="info"
        )
        self.save_data_button.on_click(self.save_data)
        
        self.show_stats_button = widgets.Button(
            description="显示统计",
            button_style="warning"
        )
        self.show_stats_button.on_click(self.show_statistics)
        
        self.cleanup_button = widgets.Button(
            description="清理临时文件",
            button_style="danger"
        )
        self.cleanup_button.on_click(self.cleanup_temp_files)
        
        # 布局
        self.ui = widgets.VBox([
            widgets.HTML("<h2>单词记忆实验</h2>"),
            widgets.HTML("<p>实验说明: 你将听到一系列单词，请尽力记住它们。播放结束后，请输入你记住的所有单词。</p>"),
            self.language_selector,
            self.level_selector,
            self.length_selector,
            self.start_button,
            widgets.HBox([self.save_data_button, self.show_stats_button, self.cleanup_button]),
            self.result_area
        ])
    
    def reset(self):
        """重置实验状态"""
        self.current_words = []
        self.user_responses = []
        self.start_time = 0
        self.end_time = 0
        self.is_running = False
        # 注意：不清除 current_language，保持设置
    
    def display_ui(self):
        """显示实验UI"""
        display(self.ui)
    
    def play_all_words_together(self, words, language='zh'):
        """关键修复：将所有词汇合并成一个音频一次性播放 - 使用ffmpeg合并"""
        import tempfile
        import os
        
        # 创建临时文件存储每个单词的音频
        temp_files = []
        
        # print(f"正在生成 {len(words)} 个单词的语音: {words}")
        for i, word in enumerate(words):
            # 为每个单词生成临时MP3文件
            temp_mp3 = f"temp_word_{i}_{abs(hash(word))}.mp3"
            
            # 使用gTTS生成每个词的语音并保存
            lang_code = 'zh' if language == 'zh' else 'en-us'
            try:
                tts = gTTS(text=word, lang=lang_code, slow=False)
                tts.save(temp_mp3)
                
                # 验证文件是否成功创建
                if os.path.exists(temp_mp3) and os.path.getsize(temp_mp3) > 0:
                    temp_files.append(temp_mp3)
                else:
                    print(f"✗ 生成失败: {word} (文件不存在或为空)")
                    return 0
            except Exception as e:
                print(f"✗ 生成 {word} 时出错: {e}")
                return 0
            
            # 如果不是最后一个词，添加静音
            if i < len(words) - 1:
                silence_mp3 = f"temp_silence_{i}.mp3"
                self.create_silence_mp3(silence_mp3, INTERVAL)
                if os.path.exists(silence_mp3):
                    temp_files.append(silence_mp3)
        
        # 使用pydub直接合并音频
        combined_mp3 = f"combined_{abs(hash(''.join(words)))}.mp3"
        
        try:
            from pydub import AudioSegment
            combined = AudioSegment.empty()
            for file in temp_files:
                if os.path.exists(file):
                    audio = AudioSegment.from_mp3(file)
                    combined += audio
            combined.export(combined_mp3, format="mp3")
        except Exception as e:
            print(f"pydub合并失败: {e}，尝试ffmpeg")
            self.merge_audio_files_ffmpeg(temp_files, combined_mp3)
        
        # 检查文件是否存在
        if not os.path.exists(combined_mp3):
            print(f"错误：合并的音频文件不存在: {combined_mp3}")
            return 0
        
        # 使用pydub加载音频并转换为numpy数组
        try:
            from pydub import AudioSegment
            audio_segment = AudioSegment.from_mp3(combined_mp3)
            
            # 转换为numpy数组
            audio_array = np.array(audio_segment.get_array_of_samples())
            
            # 如果是立体声，转换为单声道
            if audio_segment.channels == 2:
                audio_array = audio_array.reshape((-1, 2))
                audio_array = audio_array.mean(axis=1)
            
            # 转换为float32类型
            audio_array = audio_array.astype(np.float32)
            
            # 计算实际音频时长（使用audio_segment的时长更准确）
            estimated_duration = len(audio_segment) / 1000.0  # audio_segment.length返回毫秒
            
            # 直接显示播放器
            clear_output()
            display(Audio(audio_array, rate=audio_segment.frame_rate, autoplay=True))
            
        except Exception as e:
            print(f"加载音频失败: {e}")
            # 备选方案：直接显示文件路径让用户手动播放
            print(f"音频文件已保存为: {os.path.abspath(combined_mp3)}")
            estimated_duration = len(words) * DURATION + (len(words) - 1) * INTERVAL
        
        # 延迟删除临时文件
        def delayed_cleanup():
            time.sleep(estimated_duration + 10)  # 额外10秒缓冲
            for temp_file in temp_files + [combined_mp3]:
                if os.path.exists(temp_file):
                    try:
                        os.remove(temp_file)
                    except:
                        pass
        
        # 在后台线程中延迟清理文件
        cleanup_thread = threading.Thread(target=delayed_cleanup)
        cleanup_thread.daemon = True
        cleanup_thread.start()
        
        return estimated_duration
    
    def create_silence_mp3(self, output_file, duration):
        """使用ffmpeg创建静音MP3文件"""
        import subprocess
        # 使用ffmpeg生成静音文件
        cmd = [
            'ffmpeg', '-f', 'lavfi', '-i', 'anullsrc=channel_layout=mono:sample_rate={}'.format(SAMPLE_RATE),
            '-t', str(duration), '-acodec', 'mp3', '-b:a', '192k', '-y', output_file
        ]
        try:
            subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
        except subprocess.CalledProcessError as e:
            print(f"创建静音文件失败: {e}")
            # 如果ffmpeg失败，创建一个空文件（会有警告但不影响运行）
    
    def merge_audio_files_ffmpeg(self, input_files, output_file):
        """使用ffmpeg合并多个音频文件"""
        import subprocess
        
        # 创建ffmpeg输入文件列表
        with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
            filelist = f.name
            for file in input_files:
                if os.path.exists(file):
                    f.write(f"file '{os.path.abspath(file)}'\n")
        
        try:
            # 使用ffmpeg的concat demuxer合并文件
            cmd = [
                'ffmpeg', '-f', 'concat', '-safe', '0', '-i', filelist,
                '-c', 'copy', '-y', output_file
            ]
            subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
        except subprocess.CalledProcessError as e:
            print(f"合并音频失败: {e}")
            # 如果ffmpeg失败，fallback到numpy concatenate
            self.merge_audio_fallback(input_files, output_file)
        finally:
            # 清理文件列表
            if os.path.exists(filelist):
                os.remove(filelist)
    
    def merge_audio_fallback(self, input_files, output_file):
        """备选方案：如果ffmpeg不可用，使用pydub合并"""
        try:
            from pydub import AudioSegment
            combined = AudioSegment.empty()
            for file in input_files:
                if os.path.exists(file):
                    audio = AudioSegment.from_mp3(file)
                    combined += audio
            combined.export(output_file, format="mp3")
        except Exception as e:
            print(f"备选合并方案也失败了: {e}")
    

    def start_experiment(self, b):
        """开始实验 - 使用修复的播放方法"""
        self.reset()
        self.is_running = True
        
        # 清空输入框
        self.response_input.value = ""
        
        # 获取设置
        language = self.language_selector.value
        self.current_language = language  # 保存当前语言设置
        level = self.level_selector.value
        word_count = self.length_selector.value
        
        # 根据语言选择对应的词汇库
        word_bank = WORD_LEVELS if language == "zh" else WORD_LEVELS_EN
        
        # 检查词汇库中是否有足够的单词
        available_words = word_bank[level]
        if word_count > len(available_words):
            print(f"警告：请求的单词数量({word_count})超过可用单词数({len(available_words)})，将使用所有可用单词")
            word_count = len(available_words)
            # 更新UI中的word_count显示
            self.length_selector.value = word_count
        
        # 选择词汇，确保选择的数量正确
        if word_count <= len(available_words):
            self.current_words = random.sample(available_words, word_count)
        else:
            self.current_words = available_words[:word_count]
        
        # 验证选择的单词数量是否正确
        actual_count = len(self.current_words)
        if actual_count != word_count:
            print(f"警告：实际选择的单词数量({actual_count})与请求的数量({word_count})不一致")
        
        language_name = "Chinese" if language == "zh" else "English"
        with self.result_area:
            clear_output()
            # print(f"已选择 {actual_count} 个单词: {', '.join(self.current_words)}")
            # print(f"实验开始！即将播放 {actual_count} 个{level}{language_name}单词，请集中注意力记忆...")
            time.sleep(1)
            
            # 使用修复的方法：一次性播放所有词汇
            # 合并所有音频并播放
            clear_output()
            print("正在生成音频，请稍等...")
            total_duration = self.play_all_words_together(self.current_words, language=language)
            print("请点击播放按钮")
            
            # print(f"\n音频总时长约 {total_duration:.2f} 秒")
            time.sleep(total_duration + 5)  # 等待播放完成
            
            # 等待记忆时间
            clear_output()
            print("单词播放完毕，请稍等...")
            time.sleep(TEST_DELAY)
            
            # 显示回答界面
            clear_output()
            print("请输入你记住的所有单词，用空格分隔:")
            display(self.response_input)
            display(self.submit_button)
            self.start_time = time.time() # start recording the reaction time
    
    def submit_answer(self, b):
        """提交答案并计算结果"""
        if not self.is_running:
            return
            
        self.end_time = time.time()
        self.user_responses = self.response_input.value.split()
        
        # 计算正确率
        correct = [word for word in self.user_responses if word in self.current_words]
        accuracy = len(correct) / len(self.current_words) if self.current_words else 0
        reaction_time = self.end_time - self.start_time
        
        # 记录实验数据
        language_name = "Chinese" if self.current_language == "zh" else "English"
        trial_data = {
            'trial_id': len(self.experiment_data) + 1,
            'session_id': self.session_id,
            'timestamp': time.strftime("%Y-%m-%d %H:%M:%S"),
            'language': language_name,
            'difficulty': self.level_selector.value,
            'word_count': len(self.current_words),
            'target_words': ', '.join(self.current_words),
            'user_responses': ', '.join(self.user_responses) if self.user_responses else '',
            'correct_words': ', '.join(correct),
            'correct_count': len(correct),
            'total_count': len(self.current_words),
            'accuracy': accuracy,
            'reaction_time': reaction_time
        }
        
        self.experiment_data.append(trial_data)
        
        # 显示结果
        with self.result_area:
            clear_output()
            print(f"实验结果 (Trial {trial_data['trial_id']}):\n")
            print(f"原始单词: {', '.join(self.current_words)}")
            print(f"你的答案: {', '.join(self.user_responses) if self.user_responses else '无'}")
            print(f"正确数量: {len(correct)}/{len(self.current_words)}")
            print(f"正确率: {accuracy:.2%}")
            print(f"反应时间: {reaction_time:.2f}秒")
            
            print(f"\n已记录 {len(self.experiment_data)} 次实验数据")
            print("点击'开始实验'可以再次进行测试")
        
        self.is_running = False
    
    def save_data(self, b):
        """保存数据到CSV"""
        if not self.experiment_data:
            with self.result_area:
                print("没有实验数据可保存")
            return
        
        import pandas as pd
        df = pd.DataFrame(self.experiment_data)
        filename = f"memory_experiment_data_{self.session_id}.csv"
        df.to_csv(filename, index=False, encoding='utf-8-sig')
        
        with self.result_area:
            clear_output()
            print(f"数据已保存到: {filename}")
            print(f"共保存 {len(self.experiment_data)} 条实验记录")
    
    def show_statistics(self, b):
        """显示统计信息"""
        if not self.experiment_data:
            with self.result_area:
                print("没有实验数据可显示")
            return
        
        import pandas as pd
        df = pd.DataFrame(self.experiment_data)
        
        with self.result_area:
            clear_output()
            print("=== 实验统计信息 ===\n")
            print(f"总实验次数: {len(self.experiment_data)}")
            print(f"平均正确率: {df['accuracy'].mean():.2%}")
            print(f"平均反应时间: {df['reaction_time'].mean():.2f}秒")
            print(f"最高正确率: {df['accuracy'].max():.2%}")
            print(f"最低正确率: {df['accuracy'].min():.2%}")
    
    def cleanup_temp_files(self, b):
        """手动清理临时MP3文件"""
        import glob
        
        with self.result_area:
            clear_output()
            
            # 查找所有临时MP3文件
            temp_patterns = ['temp_*.mp3', 'combined_*.mp3', 'filelist_*.txt']
            deleted_count = 0
            
            for pattern in temp_patterns:
                for file in glob.glob(pattern):
                    try:
                        os.remove(file)
                        deleted_count += 1
                        # print(f"✓ 已删除: {file}")
                    except Exception as e:
                        print(f"✗ 删除失败: {file} ({e})")
            
            if deleted_count == 0:
                print("没有找到需要清理的临时文件")
            else:
                print(f"\n共清理了 {deleted_count} 个临时文件")

# 使用示例（如果在notebook中运行）
# experiment_fixed = MemoryExperimentFixed()
# experiment_fixed.display_ui()

"""
安装说明：
==========

在运行此实验前，需要安装以下依赖包：

pip install gtts pydub

或者使用conda：
conda install -c conda-forge gtts pydub

重要：本实验使用ffmpeg来合并音频文件以获得最佳质量。
如果遇到问题，需要安装ffmpeg：
- macOS: brew install ffmpeg
- Ubuntu/Debian: sudo apt-get install ffmpeg
- Windows: 从 https://ffmpeg.org/download.html 下载并添加到 PATH

如果没有ffmpeg，程序会尝试使用pydub的备选方案。

使用前请确保网络连接正常，因为gTTS需要连接到Google的服务器。

注意：本版本使用ffmpeg合并音频文件，避免了numpy concatenate可能导致的声音失真问题。
"""
