# 中文即时记忆实验
# 本实验通过播放中文词汇，测试被试者的即时记忆能力

import numpy as np
import random
import time
from IPython.display import Audio, display, clear_output
import ipywidgets as widgets
from IPython.display import HTML
import matplotlib.pyplot as plt

# 实验参数设置
SAMPLE_RATE = 44100  # 采样率
DURATION = 1.0       # 每个词汇播放时长(秒)
INTERVAL = 1.5       # 词汇间隔时间(秒)
TEST_DELAY = 3.0     # 记忆后测试延迟时间(秒)

# 中文词汇库 - 按难度分级
WORD_LEVELS = {
    "简单": ["苹果", "香蕉", "桌子", "书本", "月亮", "太阳", "红色", "蓝色", 
            "高兴", "跑步", "飞机", "汽车", "学校", "家庭", "朋友"],
    "中等": ["思考", "分析", "判断", "理解", "坚持", "努力", "迅速", "缓慢",
            "困难", "容易", "详细", "简略", "勇敢", "谨慎", "智慧"],
    "困难": ["逻辑", "抽象", "辩证", "客观", "主观", "系统", "复杂", "精密",
            "卓越", "平凡", "独特", "普遍", "深刻", "肤浅", "全面"]
}

# 生成中文语音的函数(使用简单的音调模拟，实际应用中可替换为TTS)
def generate_chinese_speech(text, duration=DURATION, sr=SAMPLE_RATE):
    """生成模拟中文语音的音频信号"""
    t = np.linspace(0, duration, int(sr * duration), endpoint=False)
    
    # 为不同汉字分配不同基础频率(模拟声调)
    char_freq_map = {
        'a': 440, 'o': 494, 'e': 523, 'i': 587, 'u': 659,
        'b': 698, 'p': 784, 'm': 880, 'f': 988, 'd': 1047,
        'n': 1175, 'l': 1319, 'g': 1397, 'k': 1568, 'h': 1661,
        'j': 1760, 'q': 1976, 'x': 2093, 'z': 2349, 'c': 2637,
        's': 2794, 'r': 2937, 't': 3136, 'w': 3322, 'y': 3520
    }
    
    # 将汉字转换为拼音首字母来映射频率(简化处理)
    pinyin_first_letters = 'abcdefghijklmnopqrstwxyz'
    audio = np.zeros_like(t)
    
    for i, char in enumerate(text):
        # 简单哈希映射到拼音首字母
        idx = hash(char) % len(pinyin_first_letters)
        first_char = pinyin_first_letters[idx]
        freq = char_freq_map.get(first_char, 440)
        
        # 为每个字符生成不同时段的音频
        start = int(i * len(t) / len(text))
        end = int((i + 1) * len(t) / len(text))
        audio[start:end] += 0.5 * np.sin(2 * np.pi * freq * t[start:end])
        
        # 添加一些谐波使声音更丰富
        audio[start:end] += 0.2 * np.sin(2 * np.pi * 2 * freq * t[start:end])
        audio[start:end] += 0.1 * np.sin(2 * np.pi * 3 * freq * t[start:end])
    
    # 归一化
    audio = audio / np.max(np.abs(audio))
    return audio

# 实验控制类
class MemoryExperiment:
    def __init__(self):
        self.reset()
        
        # 创建UI组件
        self.level_selector = widgets.Dropdown(
            options=["简单", "中等", "困难"],
            value="简单",
            description="难度:"
        )
        
        self.length_selector = widgets.IntSlider(
            value=3,
            min=2,
            max=10,
            step=1,
            description="词汇数量:"
        )
        
        self.start_button = widgets.Button(
            description="开始实验",
            button_style="success"
        )
        self.start_button.on_click(self.start_experiment)
        
        self.result_area = widgets.Output()
        self.response_input = widgets.Text(
            placeholder="请输入你记住的词汇，用空格分隔",
            description="答案:"
        )
        self.submit_button = widgets.Button(
            description="提交答案",
            button_style="primary"
        )
        self.submit_button.on_click(self.submit_answer)
        
        # 布局
        self.ui = widgets.VBox([
            widgets.HTML("<h2>中文即时记忆实验</h2>"),
            widgets.HTML("<p>实验说明: 你将听到一系列中文词汇，请尽力记住它们。播放结束后，请输入你记住的所有词汇。</p>"),
            self.level_selector,
            self.length_selector,
            self.start_button,
            self.result_area
        ])
    
    def reset(self):
        """重置实验状态"""
        self.current_words = []
        self.user_responses = []
        self.start_time = 0
        self.end_time = 0
        self.is_running = False
    
    def display_ui(self):
        """显示实验UI"""
        display(self.ui)
    
    def play_word(self, word):
        """播放单个词汇"""
        audio = generate_chinese_speech(word)
        display(Audio(audio, rate=SAMPLE_RATE, autoplay=True))
    
    def start_experiment(self, b):
        """开始实验"""
        self.reset()
        self.is_running = True
        
        # 获取设置
        level = self.level_selector.value
        word_count = self.length_selector.value
        
        # 选择词汇
        self.current_words = random.sample(WORD_LEVELS[level], word_count)
        
        with self.result_area:
            clear_output()
            print(f"实验开始！即将播放 {word_count} 个{level}词汇，请集中注意力记忆...")
            time.sleep(2)
            
            # 播放词汇
            self.start_time = time.time()
            for i, word in enumerate(self.current_words):
                clear_output()
                print(f"正在播放第 {i+1}/{word_count} 个词...")
                self.play_word(word)
                time.sleep(INTERVAL)
            
            # 等待记忆时间
            clear_output()
            print("词汇播放完毕，请稍等...")
            time.sleep(TEST_DELAY)
            
            # 显示回答界面
            clear_output()
            print("请输入你记住的所有词汇，用空格分隔:")
            display(self.response_input)
            display(self.submit_button)
    
    def submit_answer(self, b):
        """提交答案并计算结果"""
        if not self.is_running:
            return
            
        self.end_time = time.time()
        self.user_responses = self.response_input.value.split()
        
        # 计算正确率
        correct = [word for word in self.user_responses if word in self.current_words]
        accuracy = len(correct) / len(self.current_words) if self.current_words else 0
        
        # 显示结果
        with self.result_area:
            clear_output()
            print(f"实验结果:\n")
            print(f"原始词汇: {', '.join(self.current_words)}")
            print(f"你的答案: {', '.join(self.user_responses) if self.user_responses else '无'}")
            print(f"正确数量: {len(correct)}/{len(self.current_words)}")
            print(f"正确率: {accuracy:.2%}")
            print(f"反应时间: {self.end_time - self.start_time:.2f}秒")
            
            # 可视化结果
            plt.figure(figsize=(8, 4))
            plt.bar(["正确", "错误"], [len(correct), len(self.current_words) - len(correct)])
            plt.title("记忆结果")
            plt.ylim(0, len(self.current_words))
            plt.show()
            
            print("\n点击'开始实验'可以再次进行测试")
        
        self.is_running = False

# 运行实验
if __name__ == "__main__":
    experiment = MemoryExperiment()
    experiment.display_ui()